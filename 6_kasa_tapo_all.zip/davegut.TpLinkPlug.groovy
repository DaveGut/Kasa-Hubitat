/*	Kasa/Tapo Integration Driver: TpLink Plug
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md
=====  Driver Notes  =====
1.	Supports Tapo Plugs and Switches
===== */

metadata {
	definition (name: "TpLink Plug", namespace: nameSpace(), author: "Dave Gutheinz", 
				singleThreaded: true,
				importUrl: "https://raw.githubusercontent.com/DaveGut/tpLink_Hubitat/main/Drivers/tpLink_plug.groovy")
	{ }
	preferences {
		commonPreferences()
	}
}

def installed() {
	Map logData = [method: "installed", commonInstalled: commonInstalled()]
	state.eventType = "digital"
	logInfo(logData)
}

def updated() {
	Map logData = [method: "updated", commonUpdated: commonUpdated()]
	logInfo(logData)
}

def parse_get_device_info(result, data) {
	switchParse(result)
}

#include davegut.smartCapConfiguration
#include davegut.smartCapSwitch
#include davegut.smartCapEngMon
#include davegut.smartCommon
#include davegut.smartComms
#include davegut.smartCrypto
#include davegut.smartTransAes
#include davegut.smartTransKlap
#include davegut.iotSmartCommon
