/*	TP-Link TAPO plug, switches, lights, hub, and hub sensors.
		Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md

Supports:  Fixed Tapo Cameras

Known issues:
1.	Not all setting functions available on Hubitat.  User should request.
2.	Driver does not work for Tapo H200/H500 cameras.

Note on Battery Capable Devices: These devices are either solely battery powered or
connected to a power source to continually charge the battery.  To achieve the maximum
battery life, the functions are somewhat limited.  Some limitations
a.	Non- ONIF and RSTP video format.
b.	If not wired, the use of polling will have sever impact on battery time between
	recharge.  Consider using other means to bring data into Hubitat and turn off
	polling.
	1)	Link to Amazon and create rules linked to Hubitat virtual device.
	2)	Use Tapo Smart Actions linking to a bulb/dimmer in your home and use bulb-level
		to set motion/ring attributes plus set inactive (I use 10-20 to set and 0 to
		set inactive).
=================================================================================================*/
metadata {
	definition (name: "TpLink Camera", namespace: nameSpace(), author: "Dave Gutheinz", 
				singleThreaded: true,
				importUrl: "https://raw.githubusercontent.com/DaveGut/tpLink_Hubitat/main/Drivers/tpLink_Camera.groovy")
	{
	}
	preferences {
		if (getDataValue("isDoorbell") == "true") {
			input ("ringOnOff", "enum", title: "Outside Doorbell Ring on/off", 
				   options: ["on", "off"])
			input ("wakeUpType", "enum", title: "Wake Up Doorbell On... ", 
			   options: ["detection", "doorbell"])
			input ("nvMode", "enum", title: "Night Vision Display Mode",
			   options: ["infrared", "doorbell", "fullColor"])
		}
		commonPreferences()
	}
}

def installed() {
	Map logData = [method: "installed", commonInstalled: commonInstalled()]
	logInfo(logData)
}

def updated() {
	Map logData = [method: "updated", commonUpdated: commonUpdated()]
	logInfo(logData)
}

def updDevSettings() {
	List requests = []
	if (getDataValue("isDoorbell") == "true") {
		def nightMode = "inf_night_vision"
		if (nvMode == "doorbell") { nightMode = "dbl_night_vision" }
		else if (nvMode == "fullColor") {nightMode = "wtl_night_vision" }
		requests << [method:"setNightVisionModeConfig", params:[
			image:[switch:[night_vision_mode:nightMode]]]]
		requests << [method:"setRingStatus", params:[ring:[status: [enabled: ringOnOff]]]]	
		requests << [method:"setWakeUpConfig", params:[wake_up:[
			config:[wake_up_type:wakeUpType]]]]
	}
	comUpdDevSettings(requests)
	return "Device Settings Updated"
}

def refresh() {
	List requests = []
	if (getDataValue("isDoorbell") == "true") {
		requests << [method:"getNightVisionModeConfig", params:[image:[name:"switch"]]]
		requests << [method:"getRingStatus", params:[ring:[name:["status","config"]]]]
		requests << [method:"getWakeUpConfig", params:[wake_up:[name:"config"]]]
	}
	comRefresh(requests)
	logDebug([method: "refresh"])
}

def parse_getNightVisionModeConfig(devData) {
	def nightMode = "infrared"
	if (devData.night_vision_mode == "dbl_night_vision") { nightMode = "doorbell" }
	else if (devData.night_vision_mode == "wtl_night_vision") { nightMode = "fullColor" }
	device.updateSetting("nvMode", [type: "enum", value: nightMode])
	return [nvMode: nightMode]
}

def parse_getWakeUpConfig(devData) {
	device.updateSetting("wakeUpType", [type: "enum", value: devData.wake_up.config.wake_up_type])
	return [wakeUpType: devData.wake_up.config.wake_up_type]
}

def parse_getRingStatus(devData) {
	device.updateSetting("ringOnOff", [type: "enum", value: devData.ring.status.enabled])
	return [ringOnOff: devData.ring.status.enabled]
}


#include davegut.smartCamCommon
#include davegut.smartCapConfiguration
#include davegut.smartComms
#include davegut.smartCrypto
#include davegut.smartCamTransport
#include davegut.iotSmartCommon
