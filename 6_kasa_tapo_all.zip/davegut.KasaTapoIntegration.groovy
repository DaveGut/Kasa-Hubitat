/*	Kasa and Tapo (TP-Link) plugs, switches, and lights integration
	Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md
===== Link to Documentation =====
	TO BE UODATED
========================================*/ 
//	=====  nameSpace() for APP and all Drivers is located in library iotSmartCommon  ======
def appType() { return "Kasa/Tapo" }
//def appType() { return "Tapo" }
//	If appType() = Tapo, Comment out include davegut.appIotProt
#include davegut.appIotProt
#include davegut.iotSmartCommon
#include davegut.appSmartProt
#include davegut.smartCrypto
#include davegut.smartTransAes
#include davegut.smartTransKlap

import groovy.json.JsonBuilder
import groovy.json.JsonSlurper
import org.json.JSONObject
 
definition(
	name: "${appType()} Integration",
	namespace: nameSpace(),
	author: "Dave Gutheinz",
	description: "Application to install TP-Link Kasa and Tapo  bulbs, plugs, and switches.",
	category: "Convenience",
	iconUrl: "",
	iconX2Url: "",
	installOnOpen: true,
	singleInstance: true,
	documentationLink: "https://github.com/DaveGut/Kasa-Hubitat/blob/main/KasaTapoIntegrationApp.pdf",
//	if appType() = "Tapo"
//	importUrl: "https://raw.githubusercontent.com/DaveGut/tpLink_Hubitat/refs/heads/main/App/tapo_device_install.groovy"
)

preferences {
	page(name: "startPage")
	page(name: "enterCredentialsPage")
	page(name: "addDevicesPage")
	page(name: "removeDevicesPage")
}

void hubStartupHandler() {
	updateVerData()
	startPage()
	runIn(30, quickFindAll)
}

//	Update if we are not deprecating existing Kasa Integration
def updateVerData() {
	//	Check if version is updated.  If so, update app data, as required.
	log.info "Updating app data to current version specific data"
	if (version != version()) {
		app?.updateSetting("version", version())
		//	Use between version updates to cleanup old data and initialize new data.
		//	Update the list below with each version update.  First time will be longest list
		//	Remove old Kasa App data no longer used
		app?.removeSetting("routerIp")
		app?.removeSetting("nonKasaIp")
		app?.removeSetting("kasaToken")
		app?.removeSetting("kasaCloudUrl")
		app?.removeSetting("pollEnabled")
		app?.removeSetting("configureEnabled")
		app?.removeSetting("debugLog")
/////
//		app?.removeSetting("ports")
		app?.removeSetting("hostLimits")	//	Always use 2:254 as limit.
		state.remove("tapoDevices")
		state.remove("hostArray")
		//	Add new setting used by the joint App
		app?.updateSetting("instMatter", [type:"bool", value: false])
		app?.updateSetting("logEnable", [type:"bool", value: false])
		app?.updateSetting("spInst", [type:"bool", value: false])
		app?.updateSetting("hidePassword", [type:"bool", value: false])
		state.finding = false
		state seqNo = 0
	}
}

def quickFindAll() {
	smartCheckForDevices(10)
	iotCheckForDevices(10)
}

def installed() {
	app?.updateSetting("logEnable", [type:"bool", value: false])
	app?.updateSetting("instMatter", [type:"bool", value: false])
	app?.updateSetting("spInst", [type:"bool", value: false])
	app?.updateSetting("hidePassword", [type:"bool", value: false])
	def hub = location.hubs[0]
	def hubIpArray = hub.localIP.split('\\.')
	def segment = [hubIpArray[0],hubIpArray[1],hubIpArray[2]].join(".")
	app?.updateSetting("lanSegment", [type:"string", value: segment])
	state.segArray = [ segment ]
/////
	app?.updateSetting("ports", [type:"string", value: "9999"])
	state.seqNo = 0
	atomicState.finding = false
	atomicState.devices = [:]
	atomicState.unsupported = [:]
	log.info "installed: [status: Initialized settings and states.]"
}

def updated() {
	app?.updateSetting("logEnable", [type:"bool", value: false])
	app?.updateSetting("appSetup", [type:"bool", value: false])
	app?.updateSetting("spInst", [type:"bool", value: false])
	runIn(180, scheduledItems)
	log.info "updated: [status: setting updated for next session]"
}

def scheduledItems() {
	unschedule() 
	runIn(600, resetSmartChecked)
	runIn(600, resetIotChecked)
	//	Remove devices not installed from devices.
	Map newDevices = [:]
	atomicState.devices.each {
		def isChild = getChildDevice(it.key)
		if (isChild) {
			newDevices << it
		}
	}
	atomicState.devices = newDevices
	atomicState.unsupported = [:]
	log.info "scheduledItems: [devData: Purged non-children, status: complete]"
}

def uninstalled() {
	List uninstalled = []
    getAllChildDevices().each {
		uninstalled << [it.alias]
        deleteChildDevice(it.deviceNetworkId)
    }
	log.info "uninstalled: [status: Device ${uninstalled} and App uninstalled]"
}

def initInstance() {
	Map logData = [setSegments: setSegments()]
	return logData
}

def setSegments() {
	Map retData = [:]
	List segments = []
	try {
		segments = lanSegment.split('\\,')
	} catch (e) {
		log.warn "startPage: Invalid entry for Lan Segements or Host Array Range. Resetting to default!"
		def hub = location.hubs[0]
		def hubIpArray = hub.localIP.split('\\.')
		def segment = [hubIpArray[0],hubIpArray[1],hubIpArray[2]].join(".")
		app?.updateSetting("lanSegment", [type:"string", value: segment])
		segments = [ segment ]
		retData << [segArray: "error - reset."]
	}
	state.segArray = segments
	List portList = []
	try {
		portList = ports.split('\\,')
	} catch (err) {
		app?.updateSetting("ports", [type:"string", value: "9999"])
		portList = ["9999"]
		retData << [portArray: "error - reset."]
	}
	state.portArray = portList
	retData << [segArray: segments, portArray: portList]
	return retData
}

def startPage() {
	Map logData = [status: "initStartPage",
				   initData: initInstance(), instMatter: instMatter, userName: userName, 
				   pwdLength: userPassword.toString().length()]
	if (selectedRemoveDevices) {removeDevices()} 
	else if (selectedAddDevices) { addDevices() }
	log.info "startPage: ${logData}"
	return dynamicPage(name:"startPage",
					   uninstall: true,
					   install: true) {
		section() {
			input "spInst", "bool", title: "<b>Display Quick Instructions</b>",
				submitOnChange: true, defaultValue: true
			if (spInst) { paragraph quickStartPg() }
			Map setupParams = [installMatterDevices: instMatter, LanSegments: state.segArray, KasaPorts: state.portArray]
			input "appSetup", "bool", title: "<b>Modify Application Setup:</b> ${setupParams}",
				submitOnChange: true, defaultValue: false
			if (appSetup) {
				input "instMatter", "bool", title: "<b>Install matter capable devices</b>",
					submitOnChange: true, defaultValue: false
				if (instMatter) {
					paragraph "\tCaution.  If the devices is already installed in Hubitat, this will created a second version."
				}
				input "lanSegment", "string",
					title: "<b>Lan Segments</b> (ex: 192.168.50, 192,168.01)", submitOnChange: true
				input "ports", "string",
					title: "<b>Kasa (IOT) ports</b> (ex: 9999, 9990)", submitOnChange: true
			}
			def credDesc = "Credentials: userName: ${userName}, password length = ${userPassword.toString().length()}."
			if (!userName || !userPassword) {
				credDesc = "<b>Credentials not set.</b>  (Credentials are local wifi use only.)  If not set, "
				credDesc += "only Kasa IOT (legacy) devices will be found."
			} else {
				createSmartCreds()
			}
			href "enterCredentialsPage",
				title: "<b>Enter/Update Username and Password</b>",
				description: credDesc
			href "addDevicesPage",
				title: "<b>Scan for devices and add</b>",
				description: "It will take 30+ seconds to find devices."
			href "removeDevicesPage",
				title: "<b>Remove Devices</b>",
				description: "Select devices to remove from Hubitat."
			input "logEnable", "bool",
				   title: "<b>Debug logging</b>",
				   submitOnChange: true
		}
	}
}

def enterCredentialsPage() { 
	Map credData = [:] 
	return dynamicPage (name: "enterCredentialsPage", 
    					title: "Enter  Credentials",
						nextPage: startPage,
                        install: false) {
		section() {
			input "hidePassword", "bool",
				title: "<b>Hide Password</b>",
				submitOnChange: true,
				defaultValue: false
			String credText = "Password and Username are both case sensitive. "
			credText += "\n<b>Some special characters in password causes failure.</b>"
			credText += "\nRecommend changing password in Phone App to alpha/numberic characters only."
			paragraph credText
			def pwdType = "string"
			if (hidePassword) { pwdType = "password" }
			input ("userName", "string",
            		title: "Email Address", 
                    required: false,
                    submitOnChange: false)
			input ("userPassword", pwdType,
            		title: "Account Password",
                    required: false,
                    submitOnChange: false)
		}
	}
}

//	===== Add selected newdevices =====
def addDevicesPage() {
	Map logData = [findDevices:findTpLinkDevices(10)]
	app?.removeSetting("selectedAddDevices")
	def addDevicesData = atomicState.devices
	Map uninstalledDevices = [:]
	Map foundDevices = [:]
	addDevicesData.each {
		def isChild = getChildDevice(it.key)
		if (!isChild) {
			uninstalledDevices["${it.key}"] = "${it.value.alias}, ${it.value.type}"
			def driver = it.value.type
			if (!driver.contains("Kasa")) { driver = "TpLink ${driver}"}
		} else {
			foundDevices << ["${it.value.alias}":  "Installed."]
		}
	}
	foundDevices = foundDevices.sort()
	String devicesFound = "<b>Found Devices</b>"
	foundDevices.each{ devicesFound += "\n\t${it}" }
	String missingDevices = "<b>Exercise missing devices through the Kasa or Tapo Phone "
	missingDevices += "App. Then select this function.</b>"
	logData << [totalUninstalledDevs: uninstalledDevices.size(), totalInstalledDevs: foundDevices.size()]
	log.info "addDevicesPage: ${logData}"
	return dynamicPage(name:"addDevicesPage",
					   title: "Add Devices to Hubitat",
					   nextPage: startPage,
					   install: false) {
	 	section() {
			input ("selectedAddDevices", "enum",
				   required: false,
				   multiple: true,
				   title: "<b>Devices to add</b> (${uninstalledDevices.size() ?: 0} available).\n\t" +
				   "Total Devices: ${addDevicesData.size()}",
				   description: "Use the dropdown to select devices.  Then select 'Done'.",
				   options: uninstalledDevices)
			if (atomicState.unsupported.size() > 0) {
				def unsupNote = "<b>Found Unsupported Devices</b>: ${atomicState.unsupported}"
				paragraph unsupNote
			}
			paragraph devicesFound
			href "addDevicesPage",
				title: "<b>Rescan for Additional Devices</b>",
				description: missingDevices
		}
	}
}
def addDevices() {
	def hub = location.hubs[0]
	Map devicesData = atomicState.devices
	selectedAddDevices.each { dni ->
		def isChild = getChildDevice(dni)
		if (!isChild) {
			def device = devicesData.find { it.key == dni }
			addDevice(device, dni)
		}
		pauseExecution(3000)
	}
	logDebug("addDevices: ${selectedAddDevices}")
	app?.removeSetting("selectedAddDevices")
} 
def addDevice(device, dni) {
	Map logData = [dni: dni, alias: device.value.alias]
	try {
		Map deviceData = [devIp: device.value.devIp,
						  protocol: device.value.protocol,
						  baseUrl: device.value.baseUrl,
						  type: device.value.type]
		if (device.value.ledVer) { deviceData << [ledVer: device.value.ledVer] }
		if (device.value.isEm) { deviceData << [isEm: device.value.isEm] }
		if (device.value.gradOnOff) { deviceData << [gradOnOff: device.value.gradOnOff] }
		if (device.value.ctLow) { deviceData << [ctLow: device.value.ctLow] }
		if (device.value.ctHigh) { deviceData << [ctHigh: device.value.ctHigh] }
		if (device.value.feature) { deviceData << [feature: device.value.feature] }
		if (device.value.plugNo) { deviceData << [plugNo: device.value.plugNo] }
		if (device.value.plugId) { deviceData << [plugId: device.value.plugId] }
		
		String driver = device.value.type
		if (!driver.contains("Kasa")) { driver = "TpLink ${driver}" }

		addChildDevice(
			nameSpace(),
			driver,
			dni,
			[
				"label": device.value.alias.replaceAll("[\u201C\u201D]", "\"").replaceAll("[\u2018\u2019]", "'").replaceAll("[^\\p{ASCII}]", ""),
				"name" : device.value.model,
				"data" : deviceData
			]
		)
		logData << [status: "added"]
	} catch (err) {
		logData << [status: "failedToAdd", device: device, errorMsg: err]
	}
	log.info "addDevice: ${logData}"
	return
}

//	===== Remove Devices =====
def removeDevicesPage() {
	Map installedDevices = [:]
	getChildDevices().each {
		installedDevices << ["${it.device.deviceNetworkId}": it.device.label]
	}
	logDebug("removeDevicesPage: ${installedDevices}")
	return dynamicPage(name:"removedDevicesPage",
					   title:"<b>Remove Devices from Hubitat</b>",
					   nextPage: startPage,
					   install: false) {
		section() {
			input ("selectedRemoveDevices", "enum",
				   required: false,
				   multiple: true,
				   title: "Devices to remove (${installedDevices.size() ?: 0} available)",
				   description: "Use the dropdown to select devices.  Then select 'Done'.",
				   options: installedDevices)
		}
	}
}
def removeDevices() {
	List removed = []
	selectedRemoveDevices.each { dni ->
		removed << [getChildDevice(dni)]
		deleteChildDevice(dni)
	}
	app?.removeSetting("selectedRemoveDevices")
	log.info "removeDevices: ${removed}"
}

def getDeviceData(dni) {
	Map devices = atomicState.devices
	def device = devices.find { it.key == dni }
	Map devData = device.value
	return devData
}

//	===== Discover devices on UDP =====
def smartCmd() { return "0200000101e51100095c11706d6f58577b22706172616d73223a7b227273615f6b6579223a222d2d2d2d2d424547494e205055424c4943204b45592d2d2d2d2d5c6e4d494942496a414e42676b71686b6947397730424151454641414f43415138414d49494243674b43415145416d684655445279687367797073467936576c4d385c6e54646154397a61586133586a3042712f4d6f484971696d586e2b736b4e48584d525a6550564134627532416257386d79744a5033445073665173795679536e355c6e6f425841674d303149674d4f46736350316258367679784d523871614b33746e466361665a4653684d79536e31752f564f2f47474f795436507459716f384e315c6e44714d77373563334b5a4952387a4c71516f744657747239543337536e50754a7051555a7055376679574b676377716e7338785a657a78734e6a6465534171765c6e3167574e75436a5356686d437931564d49514942576d616a37414c47544971596a5442376d645348562f2b614a32564467424c6d7770344c7131664c4f6a466f5c6e33737241683144744a6b537376376a624f584d51695666453873764b6877586177717661546b5658382f7a4f44592b2f64684f5374694a4e6c466556636c35585c6e4a514944415141425c6e2d2d2d2d2d454e44205055424c4943204b45592d2d2d2d2d5c6e227d7d" }
def iotCmd() { return outputXOR("""{"system":{"get_sysinfo":{}}}""") }

def findTpLinkDevices(timeout = 10) {
	if (userName && userPassword) {
		findDevices("getSmartLanData", smartCmd(), "20002", timeout)
		if (appType() == "Tapo") {
			//	Battery camera and doorbell
			findDevices("getSmartLanData", smartCmd(), "20004", timeout)
		}
		state.smartChecked = true
		runIn(600, resetSmartChecked)
	}
	if (appType() == "Kasa/Tapo") {
		state.portArray.each { port ->
			findDevices("getIotLanData", iotCmd(), port, timeout)
		}
		state.iotChecked = true
		runIn(600, resetIotChecked)
	}
	pauseExecution(5000)
	return "complete"
}

def findDevices(action, cmdData, port, timeout) {
	Map logData = [action: action, port: port, pollSegments: state.segArray]
	state.segArray.each {
		def pollSegment = it.trim()
		log.info "findDevices: [${action}, ${pollSegment}:${port}, ${timeout}]"
		logData << [pollSegment: pollSegment]
		List deviceIPs = []
		for(int i = 2; i < 255; i++) {
			deviceIPs.add("${pollSegment}.${i.toString()}")
		}
		atomicState.finding = true
		sendLanCmd("${deviceIPs.join(',')}:${port}", cmdData, action, timeout)
		def await = waitFor(30)
		pauseExecution((timeout) * 1000)
		logDebug([findDevices: logData])
	}
	return
}

def waitFor(secs) {
	int i = 0
	for(i = 0; i < secs; i+=1) {
		if (atomicState.finding == false) { i = secs } 
		else { pauseExecution(1000) }
	}
	return
}

def updateChild(dni, deviceData) {
	def child = getChildDevice(dni)
	if (child) { child.updateChild(deviceData) }
}

def quickStartPg() {
	String quickSP = ""
	quickSP += "a. Kasa/Tapo Phone App: Install device.\n"
	quickSP += "b. Kasa/Tapo Phone App: Turn on Third Party Compatibility.\n"
	quickSP += "c. Kasa/Tapo Phone App: Exercise device to be installed.\n"
	quickSP += "d. Your WiFiRouter: Set DCHP Reservation for Device.\n"
	quickSP += "e. Here: To install matter devices select Modify Application Setup.\n"
	quickSP += "f. Here: Enter/Update Username/Pwd.\n"
	quickSP += "g. Here: Scan for devices and add.\n"
	quickSP += "<b>Detailed information: use the ? icon above</b>.\n"
	return quickSP
}
