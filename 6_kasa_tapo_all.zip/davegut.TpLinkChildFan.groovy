/*	Kasa/Tapo Integration Driver: TpLink Child Fan
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md
=====  Driver Notes  =====
1.	Supports Tapo child Fan
===== */
import groovy.json.JsonBuilder

metadata {
	definition (name: "TpLink Child Fan", namespace: nameSpace(), author: "Dave Gutheinz", 
				importUrl: "https://raw.githubusercontent.com/DaveGut/tpLink_Hubitat/main/Drivers/tpLink_child_fan.groovy")
	{
		capability "FanControl"
		attribute "level", "NUMBER"
	}
	preferences {
		if (getDataValue("isEm") == "true") {
			emPreferences()
		}
		commonPreferences()
	}

}

def installed() {
	Map logData = [method: "installed"]
	List supportedFanSpeeds = ["low","medium-low","medium","high"]
	def fanSpeedsAttr = new groovy.json.JsonBuilder(supportedFanSpeeds)
	sendEvent(name: supportedFanSpeeds, value: value)
	logData << [supportedFanSpeeds: supportedFanSpeeds]
	logData << [commonInst: commonInstalled()]
	state.eventType = "digital"
	state.NOTICE = "The driver is in a BETA state and needs your feedback."
	logInfo(logData)
}

def updated() {
	Map logData = [method: "updated", commonUpdated: commonUpdated()]
	logInfo(logData)
}

def setSpeed(fanspeed) {
	Map logData = [method: "setSpeed", fanspeed: fanspeed]
	int level = 99
	switch(fanspeed) {
		case "low": level = 1; break
		case "medium-low": level = 2; break
		case "medium": level = 3; break
		case "medium-high":
			level = 4
			logData << [ALERT: "MED-HIGH NOT SUPPORTED.  SET TO HIGH"]
			break
		case "high": level = 4; break
		case "on":
			level = device.currentValue("level")
			logData << [switch: "on"]
			break
		case "off":
			off()
			logData << [switch: "off"]
			break
		case "auto":
			logData << [ALERT: "AUTO NOT SUPPORTED.  REQUEST IGNORED"]
			break
		default: 
			logData << [ALERT: "UNKNOWN SetSpeed ERROR"]
	}
	logData << [level: level]
	if (level <= 4) {
		List requests = [[
			method: "set_device_info",
			params: [device_on: true, fan_speed_level: level]]]
		requests << [method: "get_device_info"]
		sendDevCmd(requests, "setSpeed", "parseUpdates")
	}
	if (logData.ALERT == null) {
		logDebug(logData)
	} else {
		logWarn(logData)
	}
}

def cycleSpeed() {
	def currSpeed = device.currentValue("speed")
	List cycles = ["low","medium-low","medium","high", "off"]
	def nextIndex = cycles.findIndexValues { it == currSpeed }[0] + 1
	if (nextIndex > 3) { nextIndex = 0 }
	setSpeed(cycles[nextIndex.toInteger()])
}

def parse_get_device_info(result, data) {
	Map logData = [method: "parse_get_device_info", data: data, result: result]
	switchParse(result)
	def fanSpeed = result.fan_speed_level
	def speed
		switch(fanSpeed) {
		case 1: speed = "low"; break
		case 2: speed = "medium-low"; break
		case 3: speed = "medium"; break
		case 4: speed = "high"; break
		default: speed = level
	}
	updateAttr("speed", speed)
	logData << [fanSpeed: result.fan_speed_level, status: "OK"]
	logDebug(logData)
}

#include davegut.smartCapSwitch
#include davegut.smartCapEngMon
#include davegut.smartChildCommon
#include davegut.iotSmartCommon
