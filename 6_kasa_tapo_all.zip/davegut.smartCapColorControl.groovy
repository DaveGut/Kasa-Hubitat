library (
	name: "smartCapColorControl",
	namespace: "davegut",
	author: "Compied by Dave Gutheinz",
	description: "Common color control methods library for Kasa/Tapo and Tapo SMART protocol drivers.",
	category: "utilities",
	documentationLink: ""
)

capability "Color Control"
capability "Color Temperature"
capability "Color Mode"

def setHue(hue){
	logDebug("setHue: ${hue}")
	hue = (3.6 * hue).toInteger()
	logDebug("setHue: ${hue}")
	List requests = [[
		method: "set_device_info",
		params: [
			device_on: true,
			hue: hue,
			color_temp: 0
		]]]
	requests << [method: "get_device_info"]
	sendDevCmd(requests, "setHue", "parseUpdates")
}

def setSaturation(saturation) {
	logDebug("setSatiration: ${saturation}")
	List requests = [[
		method: "set_device_info",
		params: [
			device_on: true,
			saturation: saturation,
			color_temp: 0
		]]]
	requests << [method: "get_device_info"]
	sendDevCmd(requests, "setSaturation", "parseUpdates")
}

def setColor(color) {
	logDebug("setColor: ${color}")
	def level = color.level
	if (level == 0) { level = device.currentValue("level") }
	def hue = (3.6 * color.hue).toInteger()
	List requests = [[
		method: "set_device_info",
		params: [
			device_on: true,
			hue: hue,
			saturation: color.saturation,
			brightness: level,
			color_temp: 0
		]]]
	requests << [method: "get_device_info"]
	sendDevCmd(requests, "setColor", "parseUpdates")
}

def setColorTemperature(colorTemp, level = device.currentValue("level"), transTime = 0) {
	Map logData = [method: "setColorTemperature", level: level, colorTemp: colorTemp, transTime: transTime]
	if (level > 100 || level < 0) {
		logData << [error: "level out of range"]
		logWarn(logData)
		return
	}
	def lowCt = getDataValue("ctLow").toInteger()
	def highCt = getDataValue("ctHigh").toInteger()
	if (colorTemp < lowCt || colorTemp > highCt || colorTemp == null) {
		logData << [error: "colorTemp out of range"]
		logWarn(logData)
		return
	}
	if (level == 0) {
		off()
	} else if (transTime > 0) {
		execCtLevelTrans(level, colorTemp, transTime)
	} else {
		List requests = [[method: "set_device_info",
						  params: [brightness: level,
								   color_temp: colorTemp]]]
		requests << [method: "get_device_info"]
		sendDevCmd(requests, "setColorTemperature", "parseUpdates")
	}
	logDebug(logData)
}

def execCtLevelTrans(targetLevel, targetCt, transTime) {
	Map logData = [method: "execLevelTrans", targetLevel: targetLevel,
				   targetCt: targetCt, transTime: transTime]
	def currLevel = device.currentValue("level")
	def currCt = device.currentValue("colorTemperature") 
	logData << [currLevel: currLevel, currCt: currCt]
	if (targetLevel == currLevel && targetCt == currCt) {
		logData << [ERROR: "No level nor CT Change. Exit."]
		logWarn(logData)
		return
	}
	if (transTime > 10) {
		transTime = 10
		logData << [transTimeChange: transTime]
	}
	//	Determine commandDelay
	def levelChange = targetLevel - currLevel
	def scaledLevelChange = Math.abs(levelChange / 100)
	def ctRange = getDataValue("ctHigh").toInteger() - getDataValue("ctLow").toInteger()
	def ctChange = targetCt - currCt
	def scaledCtChange = Math.abs(ctChange / ctRange)
	def deltaLevel = 0
	if (levelChange > 0) {
		deltaLevel = (0.99 + (levelChange / (4 * transTime))).toInteger()	//	next greater integer.
	} else if(levelChange < 0) {
		deltaLevel = (-0.99 + (levelChange / (4 * transTime))).toInteger()
	}
	def deltaCt = 0
	if (ctChange > 0) {
		deltaCt = (0.99 + (ctChange / (4 * transTime))).toInteger()
	} else if (ctChange < 0) {
		deltaCt = (-0.99 + (ctChange / (4 * transTime))).toInteger()
	}
	def newLevel = currLevel
	def newCt = currCt
	def startTime = now()
	if (scaledLevelChange >= scaledCtChange) {
		//	calculate total increments based on level change and delta level
		def incrs = (0.99 + (levelChange / deltaLevel)).toInteger()
		cmdDelay = (1000 * transTime / incrs).toInteger() - 10
		logData << [cmdDelay: cmdDelay, incrs: incrs]
		if (targetLevel < currLevel) {
			while(targetLevel < newLevel) {
				newLevel = setNewLevel(targetLevel, currLevel, newLevel, deltaLevel)
				newCt = setNewCt(targetCt, currCt, newCt, deltaCt)
				sendTransCmd(newLevel, newCt)
				pauseExecution(cmdDelay)
			}		
		} else if (targetLevel > currLevel) {
			while(targetLevel > newLevel) {
				newLevel = setNewLevel(targetLevel, currLevel, newLevel, deltaLevel)
				newCt = setNewCt(targetCt, currCt, newCt, deltaCt)
				sendTransCmd(newLevel, newCt)
				pauseExecution(cmdDelay)
			}
		}
	} else {
		def incrs = (0.99 + (ctChange / deltaCt)).toInteger()
		def cmdDelay = (1000 * transTime / incrs).toInteger() - 10
		logData << [cmdDelay: cmdDelay, incrs: incrs]
		if (targetCt < currCt) {
			while(targetCt < newCt) {
				newLevel = setNewLevel(targetLevel, currLevel, newLevel, deltaLevel)
				newCt = setNewCt(targetCt, currCt, newCt, deltaCt)
				sendTransCmd(newLevel, newCt)
				pauseExecution(cmdDelay)
			}		
		} else if (targetCt > currCt) {
			while(targetCt > newCt) {
				newLevel = setNewLevel(targetLevel, currLevel, newLevel, deltaLevel)
				newCt = setNewCt(targetCt, currCt, newCt, deltaCt)
				sendTransCmd(newLevel, newCt)
				pauseExecution(cmdDelay)
			}
		}
	}
	def execTime = now() - startTime
	logData << [execTime: execTime]
	logDebug(logData)
	pauseExecution(500)
	setColorTemperature(targetCt, targetLevel)
}

def setNewCt(targetCt, currCt, newCt, deltaCt) {
	newCt += deltaCt
	if ((targetCt < currCt && newCt < targetCt) ||
		(targetCt > currCt && newCt > targetCt)) {
		newCt = targetCt
	}
	return newCt
}

def sendTransCmd(newLevel, newCt) {
		List requests = [[method: "set_device_info",
						  params: [
							  brightness: newLevel,
							  color_temp: newCt]]]
			sendDevCmd(requests, "sendTransCmd", "")
}

def colorParse(result) {
	Map logData = [method: "colorParse"]
	if (result.color_temp != null) {
		if (result.color_temp == 0) {
			updateAttr("colorMode", "COLOR")
			def hubHue = (result.hue / 3.6).toInteger()
			updateAttr("hue", hubHue)
			updateAttr("saturation", result.saturation)
			updateAttr("color", "[hue: ${hubHue}, saturation: ${result.saturation}]")
			def colorName = convertHueToGenericColorName(hubHue)
			updateAttr("colorName", colorName)
			def rgb = hubitat.helper.ColorUtils.hsvToRGB([hubHue,
														  result.saturation,
														  result.brightness])
			updateAttr("RGB", rgb)
			updateAttr("colorTemperature", 0)
			logData << [colorMode: "COLOR", colorName: colorName, RGB: rgb, colorTemperature: 0]
		} else {
			updateAttr("colorMode", "CT")
			updateAttr("colorTemperature", result.color_temp)
			def colorName = convertTemperatureToGenericColorName(result.color_temp.toInteger())
			updateAttr("hue", 0)
			updateAttr("saturation", 0)
			updateAttr("colorName", colorName)
			updateAttr("color", "[:]")
			updateAttr("RGB", "[]")
			logData << [colorMode: "CT", colorName: colorName, color: color, 
						RGB: RGB, colorTemperature: result.color_temp]
		}
	}
	logDebug(logData)
}
