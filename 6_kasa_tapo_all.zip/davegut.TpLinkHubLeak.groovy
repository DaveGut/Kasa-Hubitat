/*	TP-Link TAPO plug, switches, lights, hub, and hub sensors.
		Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md
=================================================================================================*/
metadata {
	definition (name: "TpLink Hub Leak", namespace: nameSpace(), author: "Dave Gutheinz", 
				importUrl: "https://raw.githubusercontent.com/DaveGut/tpLink_Hubitat/main/Drivers/tpLink_hub_leak.groovy")
	{
		capability "Water Sensor"
		capability "Battery"
		attribute "lowBattery", "string"
		capability "Sensor"
		attribute "inAlarm", "STRING"
	}
	preferences {
		commonPreferences()
	}
}

def installed() { runIn(1, updated) }

def updated() {
	Map logData = [method: "updated", commonUpdated: commonUpdated()]
	logInfo(logData)
}

def parse_get_device_info(result, data = null) {
	Map logData = [method: "parse_get_device_info"]
	def wetDry = "wet"
	if (result.water_leak_status == "water_dry") { wetDry = "dry" }
	updateAttr("water", wetDry)
	updateAttr("inAlarm", result.in_alarm)
	logData << [water: wetDry, inAlarm: result.in_alarm]
	logDebug(logData)
}

#include davegut.smartChildCommon
#include davegut.iotSmartCommon
