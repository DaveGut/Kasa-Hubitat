/*	TP-Link TAPO plug, switches, lights, hub, and hub sensors.
		Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md
Does not support the Tapo H200 nor H300 Hubs.
=================================================================================================*/
metadata {
	definition (name: "TpLink Hub", namespace: nameSpace(), author: "Dave Gutheinz", 
				singleThreaded: true,
				importUrl: "https://raw.githubusercontent.com/DaveGut/tpLink_Hubitat/main/Drivers/tpLink_hub.groovy")
	{
		capability "Alarm"
		command "configureAlarm", [
			[name: "Alarm Type", constraints: alarmTypes(), type: "ENUM"],
			[name: "Volume", constraints: ["low", "normal", "high"], type: "ENUM"],
			[name: "Duration", type: "NUMBER"]]
		attribute "alarmConfig", "JSON_OBJECT"
	}
	preferences {
		commonPreferences()
		input ("installChild", "bool", title: "Install New Child Devices", defaultValue: true)
	}
}

def alarmTypes() {
	 return [
		 "Doorbell Ring 1", "Doorbell Ring 2", "Doorbell Ring 3", "Doorbell Ring 4",
		 "Doorbell Ring 5", "Doorbell Ring 6", "Doorbell Ring 7", "Doorbell Ring 8",
		 "Doorbell Ring 9", "Doorbell Ring 10", "Phone Ring", "Alarm 1", "Alarm 2",
		 "Alarm 3", "Alarm 4", "Alarm 5", "Dripping Tap", "Connection 1", "Connection 2"
	 ] 
}

def installed() {
	Map logData = [method: "installed", commonInstalled: commonInstalled()]
	state.seqNo = 0
	logInfo(logData)
}

def updated() { 
	Map logData = [method: updated, installChild: installChild,
				   commonUpdated: commonUpdated()]
	if (installChild) {
		runIn(5, installChildDevices)
		pauseExecution(5000)
	}
	logInfo(logData)
}

def both() { siren() }
def strobe() { siren() }

def siren() {
	List requests = [[method: "play_alarm"]]
	requests << [method: "get_device_info"]
	sendDevCmd(requests, "on", "parseUpdates")
}

def off() {
	List requests =[[method: "stop_alarm"]]
	requests << [method: "get_device_info"]
	sendDevCmd(requests, "off", "parseUpdates")
}

def configureAlarm(alarmType="Doorbell Ring 1", volume="low", duration=15) {
	Map logData = [method: configureAlarm, alarmType: alarmType, volume: volume,
				   duration: duration]
	logDebug(logData)
	List requests = alarmConfig(alarmType, volume, duration)
	sendDevCmd(requests, "configureAlarm", "parseUpdates")
}
def alarmConfig(alarmType, volume, duration) {
	List requests = [
		[method: "set_alarm_configure",
		 params: [custom: 0,
				  type: "${alarmType}",
				  volume: "${volume}",
				  duration: duration.toInteger()
				 ]]]
	requests << [method: "get_alarm_configure"]
	return requests
}

def parse_get_device_info(result, data) {
	state.seqNo += 1
	Map logData = [method: "parse_get_device_info", data: data]
	def inAlarm = result.in_alarm
	def alarm = "off"
	if (inAlarm == true) { alarm = "both" }
	updateAttr("alarm", alarm)
	logData << [alarm: alarm]
	logDebug(logData)
}

def parse_get_alarm_configure(result, data) {
	Map logData = [method: "parse_get_alarm_configure", data: data]
	updateAttr("alarmConfig", result)
	logData << [alarmConfig: result]
	logDebug(logData)
}

//	===== Install Methods Unique to Hub =====
#include davegut.smartCapConfiguration
#include davegut.smartCommon
#include davegut.smartParentCommon
#include davegut.smartComms
#include davegut.smartCrypto
#include davegut.smartTransAes
#include davegut.smartTransKlap
#include davegut.iotSmartCommon
