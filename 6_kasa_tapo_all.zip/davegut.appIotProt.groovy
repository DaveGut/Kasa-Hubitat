library (
	name: "appIotProt",
	namespace: "davegut",
	author: "Dave Gutheinz",
	description: "Discovery library for Application support the Kasa IOT protocol devices.",
	category: "utilities",
	documentationLink: ""
)

def getIotLanData(response) {
	unschedule("udpTimeout")
	Integer addedDevs = 0
	if (response instanceof Map) {
		def status = getIotDiscData(response)
		if (status == "added") { addedDevs += 1 }
	} else {
		response.each {
			def status = getIotDiscData(it)
			if (status == "added") { addedDevs += 1 }
		}
	}
	Map logData = [responses: response.size(), devsAdded: addedDevs]
	log.info "getIotLanData: ${logData}"
	atomicState.finding = false
}

def getIotDiscData(response) {
	def resp = parseLanMessage(response.description)
	String status = "unknownError"
	if (resp.type == "LAN_TYPE_UDPCLIENT") {
		String ip = convertHexToIP(resp.ip)
		String payload = inputXOR(resp.payload)
		if (payload.length() >- 1023) { payload = udpStringCorrect(payload) }
		try {
			Map cmdResp = new JsonSlurper().parseText(payload).system.get_sysinfo
			status = getIotDeviceData(cmdResp, ip)
		} catch (err) {
			status = "jsonSlurper error"
			Map logData = [status: status, payload: payload, error: err]
			log.warn "getIotDiscData: ${logData}"
		}
	} else {
		status = "notLanUdpClient error"
		Map logData = [status: status, error: "not LAN_TYPE_UDPCLIENT"]
		log.warn "getIotDiscData: ${logData}"
	}
	return status
}

def getIotDeviceData(cmdResp, ip) {
	String status = "added"
	def dni
	if (cmdResp.mic_mac) {
		dni = cmdResp.mic_mac
	} else {
		dni = cmdResp.mac.replace(/:/, "")
	}
	Map devicesData = atomicState.devices
	def kasaType
	if (cmdResp.mic_type) {
		kasaType = cmdResp.mic_type
	} else {
		kasaType = cmdResp.type
	}
	def type = "Kasa Plug Switch"
	def feature = cmdResp.feature
	if (kasaType == "IOT.SMARTPLUGSWITCH") {
		if (cmdResp.dev_name && cmdResp.dev_name.contains("Dimmer")) {
			feature = "dimmingSwitch"
			type = "Kasa Dimming Switch"
		}
	} else if (kasaType == "IOT.SMARTBULB") {
		if (cmdResp.lighting_effect_state) {
			feature = "lightStrip"
			type = "Kasa Light Strip"
		} else if (cmdResp.is_color == 1) {
			feature = "colorBulb"
			type = "Kasa Color Bulb"
		} else if (cmdResp.is_variable_color_temp == 1) {
			feature = "colorTempBulb"
			type = "Kasa CT Bulb"
		} else {
			feature = "monoBulb"
			type = "Kasa Mono Bulb"
		}
	} else {
		status = "notSupported"
		Map logData = [model: cmdResp.model, type:kasaType, ip:ip, protocol:"IOT", status: status]
		log.info "parseIotDeviceData: ${logData}"
		return status
	}
	if (cmdResp.children) {
		cmdResp.children.each {
			String childAlias = it.alias
			String plugNo = it.id
			String plugId = cmdResp.deviceId + plugNo
			String childDni = dni + plugNo
			Map device = [devIp: ip, protocol: "IOT", baseUrl: "${ip}:9999",
						  model: cmdResp.model.substring(0,5), kasaType: kasaType,
						  type: type, feature: feature, alias: childAlias, 
						  plugId: plugId, plugNo: plugNo]
			devicesData << ["${childDni}": device]
			Map logData = ["${childAlias}": [model: cmdResp.model, protocol: "IOT"]]
			logDebug("parseIotDeviceData: ${logData}")
			updateChild(childDni, device)
		}
	} else {
		Map device = [devIp: ip, protocol: "IOT", baseUrl: "${ip}:9999",
					  model: cmdResp.model.substring(0,5), kasaType: kasaType,
					  type: type, feature: feature, alias: cmdResp.alias]
		devicesData << ["${dni}": device]
		Map logData = ["${cmdResp.alias}": [model: cmdResp.model, protocol: "IOT"]]
		logDebug("parseIotDeviceData: ${logData}")
		updateChild(dni, device)
	}
	atomicState.devices = devicesData
	return status
}

//	===== Support device data update request =====
def iotCheckForDevices(timeout = 5) {
	Map logData = [:]
	def checked = true
	if (state.iotChecked == true) {
		logData << [status: "noCheck", reason: "Completed within last 10 minutes"]
	} else {
		findDevices("getIotLanData", "getIotLanData", "9999", 5)	
		logData << [status: "checking"]
		state.iotChecked = true
		runIn(600, resetIotChecked)
	}
	logDebug("iotCheckForDevices: ${logData}")
log.trace "iotCheckForDevices: ${logData}"
	return checked
}

def resetIotChecked() { state.iotChecked = false }

def syncBulbPresets(bulbPresets) {
	logDebug("syncBulbPresets")
	def devices = state.devices
	devices.each {
		def type = it.value.type
		if (type == "Kasa Color Bulb" || type == "Kasa Light Strip") {
			def child = getChildDevice(it.value.dni)
			if (child) {
				child.updatePresets(bulbPresets)
			}
		}
	}
}

def resetStates(deviceNetworkId) {
	logDebug("resetStates: ${deviceNetworkId}")
	def devices = state.devices
	devices.each {
		def type = it.value.type
		def dni = it.value.dni
		if (type == "Kasa Light Strip") {
			def child = getChildDevice(dni)
			if (child && dni != deviceNetworkId) {
				child.resetStates()
			}
		}
	}
}

def syncEffectPreset(effData, deviceNetworkId) {
	logDebug("syncEffectPreset: ${effData.name} || ${deviceNetworkId}")
	def devices = state.devices
	devices.each {
		def type = it.value.type
		def dni = it.value.dni
		if (type == "Kasa Light Strip") {
			def child = getChildDevice(dni)
			if (child && dni != deviceNetworkId) {
				child.updateEffectPreset(effData)
			}
		}
	}
}

private outputXOR(command) {
	def str = ""
	def encrCmd = ""
 	def key = 0xAB
	for (int i = 0; i < command.length(); i++) {
		str = (command.charAt(i) as byte) ^ key
		key = str
		encrCmd += Integer.toHexString(str)
	}
   	return encrCmd
}

private inputXOR(encrResponse) {
	String[] strBytes = encrResponse.split("(?<=\\G.{2})")
	def cmdResponse = ""
	def key = 0xAB
	def nextKey
	byte[] XORtemp
	for(int i = 0; i < strBytes.length-1; i++) {
		nextKey = (byte)Integer.parseInt(strBytes[i], 16)	// could be negative
		XORtemp = nextKey ^ key
		key = nextKey
		cmdResponse += new String(XORtemp)
	}
	return cmdResponse
}
