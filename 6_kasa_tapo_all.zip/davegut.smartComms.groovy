library (
	name: "smartComms",
	namespace: "davegut",
	author: "Compiled by Dave Gutheinz",
	description: "Communication methods for TP-Link Integration",
	category: "utilities",
	documentationLink: ""
)
import org.json.JSONObject
import groovy.json.JsonOutput
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper

//	===== Communications Methods =====
def asyncSend(cmdBody, reqData, action) {
	Map cmdData = [cmdBody: cmdBody, reqData: reqData, action: action]
	def protocol = getDataValue("protocol")
	Map reqParams = [:]
	if (protocol == "KLAP") {
		reqParams = getKlapParams(cmdBody)
	} else if (protocol == "camera") {
		reqParams = getCameraParams(cmdBody, reqData)
	} else if (protocol == "AES") {
		reqParams = getAesParams(cmdBody)
	} else if (protocol == "vacAes") {
		reqParams = getVacAesParams(cmdBody, "${getDataValue("baseUrl")}/?token=${token}")
	}
	if (reqParams != [:]) {
		if (state.errorCount == 0) { state.lastCommand = cmdData }
		asynchttpPost(action, reqParams, [data: reqData])
		logDebug([method: "asyncSend", reqData: reqData])
	} else {
		unknownProt(reqData)
	}
}

def unknownProt(reqData) {
	Map warnData = ["<b>UnknownProtocol</b>": [data: reqData,
				    msg: "Device will not install or if installed will not work"]]
	logWarn(warnData)
}
	
def parseData(resp, protocol = getDataValue("protocol"), data = null) {
	Map logData = [method: "parseData", status: resp.status, protocol: protocol,
				   sourceMethod: data.data]
	def message = "OK"
	if (resp.status == 200) {
		if (protocol == "KLAP") {
			logData << parseKlapData(resp, data)
		} else if (protocol == "AES") {
			logData << parseAesData(resp, data)
		} else if (protocol == "vacAes") {
			logData << parseVacAesData(resp, data)
		} else if (protocol == "camera") {
			logData << parseCameraData(resp, data)
		}
	} else {
		message = resp.errorMessage
		String userMessage = "unspecified"
		if (resp.status == 403) {
			userMessage = "<b>Try again. If error persists, check your credentials</b>"
		} else if (resp.status == 408) {
			userMessage = "<b>Your router connection to ${getDataValue("baseUrl")} failed.  Run Configure.</b>"
		} else {
			userMessage = "<b>Unhandled error Lan return</b>"
		}
		logData << [respMessage: message, userMessage: userMessage]
		logDebug(logData)
	}
	handleCommsError(resp.status, message)
	return logData
}

private sendFindCmd(ip, port, cmdData, action, commsTo = 5, ignore = false) {
	def myHubAction = new hubitat.device.HubAction(
		cmdData,
		hubitat.device.Protocol.LAN,
		[type: hubitat.device.HubAction.Type.LAN_TYPE_UDPCLIENT,
		 destinationAddress: "${ip}:${port}",
		 encoding: hubitat.device.HubAction.Encoding.HEX_STRING,
		 ignoreResponse: ignore,
		 parseWarning: true,
		 timeout: commsTo,
		 callback: action])
	try {
		sendHubCommand(myHubAction)
	} catch (error) {
		logWarn("sendLanCmd: command to ${ip}:${port} failed. Error = ${error}")
	}
	return
}

//	Unknown Protocol method
//	===== Communications Error Handling =====
def handleCommsError(status, msg = "") {
	//	Retransmit all comms error except Switch and Level related (Hub retries for these).
	//	This is determined by state.digital
	if (status == 200) {
		setCommsError(status, "OK")
	} else {
		Map logData = [method: "handleCommsError", status: code, msg: msg]
		def count = state.errorCount + 1
		logData << [count: count, status: status, msg: msg]
		switch(count) {
			case 1:
			case 2:
				//	errors 1 and 2, retry immediately
				runIn(1, delayedPassThrough)
				break
			case 3:
				//	error 3, login or scan find device on the lan
				//	then retry
				if (status == 403) {
					logData << [action: "attemptLogin"]
//	await device handshake result????
					deviceHandshake()
					runIn(4, delayedPassThrough)
				} else {
					logData << [action: "Find on LAN then login"]
					configure()
//	await configure result?????
					runIn(10, delayedPassThrough)
				}
				break
			case 4:
				runIn(1, delayedPassThrough)
				break
			default:
				//	Set comms error first time errros are 5 or more.
				logData << [action: "SetCommsErrorTrue"]
				setCommsError(status, msg, 5)
		}
		state.errorCount = count
		logInfo(logData)
	}
}

def delayedPassThrough() {
	def cmdData = new JSONObject(state.lastCommand)
	def cmdBody = parseJson(cmdData.cmdBody.toString())
	asyncSend(cmdBody, cmdData.reqData, cmdData.action)
}

def setCommsError(status, msg = "OK", count = state.commsError) {
	Map logData = [method: "setCommsError", status: status, errorMsg: msg, count: count]
//	if (device && status == 200) {
	if (status == 200) {
		state.errorCount = 0
		if (device.currentValue("commsError") == "true") {
			sendEvent(name: "commsError", value: "false")
			setPollInterval()
			unschedule("errorConfigure")
			logInfo(logData)
		}
//	} else if (device) {
	} else {
		if (device.currentValue("commsError") == "false" && count > 4) {
			updateAttr("commsError", "true")
			setPollInterval("30 min")
			runEvery10Minutes(errorConfigure)
			logData << [pollInterval: "30 Min", errorConfigure: "ever 10 min"]
			logWarn(logData)
			if (status == 403) {
				logWarn(logInErrorAction())
			} else {
				logWarn(lanErrorAction())
			}
		} else {
			logData << [error: "Unspecified Error"]
			logWarn(logData)
		}
	}
}

def errorConfigure() {
	logDebug([method: "errorConfigure"])
	if (device.currentValue("commsError") == "true") {
		configure()
	} else {
		unschedule("errorConfigure")
	}
}

def lanErrorAction() {
	def action = "Likely cause of this error is YOUR LAN device configuration: "
	action += "a. VERIFY your device is on the DHCP list in your router, "
	action += "b. VERIFY your device is in the active device list in your router, and "
	action += "c. TRY controlling your device from the TAPO phone app."
	return action
}

def logInErrorAction() {
	def action = "Likely cause is your login credentials are incorrect or the login has expired. "
	action += "a. RUN command Configure. b. If error persists, check your credentials in the App"
	return action
}
