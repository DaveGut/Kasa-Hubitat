/*	TP-Link TAPO plug, switches, lights, hub, and hub sensors.
		Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md
=================================================================================================*/
metadata {
	definition (name: "TpLink Hub Plug", namespace: nameSpace(), author: "Dave Gutheinz", 
				importUrl: "https://raw.githubusercontent.com/DaveGut/tpLink_Hubitat/main/Drivers/tpLink_hub_plug.groovy")
	{
		capability "Battery"
		attribute "lowBattery", "string"
		capability "Sensor"
	}
	preferences {
		commonPreferences()
	}
}

def installed() { 
	state.eventType = "digital"
	runIn(1, updated)
}

def updated() {
	Map logData = [method: "updated", commonUpdated: commonUpdated()]
	state.BETA_VERSION = "This is a beta version of the driver."
	logInfo(logData)
}

def parse_get_device_info(result, data = null) {
	Map logData = [method: "parse_get_device_info"]
	switchParse(result)
	if (state.fullUpdate) {
		byte[] plainBytes = result.nickname.decodeBase64()
		def newLabel = new String(plainBytes)
		device.setLabel(newLabel)
		device.updateSetting("syncName",[type:"enum", value: "notSet"])
		updateAttr("lowBattery", result.is_low.toString())
		updateAttr("battery", result.battery_percentage)
		state.fullUpdate = false
		logData << [newLabel: newLabel, lowBattery: result.at_low_battery, 
					battery: result.battery_percentage]
	}
	logDebug(logData)
}

#include davegut.smartCapSwitch
#include davegut.smartChildCommon
#include davegut.iotSmartCommon
