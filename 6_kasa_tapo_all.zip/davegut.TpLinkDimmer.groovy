/*	TP-Link TAPO plug, switches, lights, hub, and hub sensors.
		Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md
TEST Version
=================================================================================================*/
metadata {
	definition (name: "TpLink Dimmer", namespace: nameSpace(), author: "Dave Gutheinz", 
				singleThreaded: true,
				importUrl: "https://raw.githubusercontent.com/DaveGut/tpLink_Hubitat/main/Drivers/tpLink_dimmer.groovy")
	{
		capability "Light"
	}
	preferences {
		commonPreferences()
	}
}

def installed() {
	Map logData = [method: "installed", commonInstalled: commonInstalled()]
	state.eventType = "digital"
	logInfo(logData)
}

def updated() {
	Map logData = [method: "updated", commonUpdated: commonUpdated()]
	logInfo(logData)
}

def parse_get_device_info(result, data) {
	switchParse(result)
	levelParse(result)
}

//	Library Inclusion
#include davegut.smartCapConfiguration
#include davegut.smartCapSwitch
#include davegut.smartCapSwitchLevel
#include davegut.smartCommon
#include davegut.smartComms
#include davegut.smartCrypto
#include davegut.smartTransAes
#include davegut.smartTransKlap
#include davegut.iotSmartCommon
