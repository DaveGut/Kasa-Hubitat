library (
	name: "smartChildCommon",
	namespace: "davegut",
	author: "Compied by Dave Gutheinz",
	description: "Common child methods library for Kasa/Tapo and Tapo SMART protocol drivers.",
	category: "utilities",
	documentationLink: ""
)

capability "Refresh"

def commonPreferences() {
	input ("syncName", "enum", title: "Update Device Names and Labels", 
		   options: ["hubMaster", "tapoAppMaster", "notSet"], defaultValue: "notSet")
	input ("logEnable", "bool",  title: "Enable debug logging for 30 minutes", defaultValue: false)
	input ("infoLog", "bool", title: "Enable information logging",defaultValue: true)
}

def commonInstalled() {
	runIn(1, updated)
	return [eventType: "digital"]
}

def commonUpdated() {
	unschedule()
	Map logData = [logging: setLogsOff()]
	updDevSettings()
	if (getDataValue("isEm") == "true") {
		logData << [emUpdated: emUpdated()]
	}
	pauseExecution(5000)
	return logData
}

def updDevSettings() {
	Map params = [:]
	String tempUnit = "celsius"
	if (tempScale != null && tempScale != "C")  {
		tempUnit = "fahrenheit"
		params << [temp_unit: tempUnit]
	}
	if (maxCtrlTemp != null) {
		params << [frost_protection_on: frostProtect,
				   max_control_temp: maxCtrlTemp,
				   min_control_temp: minCtrlTemp]	
	}
	if (syncName == "hubMaster") {
		String nickname = device.getLabel().bytes.encodeBase64().toString()
		params << [nickname: nickname]
		device.updateSetting("syncName",[type:"enum", value: "notSet"])
	}
	List requests = [
		[method: "set_device_info", params: params],
		[method: "get_device_info"]
	]
	sendDevCmd(requests, "updDevSettings", "parseUpdates")
}

def refresh() {
	List requests = [[method: "get_device_info"]]
	if (getDataValue("isEm") == "true") {
		requests << [method: "get_current_power"]
	}
	sendDevCmd(requests, device.getDeviceNetworkId(), "parseUpdates")
}

def parseNameUpdate(result) {
	if (syncName != "notSet") {
		Map logData = [method: "parseNameUpdate"]
		byte[] plainBytes = result.nickname.decodeBase64()
		def newLabel = new String(plainBytes)
		device.setLabel(newLabel)
		device.updateSetting("syncName",[type:"enum", value: "notSet"])
		logData << [label: newLabel]
		logDebug(logData)
	}
}

//	===== Comms, etc =====
def sendDevCmd(requests, data, action) {
	Map multiCmdBody = [
		method: "multipleRequest",
		params: [requests: requests]]
	Map cmdBody = [method: "control_child",
				   params: [device_id: getDataValue("deviceId"),
							requestData: multiCmdBody]]
	parent.asyncSend(cmdBody, device.getDeviceNetworkId(), action)
}

def sendSingleCmd(request, data, action) {
	Map cmdBody = [method: "control_child",
				   params: [device_id: getDataValue("deviceId"),
							requestData: request]]
	parent.asyncSend(cmdBody, device.getDeviceNetworkId(), action)
}
