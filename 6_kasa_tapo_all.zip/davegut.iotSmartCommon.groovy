library (
	name: "iotSmartCommon",
	namespace: "davegut",
	author: "Dave Gutheinz",
	description: "Common methods library for Kasa/Tapo and Tapo applications and drivers.",
	category: "utilities",
	documentationLink: ""
)
def nameSpace() { return "davegut" }
def version() {return "2.4.4a"}

//	===== Common UDP Communications Methods =====
private sendLanCmd(ipPort, cmdData, action, commsTo = 5, ignore = false) {
	def myHubAction = new hubitat.device.HubAction(
		cmdData,
		hubitat.device.Protocol.LAN,
		[type: hubitat.device.HubAction.Type.LAN_TYPE_UDPCLIENT,
		 destinationAddress: ipPort,
		 encoding: hubitat.device.HubAction.Encoding.HEX_STRING,
		 ignoreResponse: ignore,
		 parseWarning: true,
		 timeout: commsTo,
		 callback: action])
	try {
		runIn(commsTo + 5, udpTimeout)
		sendHubCommand(myHubAction)
	} catch (error) {
		log.warn "sendLanCmd: command to ${ipPort} failed. Error = ${error}"
	}
	return
}

def udpTimeout() {
	Map logData = [method: "udpTimeout", status: "no devices found", error: "udpTimeout"]
	logDebug(logData)
	atomicState.finding = false
}

def udpStringCorrect(payloadString) {
	if (payloadString.count("{") != payloadString.count("}")) {
		if (payloadString.count("[") != payloadString.count("]")) {
		//	First, delete entire data within incomplete bracket.  Next will then delete the label.
			payloadString = payloadString.substring(0, payloadString.lastIndexOf("["))
		}
		payloadString = payloadString.substring(0, payloadString.lastIndexOf(',\"'))
		def addString = "}" * (1 + payloadString.count("{") - payloadString.count("}"))
		payloadString += addString
	}
	return payloadString
}

private String convertHexToIP(hex) {
	[convertHexToInt(hex[0..1]),convertHexToInt(hex[2..3]),convertHexToInt(hex[4..5]),convertHexToInt(hex[6..7])].join(".")
}

private Integer convertHexToInt(hex) { Integer.parseInt(hex,16) }

def updateAttr(attr, value) {
	if (device.currentValue(attr) != value) {
		sendEvent(name: attr, value: value)
	}
}

def updateChildDevice(devData) {
log.trace "updateChildDevice: $devData"
	if (devData != null) {
		if (devData.devIp != getDataValue("deviceIP") || devData.protocol != getDataValue("protocol")) {
			Map logData = [deviceIP: devData..deviceIp, devicePort: devData.devPort, protocol: devData.protocol, 
						   baseUrl: devData.baseUrl, status: "updated", action: "refresh"]
			updateDataValue("deviceIP", devData.devIp)
			updateDataValue("baseUrl", devData.baseUrl)
			updateDataValue("protocol", devData.protocol)
			updateDataValue("devicePort", devData.devPort)
			log.info "updateChildDevice: ${logData}"
			refresh()
		} else {
			logDebug("updateChildDevice: noChange")
		}
	} else {
		logDebug("updateChildDevice: devDataNull")
	}
}

def listAttributes() {
	def attrData = device.getCurrentStates()
	Map attrs = [:]
	attrData.each {
		attrs << ["${it.name}": it.value]
	}
	return attrs
}

//	===== Logging =====
def setLogsOff() {
	def logData = [infoLog: infoLog, logEnable: logEnable]
	if (logEnable) {
		runIn(1800, debugLogOff)
		logData << [debugLogOff: "scheduled"]
	}
	return logData
}

def logTrace(msg){ log.trace msg }

def logInfo(msg) { 
	if (infoLog) { log.info msg }
}

def debugLogOff() {
	if (device) {
		device.updateSetting("logEnable", [type:"bool", value: false])
	} else {
		app.updateSetting("logEnable", false)
	}
	logInfo("debugLogOff")
}

def logDebug(msg) {
	if (logEnable) { log.debug msg }
}

def logWarn(msg) { log.warn msg }

def logError(msg) { log.error msg }
