library (
	name: "appSmartProt",
	namespace: "davegut",
	author: "Dave Gutheinz",
	description: "Discovery library for Application support the Tapo Smart protocol devices.",
	category: "utilities",
	documentationLink: ""
)
import groovy.json.JsonOutput

def createSmartCreds() {
	String encUsername = mdEncode("SHA-1", userName.bytes).encodeHex().encodeAsBase64().toString()
	app?.updateSetting("encUsername", [type: "string", value: encUsername])
	String encPassword = userPassword.trim().bytes.encodeBase64().toString()
	app?.updateSetting("encPassword", [type: "string", value: encPassword])
	//	KLAP Local Hash
	byte[] userHashByte = mdEncode("SHA-1", encodeUtf8(userName).getBytes())
	byte[] passwordHashByte = mdEncode("SHA-1", encodeUtf8(userPassword.trim()).getBytes())
	byte[] authHashByte = [userHashByte, passwordHashByte].flatten()
	String authHash = mdEncode("SHA-256", authHashByte).encodeBase64().toString()
	app?.updateSetting("localHash", [type: "string", value: authHash])
	if (appType() == "Tapo") {
		//	vacAes Creds (password only)
		String encPasswordVac = mdEncode("MD5", userPassword.trim().bytes).encodeHex().toString().toUpperCase()
		app?.updateSetting("encPasswordVac", [type: "string", value: encPasswordVac])
		//	Camera Creds (password only)
		String encPasswordCam = mdEncode("SHA-256", userPassword.trim().bytes).encodeHex().toString().toUpperCase()
		app?.updateSetting("encPasswordCam", [type: "string", value: encPasswordCam])
	}
	logDebug("createSmartCreds: Created credeitial settings")
	return
}

def getSmartLanData(response) {
	unschedule("udpTimeout")
	Integer addedDevs = 0
	def status
	if (response instanceof Map) {
		status = getSmartDiscData(response, "discovery")
		if (status == "added") { addedDevs += 1 }
	} else {
		response.each {
			status = getSmartDiscData(it, "discovery")
			if (status == "added") { addedDevs += 1 }
		}
	}
	Map logData = [responses: response.size(), devsToValidate: addedDevs]
	log.info "getSmartLanData: ${logData}"
	atomicState.finding = false
}

def getSmartDiscData(response, type) {
	def resp = parseLanMessage(response.description)
	String status = "unknownError"
	if (resp.type == "LAN_TYPE_UDPCLIENT") {
		byte[] payloadByte = hubitat.helper.HexUtils.hexStringToByteArray(resp.payload.drop(32)) 
		String payload = new String(payloadByte)
		if (payload.length() >= 1007) { payload = udpStringCorrect(payload) }
		try {
			Map cmdResp = new JsonSlurper().parseText(payload).result
			if (type == "discovery") {
				status = getSmartDeviceData(cmdResp)
			} else {
				status = updateSmartDevice(cmdResp)
			}
		} catch (err) {
			status = "jsonSlurper error"
			Map logData = [status: status, payload: payload, error: err]
			log.warn "getSmartDiscData: ${logData}"
		}
	} else {
		status = "notLanUdpClient error"
		Map logData = [status: status, error: "not LAN_TYPE_UDPCLIENT"]
		log.warn "getIotDiscData: ${logData}"
	}
	return status
}

def getSmartDeviceData(payload) {
	Map devData = [:]
	String devType = payload.device_type
	String model = payload.device_model
	String devIp = payload.ip
	String protocol = payload.mgt_encrypt_schm.encrypt_type
	String status = "added"
	if (isTypeSup(devType, model) == false) {
		Map unsupData = ["${model}": [type: devType, ip: devIp, protocol: protocol]]
		atomicState.unsupported << unsupData
		status = "notSupported"
		log.info "getSmartDiscData: [notSupported: ${unsupData}]"
	} else {
		String dni = payload.mac.replaceAll("-", "")
		String port = payload.mgt_encrypt_schm.http_port
		String httpStr = "http://"
		String httpPath = "/app"
		if (payload.mgt_encrypt_schm.is_support_https) { httpStr = "https://" }
		if (devType == "SMART.TAPOHUB" || devType == "SMART.KASAHUB") {
			port = "443"
		} else if (devType == "SMART.TAPOROBOVAC" && protocol == "AES") {
			httpPath = ""
			protocol = "vacAes"
		}
		String baseUrl = httpStr + devIp + ":" + port + httpPath
		devData << [type: devType, model: model, baseUrl: baseUrl, dni: dni, ip: 
					devIp, port: port, protocol: protocol, status: "OK"]
		if (payload.power) { devData << [power: payload.power] }
		if (devData.protocol == "KLAP") {
			klapHandshake(devData.baseUrl, localHash, devData)
		} else if (devData.protocol == "AES") {
			aesHandshake(devData.baseUrl, devData)
		} else if (devData.protocol == "vacAes") {
			vacAesHandshake(devData.baseUrl, userName, encPasswordVac, devData)
		} else if (devData.protocol == "camera") {
			Map hsInput = [url: devData.baseUrl, user: userName, pwd: encPasswordCam]
			cameraHandshake(hsInput, devData)
		} else { 
			unknownProt(devData)
		}
		pauseExecution(700)
		Map logData = [added: [model: model, ip: devIp, protocol: protocol]]
		logDebug("getSmartDiscData: ${logData}")
	}
	return status
}

def isTypeSup(devType, model) {
	//	Validated device types
	List supTypes = ["SMART.TAPOBULB", "SMART.TAPOPLUG", "SMART.TAPOSWITCH",
					 "SMART.KASAPLUG", "SMART.KASASWITCH", "SMART.KASABULB"]
	if (appType() == "Tapo") {
		supTypes << ["SMART.TAPOHUB", "SMART.KASAHUB","SMART.TAPOROBOVAC",
					 "SMART.IPCAMERA",  "SMART.TAPODOORBELL"]
	}
	def supported = false
	if (supTypes.contains(devType)) { supported = true }
	if (model.contains("H200") || model.contains("H500")) { supported = false }
	return supported
}

def getSmartDataCmd() {
	List requests = [[method: "get_device_info"], [method: "component_nego"]]
	Map cmdBody = [method: "multipleRequest", params: [requests: requests]]
	return cmdBody
}

def smartAddToDevices(devData, cmdData) {
	String dni = devData.dni
	Map devicesData = atomicState.devices
	String tpType = devData.type
	String model = devData.model
	String devIp = devData.ip
	String protocol = devData.protocol
	String baseUrl = devData.baseUrl
	comps = cmdData.find { it.method == "component_nego" }
	comps = comps.result.component_list
	cmdResp = cmdData.find { it.method == "get_device_info" }
	cmdResp = cmdResp.result
	byte[] aliasBytes = cmdResp.nickname.decodeBase64()
	String alias = new String(aliasBytes)
//	Installation Exclusion(s)	
	if (instMatter == false && comps.find {it.id == "matter"}) {
		Map logData = [alias: alias, issue: "Matter device not added to devices"]
		logDebug([smartAddToDevices: logData])
		return
	}
	if (alias == "") { alias = model }
	def type = "Unknown"
	def ctHigh
	def ctLow
	Map deviceData = [devIp: devIp, deviceType: tpType, protocol: protocol,
					  model: model, baseUrl: baseUrl, alias: alias]
	if (tpType.contains("PLUG") || tpType.contains("SWITCH")) {
		type = "Plug"
		if (comps.find { it.id == "control_child" }) {
			type = "Parent"
		} else if (comps.find{it.id=="dimmer"} || comps.find{it.id=="brightness"}) {
			type = "Dimmer"
		}
	} else if (tpType.contains("BULB")) {
		type = "Dimmer"
		if (comps.find { it.id == "light_strip" }) {
			type = "Lightstrip"
		} else if (comps.find { it.id == "color" }) {
			type = "Color Bulb"
		}
		if (type != "Dimmer" && comps.find { it.id == "color_temperature" } ) {
			deviceData << [ctHigh: cmdResp.color_temp_range[1], ctLow: cmdResp.color_temp_range[0]]
		}
	} else if (tpType.contains("HUB")) {
		type = "Hub"
	}
	deviceData << [type: type]
	if (comps.find {it.id == "led"} ) { 
		String ledVer = comps.find {it.id == "led"}.ver_code
		if (ledVer == null) {
			ledVer = comps.find { it.name == "led" }.version
		}
		deviceData << [ledVer: ledVer]
	}
	if (comps.find {it.id == "energy_monitoring"}) { deviceData << [isEm: "true"] }
	if (comps.find {it.id == "on_off_gradually"}) { deviceData << [gradOnOff: "true"] }
	devicesData << ["${dni}": deviceData]
	atomicState.devices = devicesData
	Map logData = ["${alias}": [model: deviceData.model, protocol: protocol]]
	logDebug("smartAddToDevices: ${logData}")
	updateChild(dni, deviceData)
}

//	===== get Smart KLAP Protocol Data =====
def sendKlapDataCmd(handshakeData, data) {
	if (handshakeData.respStatus != "Login OK") {
		Map logData = [handshake: handshakeData, data: data]
		log.warn "sendKlapDataCmd: ${logData}"
	} else {
		def seqNo = data.data.seqNo + 1
		String cmdBodyJson = new groovy.json.JsonBuilder(getSmartDataCmd()).toString()
		Map encryptedData = klapEncrypt(cmdBodyJson.getBytes(), data.data.encKey, 
										data.data.encIv, data.data.encSig, seqNo)
		Map reqParams = [
			uri: "${data.data.devData.baseUrl}/request?seq=${encryptedData.seqNumber}",
			body: encryptedData.cipherData,
			ignoreSSLIssues: true,
			timeout:10,
			contentType: "application/octet-stream",
			requestContentType: "application/octet-stream",
			headers: ["Cookie": data.data.cookie]
		]
		asynchttpPost("parseKlapResp", reqParams, [data: data])
	}
}

def parseKlapResp(resp, respData) {
	Map data = respData.data
	Map logData = [method: "parseKlapResp", ip: data.data.devData.ip, model: data.data.devData.model]
	if (resp.status == 200) {
		Map cmdResp = [:]
		try {
			byte[] cipherResponse = resp.data.decodeBase64()[32..-1]
			def clearResp = klapDecrypt(cipherResponse, data.data.encKey,
									data.data.encIv, data.data.seqNo + 1)
			cmdResp =  new JsonSlurper().parseText(clearResp)
			logData << [status: "OK"]
		} catch (err) {
			logData << [error: err, errTxt: "error decyphering response"]
			log.warn logData 
			return
		}
		if (cmdResp.error_code == 0) {
			smartAddToDevices(data.data.devData, cmdResp.result.responses)
			logDebug(logData)
		} else {
			logData << [status: "errorInCmdResp", cmdResp: cmdResp]
			log.warn logData 
		}
	} else {
		logData << [status: "httpFailure", data: resp.properties]
		log.warn logData 
	}
}

//	===== get Smart AES Protocol Data =====
def getAesToken(resp, data) {
	Map logData = [method: "getAesToken"]
	if (resp.status == 200) {
		if (resp.json.error_code == 0) {
			try {
				def clearResp = aesDecrypt(resp.json.result.response, data.encKey, data.encIv)
				Map cmdResp = new JsonSlurper().parseText(clearResp)
				if (cmdResp.error_code == 0) {
					def token = cmdResp.result.token
					logData << [respStatus: "OK", token: token]
					logDebug(logData)
					sendAesDataCmd(token, data)
				} else {
					logData << [respStatus: "ERROR code in cmdResp", 
								error_code: cmdResp.error_code,
								check: "cryptoArray, credentials", data: cmdResp]
					log.warn logData 
				}
			} catch (err) {
				logData << [respStatus: "ERROR parsing respJson", respJson: resp.json,
							error: err]
				log.warn logData 
			}
		} else {
			logData << [respStatus: "ERROR code in resp.json", errorCode: resp.json.error_code,
						respJson: resp.json]
			log.warn logData 
		}
	} else {
		logData << [respStatus: "ERROR in HTTP response", respStatus: resp.status, data: resp.properties]
		log.warn logData 
	}
}

def sendAesDataCmd(token, data) {
	def cmdStr = JsonOutput.toJson(getSmartDataCmd()).toString()
	Map reqBody = [method: "securePassthrough",
				   params: [request: aesEncrypt(cmdStr, data.encKey, data.encIv)]]
	Map reqParams = [uri: "${data.baseUrl}?token=${token}",
					 body: new groovy.json.JsonBuilder(reqBody).toString(),
					 contentType: "application/json",
					 requestContentType: "application/json",
					 timeout: 10,
					 headers: ["Cookie": data.cookie]]
	asynchttpPost("parseAesResp", reqParams, [data: data])
}

def parseAesResp(resp, data) {
	Map logData = [method: "parseAesResp"]
	if (resp.status == 200) {
		try {
			Map cmdResp = new JsonSlurper().parseText(
				aesDecrypt(resp.json.result.response, data.data.encKey, data.data.encIv))
			logData << [status: "OK", cmdResp: cmdResp]
			if (cmdResp.error_code == 0) {
				smartAddToDevices(data.data.devData, cmdResp.result.responses)
				logDebug(logData)
			} else {
				logData << [status: "errorInCmdResp"]
				log.warn logData 
			}
		} catch (err) {
			logData << [status: "deviceDataParseError", error: err, dataLength: resp.data.length()]
			log.warn logData 
		}
	} else {
		logData << [status: "httpFailure", data: resp.properties]
		log.warn logData 
	}
}

//	Cameras and Vacuums will only be called if appType() == Tapo
def sendCameraDataCmd(devData, camCmdIn) {
	List requests = [[method:"getDeviceInfo", params:[device_info:[name:["basic_info"]]]],
					 [method:"getAppComponentList", params:[app_component:[name:"app_component_list"]]]]
	Map cmdBody = [method: "multipleRequest", params: [requests: requests]]
	def cmdStr = JsonOutput.toJson(cmdBody)
	Map reqBody = [method: "securePassthrough",
				   params: [request: aesEncrypt(cmdStr, camCmdIn.lsk, camCmdIn.ivb)]]
	String cmdData = new groovy.json.JsonBuilder(reqBody).toString()
	String initTagHex = camCmdIn.encPwd + camCmdIn.cnonce
	String initTag = mdEncode("SHA-256", initTagHex.getBytes()).encodeHex().toString().toUpperCase()
	String tagString = initTag + cmdData + camCmdIn.seqNo
	String tag =  mdEncode("SHA-256", tagString.getBytes()).encodeHex().toString().toUpperCase()
	Map heads = getCamHeaders()
	heads << ["Tapo_tag": tag, Seq: camCmdIn.seqNo]
	Map reqParams = [uri: camCmdIn.apiUrl,
					 body: cmdData,
					 contentType: "application/json",
					 requestContentType: "application/json",
					 timeout: 10,
					 ignoreSSLIssues: true,
					 headers: heads
					]
	asynchttpPost("parseCameraResp", reqParams, [data: [devData: devData, camCmdIn: camCmdIn]])
}

def parseCameraResp(resp, data) {
	Map logData = [method: "parseCameraResp", ip: data.data.devData.ip]
	if (resp.json.error_code == 0) {
		resp = resp.json
		try {
			def clearResp = aesDecrypt(resp.result.response, data.data.camCmdIn.lsk,
									   // library marker davegut.appTpLinkSmart, line 373
									   data.data.camCmdIn.ivb)
			Map cmdResp =  new JsonSlurper().parseText(clearResp) // library marker davegut.appTpLinkSmart, line 375
			logData << [status: "OK"]
			if (cmdResp.error_code == 0) {
				addToDevices(data.data.devData, cmdResp.result.responses)
               logDebug(logData)
			} else {
				logData << [status: "errorInCmdResp", cmdResp: cmdResp] // library marker davegut.appTpLinkSmart, line 381
				logWarn(logData)
			}
		} catch (err) {
			logData << [status: "decryptDataError", error: err]
			logWarn(logData)
		}
	} else {
		logData << [status: "rerurnDataErrorCode", resp: resp]
		logWarn(logData)
	}
}

def sendVacAesDataCmd(token, data) {
	Map devData = data.data.devData
	Map reqParams = getVacAesParams(getDataCmd(), "${data.data.baseUrl}/?token=${token}")
	asynchttpPost("parseVacAesResp", reqParams, [data: devData])
}

def parseVacAesResp(resp, devData) {
	Map logData = [parseMethod: "parseVacAesResp"]
	try {
		Map cmdResp = resp.json
		logData << [status: "OK", cmdResp: cmdResp]
			if (cmdResp.error_code == 0) {
				addToDevices(devData.data, cmdResp.result.responses)
				logDebug(logData)
			} else {
				logData << [status: "errorInCmdResp"]
				logWarn(logData)
			}
	} catch (err) {
		logData << [status: "deviceDataParseError", error: err, dataLength: resp.data.length()]
		logWarn(logData)
	}
	return parseData
}

//	===== Support device data update request =====
def smartCheckForDevices(timeout = 5) {
	Map logData = [:]
	def checked = true
	if (state.smartChecked == true) {
		logData << [status: "noCheck", reason: "Completed within last 10 minutes"]
	} else {
		findDevices("parseSmartCheck", smartCmd(), "20002", 5)
		logData << [status: "checking"]
		state.smartChecked = true
		runIn(600, resetSmartChecked)
	}
	logDebug("smartCheckForDevices: ${logData}")
log.trace "smartCheckForDevices: ${logData}"
	return checked
}

def resetSmartChecked() { state.smartChecked = false }

def parseSmartCheck(response) {
	unschedule("udpTimeout")
	def status
	if (response instanceof Map) {
		 status = getSmartDiscData(response, "check")
	} else {
		response.each {
			status = getSmartDiscData(it, "check")
		}
	}
	state.smartChecked = true
	runIn(600, resetSmartChecked)
}

def updateSmartDevice(payload) {
	String dni = payload.mac.replaceAll("-", "")
	def isChild = getChildDevice(dni)
	if (isChild) {
		String protocol = payload.mgt_encrypt_schm.encrypt_type
		String port = payload.mgt_encrypt_schm.http_port
		String httpStr = "http://"
		String httpPath = "/app"
		if (payload.mgt_encrypt_schm.is_support_https) { httpStr = "https://" }
		if (payload.device_type == devType == "SMART.TAPOHUB" || devType == "SMART.KASAHUB") {
			port = "443"
		} else if (devType == "SMART.TAPOROBOVAC" && protocol == "AES") {
			httpPath = ""
			protocol = "vacAes"
		}
		Map devData = [devIp: payload.ip, protocol: protocol,
					   baseUrl: httpStr + devIp + ":" + port + httpPath]
		updateChild(dni, devData)
	}
	return
}
