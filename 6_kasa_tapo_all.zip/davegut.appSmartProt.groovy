library (
	name: "appSmartProt",
	namespace: "davegut",
	author: "Dave Gutheinz",
	description: "Smart Protocol (KLAP/AES) metnods for Kasa/Tapo application.",
	category: "utilities",
	documentationLink: ""
)
import groovy.json.JsonOutput

def createSmartCreds() {
	String encUsername = mdEncode("SHA-1", userName.bytes).encodeHex().encodeAsBase64().toString()
	app?.updateSetting("encUsername", [type: "string", value: encUsername])
	String encPassword = userPassword.trim().bytes.encodeBase64().toString()
	app?.updateSetting("encPassword", [type: "string", value: encPassword])
	//	KLAP Local Hash
	byte[] userHashByte = mdEncode("SHA-1", encodeUtf8(userName).getBytes())
	byte[] passwordHashByte = mdEncode("SHA-1", encodeUtf8(userPassword.trim()).getBytes())
	byte[] authHashByte = [userHashByte, passwordHashByte].flatten()
	String authHash = mdEncode("SHA-256", authHashByte).encodeBase64().toString()
	app?.updateSetting("localHash", [type: "string", value: authHash])
	logDebug("createSmartCreds: Created credeitial settings")
	return
}

def getSmartLanData(response) {
	unschedule("udpTimeout")
	Integer addedDevs = 0
	def status
	if (response instanceof Map) {
		status = getSmartDiscData(response)
		if (status == "added") { addedDevs += 1 }
	} else {
		response.each {
			status = getSmartDiscData(it)
			if (status == "added") { addedDevs += 1 }
		}
	}
	pauseExecution(addedDevs * 500)
	Map logData = [responses: response.size(), devsToValidate: addedDevs]
	log.info "getSmartLanData: ${logData}"
	atomicState.finding = false
}

def getSmartDiscData(response) {
	def resp = parseLanMessage(response.description)
	String status = "unknownError"
	if (resp.type == "LAN_TYPE_UDPCLIENT") {
		String ip = convertHexToIP(resp.ip)
		String port = convertHexToInt(resp.port)
		byte[] payloadByte = hubitat.helper.HexUtils.hexStringToByteArray(resp.payload.drop(32)) 
		String payload = new String(payloadByte)
		if (payload.length() >= 1007) { payload = udpStringCorrect(payload) }
		try {
			Map cmdResp = new JsonSlurper().parseText(payload).result
			status = getSmartDeviceData(cmdResp, ip, port)
		} catch (err) {
			status = "jsonSlurper error"
			Map logData = [status: status, payload: payload, error: err]
			log.warn "getSmartDiscData: ${logData}"
		}
	} else {
		status = "notLanUdpClient error"
		Map logData = [status: status, error: "not LAN_TYPE_UDPCLIENT"]
		log.warn "getSmartDiscData: ${logData}"
	}
	return status
}

def getSmartDeviceData(payload, ip, port) {
	Map devData = [:]
	String devType = payload.device_type
	String model = payload.device_model
	String protocol = payload.mgt_encrypt_schm.encrypt_type
	String status = "added"
	if (isTypeSup(devType, model) == false) {
		Map unDev = atomicState.unsupported
		Map unsupData = ["${ip}": [type: devType, model: model, protocol: protocol]]
		unDev << unsupData
		atomicState.unsupported = unDev
		unsupData << [status: "deviceType or protocol not supported"]
		status = "notSupported"
		log.info "getSmartDiscData: ${unsupData}"
	} else {
		String dni = payload.mac.replaceAll("-", "")
		String httpPort = payload.mgt_encrypt_schm.http_port
		String httpStr = "http://"
		String httpPath = "/app"
		if (payload.mgt_encrypt_schm.is_support_https) { httpStr = "https://" }
		String baseUrl = httpStr + ip + ":" + httpPort + httpPath
		devData << [type: devType, model: model, baseUrl: baseUrl, dni: dni, 
					ip: ip, port: port, protocol: protocol, status: "OK"]
		if (payload.power) { devData << [power: payload.power] }
		if (devData.protocol == "KLAP") {
			klapHandshake(devData.baseUrl, localHash, devData)
		} else if (devData.protocol == "AES") {
			aesHandshake(devData.baseUrl, devData)
		} else { 
			unknownProt(devData)
		}
		pauseExecution(1000)
		Map logData = [added: [model: model, ip: ip, protocol: protocol]]
		logDebug("getSmartDiscData: ${logData}")
	}
	return status
}

def isTypeSup(devType, model) {
	//	Validated device types
	List supTypes = ["SMART.TAPOBULB", "SMART.TAPOPLUG", "SMART.TAPOSWITCH",
					 "SMART.KASAPLUG", "SMART.KASASWITCH", "SMART.KASABULB"]
	def supported = false
	if (supTypes.contains(devType)) { supported = true }
	if (model.contains("H200") || model.contains("H500")) { supported = false }
	return supported
}

def getSmartDataCmd() {
	List requests = [[method: "get_device_info"], [method: "component_nego"]]
	Map cmdBody = [method: "multipleRequest", params: [requests: requests]]
	return cmdBody
}

def smartAddToDevices(devData, cmdData) {
	String dni = devData.dni
	Map devicesData = atomicState.devices
	String tpType = devData.type
	String baseUrl = devData.baseUrl
	comps = cmdData.find { it.method == "component_nego" }
	comps = comps.result.component_list
	cmdResp = cmdData.find { it.method == "get_device_info" }
	cmdResp = cmdResp.result
	byte[] aliasBytes = cmdResp.nickname.decodeBase64()
	String alias = new String(aliasBytes)
//	Exclue matter devices here.
	if (instMatter == false && comps.find {it.id == "matter"}) {
//		Map unDev = atomicState.unsupported
		Map unsupData = ["${devData.ip}": [type: tpType, model: devData.model, protocol: "MATTER"]]
//		unDev << unsupData
//		atomicState.unsupported = unDev
		unsupData << [status: "Matter install not selected."]
		log.info "smartAddToDevices: ${unsupData}"
		return
	}
	if (alias == "") { alias = devData.model }
	def type = "Unknown"
	def ctHigh
	def ctLow
	Map deviceData = [devIp: devData.ip, devPort: devData.port, deviceType: tpType, protocol: devData.protocol,
					  model: devData.model, baseUrl: baseUrl, alias: alias]
	if (tpType.contains("PLUG") || tpType.contains("SWITCH")) {
		type = "TpLink Plug"
		if (comps.find { it.id == "control_child" }) {
			type = "TpLink Parent"
		} else if (comps.find{it.id=="dimmer"} || comps.find{it.id=="brightness"}) {
			type = "TpLink Dimmer"
		}
	} else if (tpType.contains("BULB")) {
		type = "TpLink Dimmer"
		if (comps.find { it.id == "light_strip" }) {
			type = "TpLink Lightstrip"
		} else if (comps.find { it.id == "color" }) {
			type = "TpLink Color Bulb"
		}
		if (type != "TpLink Dimmer" && comps.find { it.id == "color_temperature" } ) {
			deviceData << [ctHigh: cmdResp.color_temp_range[1], ctLow: cmdResp.color_temp_range[0]]
		}
	}
	deviceData << [type: type]
	if (comps.find {it.id == "led"} ) { 
		String ledVer = comps.find {it.id == "led"}.ver_code
		if (ledVer == null) {
			ledVer = comps.find { it.name == "led" }.version
		}
		deviceData << [ledVer: ledVer]
	}
	if (comps.find {it.id == "energy_monitoring"}) { deviceData << [isEm: "true"] }
	if (comps.find {it.id == "on_off_gradually"}) { deviceData << [gradOnOff: "true"] }
	devicesData << ["${dni}": deviceData]
	atomicState.devices = devicesData
	Map logData = ["${alias}": [model: deviceData.model, protocol: protocol]]
	logDebug("smartAddToDevices: ${logData}")
	updateChild(dni, deviceData)
}

//	===== get Smart KLAP Protocol Data =====
def sendKlapDataCmd(handshakeData, data) {
	if (handshakeData.respStatus != "Login OK") {
		Map logData = [handshake: handshakeData, data: data]
		log.warn "sendKlapDataCmd: ${logData}"
	} else {
		def seqNo = data.data.seqNo + 1
		String cmdBodyJson = new groovy.json.JsonBuilder(getSmartDataCmd()).toString()
		Map encryptedData = klapEncrypt(cmdBodyJson.getBytes(), data.data.encKey, 
										data.data.encIv, data.data.encSig, seqNo)
		Map reqParams = [
			uri: "${data.data.devData.baseUrl}/request?seq=${encryptedData.seqNumber}",
			body: encryptedData.cipherData,
			ignoreSSLIssues: true,
			timeout:10,
			contentType: "application/octet-stream",
			requestContentType: "application/octet-stream",
			headers: ["Cookie": data.data.cookie]
		]
		asynchttpPost("parseKlapResp", reqParams, [data: data])
	}
}

def parseKlapResp(resp, respData) {
	Map data = respData.data
	Map logData = [method: "parseKlapResp", ip: data.data.devData.ip, model: data.data.devData.model]
	if (resp.status == 200) {
		Map cmdResp = [:]
		try {
			byte[] cipherResponse = resp.data.decodeBase64()[32..-1]
			def clearResp = klapDecrypt(cipherResponse, data.data.encKey,
									data.data.encIv, data.data.seqNo + 1)
			cmdResp =  new JsonSlurper().parseText(clearResp)
			logData << [status: "OK"]
		} catch (err) {
			logData << [error: err, errTxt: "error decyphering response"]
			log.warn logData 
			return
		}
		if (cmdResp.error_code == 0) {
			smartAddToDevices(data.data.devData, cmdResp.result.responses)
			logDebug(logData)
		} else {
			logData << [status: "errorInCmdResp", cmdResp: cmdResp]
			log.warn logData 
		}
	} else {
		logData << [status: "httpFailure", data: resp.properties]
		log.warn logData 
	}
}

//	===== get Smart AES Protocol Data =====
def getAesToken(resp, data) {
	Map logData = [method: "getAesToken"]
	if (resp.status == 200) {
		if (resp.json.error_code == 0) {
			try {
				def clearResp = aesDecrypt(resp.json.result.response, data.encKey, data.encIv)
				Map cmdResp = new JsonSlurper().parseText(clearResp)
				if (cmdResp.error_code == 0) {
					def token = cmdResp.result.token
					logData << [respStatus: "OK", token: token]
					logDebug(logData)
					sendAesDataCmd(token, data)
				} else {
					logData << [respStatus: "ERROR code in cmdResp", 
								error_code: cmdResp.error_code,
								check: "cryptoArray, credentials", data: cmdResp]
					log.warn logData 
				}
			} catch (err) {
				logData << [respStatus: "ERROR parsing respJson", respJson: resp.json,
							error: err]
				log.warn logData 
			}
		} else {
			logData << [respStatus: "ERROR code in resp.json", errorCode: resp.json.error_code,
						respJson: resp.json]
			log.warn logData 
		}
	} else {
		logData << [respStatus: "ERROR in HTTP response", respStatus: resp.status, data: resp.properties]
		log.warn logData 
	}
}

def sendAesDataCmd(token, data) {
	def cmdStr = JsonOutput.toJson(getSmartDataCmd()).toString()
	Map reqBody = [method: "securePassthrough",
				   params: [request: aesEncrypt(cmdStr, data.encKey, data.encIv)]]
	Map reqParams = [uri: "${data.baseUrl}?token=${token}",
					 body: new groovy.json.JsonBuilder(reqBody).toString(),
					 contentType: "application/json",
					 requestContentType: "application/json",
					 timeout: 10,
					 headers: ["Cookie": data.cookie]]
	asynchttpPost("parseAesResp", reqParams, [data: data])
}

def parseAesResp(resp, data) {
	Map logData = [method: "parseAesResp"]
	if (resp.status == 200) {
		try {
			Map cmdResp = new JsonSlurper().parseText(
				aesDecrypt(resp.json.result.response, data.data.encKey, data.data.encIv))
			logData << [status: "OK", cmdResp: cmdResp]
			if (cmdResp.error_code == 0) {
				smartAddToDevices(data.data.devData, cmdResp.result.responses)
				logDebug(logData)
			} else {
				logData << [status: "errorInCmdResp"]
				log.warn logData 
			}
		} catch (err) {
			logData << [status: "deviceDataParseError", error: err, dataLength: resp.data.length()]
			log.warn logData 
		}
	} else {
		logData << [status: "httpFailure", data: resp.properties]
		log.warn logData 
	}
}

//	===== Support device data update request =====
def smartCheckForDevices(timeout = 5) {
	Map logData = [:]
	def checked = true
	if (state.smartChecked == true) {
		logData << [status: "noCheck", reason: "Completed within last 10 minutes"]
	} else {
		if (userName && userPassword) {
			findDevices("parseSmartCheck", smartCmd(), "20002", 5)
			state.smartChecked = true
			runIn(600, resetSmartChecked)
		}
	}
	logDebug("smartCheckForDevices: ${logData}")
	return checked
}

def resetSmartChecked() { state.smartChecked = false }

def parseSmartCheck(response) {
	unschedule("udpTimeout")
	if (response instanceof Map) {
		getSmartCheckData(response)
	} else {
		response.each {
			getSmartCheckData(it)
		}
	}
	atomicState.finding = false
}

def getSmarCheckData(response) {
	def resp = parseLanMessage(response.description)
	if (resp.type == "LAN_TYPE_UDPCLIENT") {
		String ip = convertHexToIP(resp.ip)
		String port = convertHexToInt(resp.port)
		byte[] payloadByte = hubitat.helper.HexUtils.hexStringToByteArray(resp.payload.drop(32)) 
		String payload = new String(payloadByte)
		if (payload.length() >= 1007) { payload = udpStringCorrect(payload) }
		try {
			Map cmdResp = new JsonSlurper().parseText(payload).result
			updateSmartDevice(cmdResp, ip, port)
		} catch (err) {
			Map logData = [status: "jsonSlurper error", payload: payload, error: err]
			log.warn "getSmartDiscData: ${logData}"
		}
	} else {
		Map logData = [status: status, "notLanUdpClient error": "not LAN_TYPE_UDPCLIENT"]
		log.warn "getSmartDiscData: ${logData}"
	}
}

def updateSmartDevice(cmdResp, ip, port) {
	String dni = cmdResp.mac.replaceAll("-", "")
	def isChild = getChildDevice(dni)
	if (isChild) {
		String protocol = cmdResp.mgt_encrypt_schm.encrypt_type
		String httpStr = "http://"
		String httpPath = "/app"
		String httpPort = payload.mgt_encrypt_schm.http_port
		if (cmdResp.mgt_encrypt_schm.is_support_https) { httpStr = "https://" }
		String baseUrl = httpStr + devIp + ":" + httpPort + httpPath
		Map device = [devIp: ip, protocol: protocol, devPort: port, baseUrl: baseUrl]
		updateChild(dni, devData)
	}
}
