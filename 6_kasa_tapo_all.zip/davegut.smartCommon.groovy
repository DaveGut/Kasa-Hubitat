library (
	name: "smartCommon",
	namespace: "davegut",
	author: "Compied by Dave Gutheinz",
	description: "Common methods library for Kasa/Tapo and Tapo SMART protocol drivers.",
	category: "utilities",
	documentationLink: ""
)
capability "Refresh"
attribute "commsError", "string"

def commonPreferences() {
	List pollOptions = ["5 sec", "10 sec", "1 min", "5 min", "15 min", "30 min"]
	input ("pollInterval", "enum", title: "Poll Interval",
		   options: pollOptions, defaultValue: "30 min")
	if (getDataValue("ledVer")) {
		input ("ledRule", "enum", title: "LED Mode",
			   options: ["always", "never"], defaultValue: "always")
	}
	input ("rebootDev", "bool", title: "Reboot Device", defaultValue: false)
	input ("syncName", "enum", title: "Update Device Names and Labels", 
		   options: ["hubMaster", "tapoAppMaster", "notSet"], defaultValue: "notSet")
	input ("logEnable", "bool",  title: "Enable debug logging for 30 minutes", defaultValue: false)
	input ("infoLog", "bool", title: "Enable information logging",defaultValue: true)
}

def commonInstalled() {
	Map logData = [method: "commonInstalled"]
	updateAttr("commsError", "false")
	state.errorCount = 0
	state.seqNo = 0
	logData << [configure: configure()]
	runIn(2, updated)
	return logData
}

def commonUpdated() {
	unschedule()
	sendEvent(name: "commsError", value: "false")
	state.errorCount = 0
	Map logData = [commsError: "cleared"]
	if (rebootDev == true) {
		List requests = [[method: "device_reboot"]]
		sendDevCmd(requests, "rebootDevice", "parseUpdates") 
		logData << [rebootDevice: "device reboot being attempted"]
	} else {
		runEvery3Hours(deviceHandshake)
		logData << [handshakeInterval: "3 Hours"]
		logData << [pollInterval: setPollInterval()]
		logData << [logging: setLogsOff()]
		logData << [updateDevSettings: updDevSettings()]
		runIn(2, refresh)
		if (getDataValue("isEm") == "true") {
			runIn(7, emUpdated)
		}
	}
	return logData
}

def finishReboot(respData) {
	Map logData = [method: "finishReboot", respData: respData]
	logData << [wait: "<b>20s for device to reconnect to LAN</b>", action: "executing deviceHandshake"]
	device.updateSetting("rebootDev",[type:"bool", value: false])
	runIn(20, configure)
	logDebug(logData)
}

def updDevSettings() {
	List requests = []
	if (syncName == "hubMaster") {
		String nickname = device.getLabel().bytes.encodeBase64().toString()
		requests << [method: "set_device_info", params: [nickname: nickname]]
	}
	if (ledRule) {
		requests << [method: "get_led_info"]
	}
	if (getDataValue("isEm") == "true") {
		requests << [method: "get_energy_usage"]
	}
	requests << [method: "get_device_info"]
	sendDevCmd(requests, "updateDevSettings", "parseUpdates")
	return "Updated"
}

def setPollInterval(pInterval = pollInterval) {
	if (pInterval.contains("sec")) {
		logWarn("<b>Poll intervals of less than 1 minute may overload the Hub</b>")
		def interval = pInterval.replace(" sec", "").toInteger()
		def start = Math.round((interval-1) * Math.random()).toInteger()
		schedule("${start}/${interval} * * * * ?", "refresh")
	} else {
		def interval= pInterval.replace(" min", "").toInteger()
		def start = Math.round(59 * Math.random()).toInteger()
		schedule("${start} */${interval} * * * ?", "refresh")
	}
	return pInterval
}

//	===== Data Distribution (and parse) =====
def parseUpdates(resp, data = null) {
	Map logData = [method: "parseUpdates", data: data]
	def respData = parseData(resp, getDataValue("protocol"), data)
	if (resp.status == 200 && respData.cryptoStatus == "OK") {
		def cmdResp = respData.cmdResp.result.responses
		if (respData.cmdResp.result.responses != null) {
			respData.cmdResp.result.responses.each {
				if (it.error_code == 0) {
					distGetData(it, data)
				} else {
					logData << ["${it.method}": [status: "cmdFailed", data: it]]
					logDebug(logData)
				}
			}
		}
		if (respData.cmdResp.result.responseData != null) {
			respData.cmdResp.result.responseData.result.responses.each {
				if (it.error_code == 0) {
					distChildGetData(it, data)
				} else {
					logData << ["${it.method}": [status: "cmdFailed", data: it]]
					logDebug(logData)
				}
			}
		}
	} else {
		logData << [errorMsg: "Misc Error"]
		logDebug(logData)
	}
}

def distGetData(devResp, data) {
	switch(devResp.method) {
		case "get_device_info":
			parse_get_device_info(devResp.result, data)
			parseNameUpdate(devResp.result)
			break
		case "get_current_power":
			parse_get_current_power(devResp.result, data)
			break
		case "get_device_usage":
			parse_get_device_usage(devResp.result, data)
			break
		case "get_child_device_list":
			parse_get_child_device_list(devResp.result, data)
			break
		case "get_alarm_configure":
			parse_get_alarm_configure(devResp.result, data)
			break
		case "get_led_info":
			parse_get_led_info(devResp.result, data)
			break
		case "device_reboot":
			finishReboot(devResp)
			break
		//	RoboVac
		case "getBatteryInfo":
			parse_getBatteryInfo(devResp.result, data)
			break
		case "getCleanNumber":
			parse_getCleanNumber(devResp.result, data)
			break
		case "getSwitchClean":
			parse_getSwitchClean(devResp, data)
			break
		case "getMopState":
			parse_getMopState(devResp, data)
			break
		case "getSwitchCharge":
			updateAttr("docking", devResp.switch_charge, data)
			break
		case "getVacStatus":
			parse_getVacStatus(devResp.result, data)
			break
		case "getMapInfo":
			parse_getMapInfo(devResp.result, data)
			break
		case "getMapData":
			parse_getMapData(devResp.result, data)
			break
		case "getLastAlarmInfo": 
			parse_getLastAlarmInfo(devResp.result, data)
			break
		default:
			if (!devResp.method.contains("set_")) {
				Map logData = [method: "distGetData", data: data,
							   devMethod: devResp.method, status: "unprocessed"]
				logDebug(logData)
			}
	}
}

def parse_get_led_info(result, data) {
	Map logData = [method: "parse_get_led_info", data: data]
	if (ledRule != result.led_rule) {
		Map request = [
			method: "set_led_info",
			params: [
				led_rule: ledRule]]
		asyncSend(request, "delayedUpdates", "parseUpdates")
		device.updateSetting("ledRule", [type:"enum", value: ledRule])
		logData << [status: "updatingLedRule"]
	}
	logData << [ledRule: ledRule]
	logDebug(logData)
}

def parseNameUpdate(result) {
	if (syncName != "notSet") {
		Map logData = [method: "parseNameUpdate"]
		byte[] plainBytes = result.nickname.decodeBase64()
		def newLabel = new String(plainBytes)
		device.setLabel(newLabel)
		device.updateSetting("syncName",[type:"enum", value: "notSet"])
		logData << [label: newLabel]
		logDebug(logData)
	}
}

//	===== Capability Refresh =====
def refresh() {
	def type = getDataValue("type")
	List requests = [[method: "get_device_info"]]
	if (type == "Hub" || type == "Parent") {
		requests << [method:"get_child_device_list"]
	}
	if (getDataValue("isEm") == "true") {
		requests << [method: "get_current_power"]
	}
	if (type == "Robovac") {
		requests = [[method: "getBatteryInfo"],
					[method: "getCleanNumber"],
					[method: "getSwitchClean"],
					[method: "getVacStatus"],
					[method: "getMopState"],
					[method: "getSwitchCharge"]]
	}
	sendDevCmd(requests, "refresh", "parseUpdates")
}

def plugEmRefresh() { refresh() }
def parentRefresh() { refresh() }
def minRefresh() { refresh() }

def sendDevCmd(requests, data, action) {
	Map cmdBody = [
		method: "multipleRequest",
		params: [requests: requests]]
	asyncSend(cmdBody, data, action)
}

def nullParse(resp, data) { }
