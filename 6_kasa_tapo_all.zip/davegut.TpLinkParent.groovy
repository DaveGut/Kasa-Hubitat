/*	Kasa/Tapo Integration Driver: TpLink Parent
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md
=====  Driver Notes  =====
1.	Supports Tapo Parents (Hubs and multi-plugs/switches)
===== */

metadata {
	definition (name: "TpLink Parent", namespace: nameSpace(), author: "Dave Gutheinz", 
				singleThreaded: true,
				importUrl: "https://raw.githubusercontent.com/DaveGut/tpLink_Hubitat/main/Drivers/tpLink_parent.groovy")
	{
	}
	preferences {
		commonPreferences()
		input ("installChild", "bool", title: "Install Child Devices", defaultValue: true)
	}
}

def installed() {
	Map logData = [method: "installed", commonInstalled: commonInstalled()]
	logInfo(logData)
}

def updated() { 
	Map logData = [method: updated, installChild: installChild,
				   commonUpdated: commonUpdated()]
	if (installChild) {
		runIn(5, installChildDevices)
		pauseExecution(5000)
	}
	logInfo(logData)
}

def parse_get_device_info(result, data) {
	Map logData = [method: "parse_get_device_info", data: data]
	logDebug(logData)
}

//	===== Include Libraries =====
#include davegut.smartCapEngMon
#include davegut.smartCapConfiguration
#include davegut.smartCommon
#include davegut.smartParentCommon
#include davegut.smartComms
#include davegut.smartCrypto
#include davegut.smartTransAes
#include davegut.smartTransKlap
#include davegut.iotSmartCommon
