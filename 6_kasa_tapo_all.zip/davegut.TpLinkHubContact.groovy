/*	TP-Link TAPO plug, switches, lights, hub, and hub sensors.
		Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md 
=================================================================================================*/
metadata {
	definition (name: "TpLink Hub Contact", namespace: nameSpace(), author: "Dave Gutheinz", 
				importUrl: "https://raw.githubusercontent.com/DaveGut/tpLink_Hubitat/main/Drivers/tpLink_hub_contact.groovy")
	{
		capability "Contact Sensor"
		attribute "lowBattery", "string"
		capability "Sensor"
	}
	preferences {
		commonPreferences()
	}
}

def installed() { runIn(1, updated) }

def updated() {
	Map logData = [method: "updated", commonUpdated: commonUpdated()]
	logInfo(logData)
}

def parse_get_device_info(result, data = null) {
	Map logData = [method: "parse_get_device_info"]
	def contact = "closed"
	if (result.open) { contact = "open" }
	updateAttr("contact", contact)
	updateAttr("lowBattery", result.at_low_battery.toString())
	logData = [contact: contact]
	logDebug(logData)
}

#include davegut.smartChildCommon
#include davegut.iotSmartCommon
