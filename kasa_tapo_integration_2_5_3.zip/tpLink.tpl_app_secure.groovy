library ( 
	name: "tpl_app_secure",
	namespace: "tpLink",
	author: "Dave Gutheinz",
	description: "Smart Protocol (KLAP/AES) metnods for Kasa/Tapo application. Hub V 2.5.3",
	category: "utilities",
	documentationLink: ""
)

void getSecureLanData(response) {
	unschedule("udpTimeout")
	Map logData = [method: "getSecureLanData"]
	if (response == "udpTimeout") {
		logData << [response: "udpTimeout", warning: "No devices found"]
	} else {
		logData << [responses: response.size()]
		if (response instanceof Map) {
    		atomicState.deviceWait = true
    		getSecureDiscData(response)
    		def wait = waitForDevData(5)
		} else {
			response.each {
				atomicState.deviceWait = true
				getSecureDiscData(it)
				def wait = waitForDevData(5)
			}
		}
	}
	atomicState.findingSecure = false
	logInfo(logData)
}

void getSecureDiscData(response) {
	Map discData = parseUdp(response, "secure")
	if (discData.status == "ok") {
		Map payload = discData?.cmdResp?.result
		Map encryptScheme = payload?.mgt_encrypt_schm
		if (!payload?.mac || !payload?.device_type 
			|| !encryptScheme?.encrypt_type || !encryptScheme?.http_port) {
			atomicState.deviceWait = false
			logDebug("getSecureDiscData: " + 
				"[status: invalidDiscoveryPayload, " + 
				"ip: ${discData?.ip}, payload: ${payload}]")
			return
		}
		String model = payload.device_model
		String protocol = payload.mgt_encrypt_schm.encrypt_type.toLowerCase()
		//	Handle prefer_tpap = true by hard coding tpap to klap.
		if (protocol == "tpap") { protocol = "klap" }
		String devType = payload.device_type
		String dni = payload.mac.replaceAll("-", "")
		Map logData =[method: "getSecureDiscData", devType: devType, model: model, 
					  dni: dni, protocol: protocol]
		List supTypes = ["SMART.TAPOBULB", "SMART.TAPOPLUG", "SMART.TAPOSWITCH",
					 	"SMART.KASAPLUG", "SMART.KASASWITCH", "SMART.KASABULB",
						 "IOT.SMARTPLUGSWITCH", "IOT.SMARTBULB"]
		if (!supTypes.contains(devType)) {
			logData << [status: "Ignored. Unsupported device."]
			logInfo(logData)
			atomicState.deviceWait = false
		} else if (atomicState.iotDevices?.containsKey(dni) 
				   && getChildDevice(dni)) {
			//	Design to preclude unnecessary processing and also device protocol
			//	ping-pong. For Smart devices, if it has already been found on this 
			//	application session, do not add.
			logData << [status: "Ignored! Found in iotDevices and already installed."]
			logInfo(logData)
			atomicState.deviceWait = false
		} else if (atomicState.smartDevices?.containsKey(dni)) {
			logData << [status: "Ignored. Aready in state.smartDevices."]
			logInfo(logData)
			atomicState.deviceWait = false
		} else {
			Map devData = [:]
			def api = "smart"
			if (devType.contains("IOT")) { api = "iot" }
			String httpPort = payload.mgt_encrypt_schm.http_port
			String httpStr = "http://"
			String httpPath = "/app"
			if (payload.mgt_encrypt_schm.is_support_https) { httpStr = "https://" }
			String baseUrl = httpStr + discData.ip + ":" + httpPort + httpPath
			devData << [type: devType, model: model, baseUrl: baseUrl, dni: dni,
						api: api, protocol: protocol]
			if (devData.protocol == "klap") {
				klapHandshake(baseUrl, localHash, devData)
			} else if (devData.protocol == "aes") {
				aesHandshake(baseUrl, devData)
			} else {
				atomicState.deviceWait = false
				logData << [status: "unsupportedProtocol: ${devData.protocol}"]
				logInfo(logData)
			}
		}
	} else {
		atomicState.deviceWait = false
		Map logData = [method: "getSecureDiscData", status: "errorInParseUDP", discData: discData]
		logDebug(logData)
	}
}

void getSmartDeviceData(devData, cmdData) {
	Map logData = [method: "getSmartDeviceData"]
	Map device = [api: "smart", protocol: devData.protocol, baseUrl: """${devData.baseUrl}""",
				  model: devData.model]
	Map componentResponse = cmdData?.find { it.method == "component_nego" }
	Map deviceInfoResponse = cmdData?.find { it.method == "get_device_info" }
	List comps = componentResponse?.result?.component_list ?: []
	Map cmdResp = deviceInfoResponse?.result
	if (!cmdResp) {
		atomicState.deviceWait = false
		logDebug("getSmartDeviceData: [status: missingDeviceInfo]")
		return
	}
	
	def dni = devData.dni
	byte[] aliasBytes = cmdResp.nickname.decodeBase64()
	String alias = new String(aliasBytes)
	if (!(instMatter ?: false) && comps.find {it.id == "matter"}) {
		logData << ["${alias}": device, status: "Not added. Matter Install Not Selected"]
		atomicState.deviceWait = false
	} else {
		def tpType = devData.type
		if (alias == "") { alias = devData.model }
		String manufacturer = "tapo"
		if (tpType.contains("KASA")) { manufacturer = "kasa" }
		device << [alias: alias, manufacturer: manufacturer, deviceId: cmdResp.device_id]
		def type = "unknown"
		if (tpType.contains("PLUG") || tpType.contains("SWITCH")) {
			type = "Plug Switch"
			if (comps.find { it.id == "control_child" }) {
				type = "Parent"
			} else if (comps.find{it.id=="dimmer"} || comps.find{it.id=="brightness"}) {
				type = "Dimming Switch"
			}
		} else if (tpType.contains("BULB")) {
			type = "Mono Bulb"
			if (comps.find { it.id == "light_strip" }) {
				type = "Light Strip"
			} else if (comps.find { it.id == "color" }) {
				type = "Color Bulb"
			} else if (comps.find { it.id == "color_temperature" } ) {
				type = "CT Bulb"
			}
			
			if (comps.find { it.id == "color_temperature" } ) {
				def ctHigh = 6500
				def ctLow = 2700
				if (cmdResp.color_temp_range) {
					ctHigh = cmdResp.color_temp_range[1]
					ctLow = cmdResp.color_temp_range[0]
				}
				device << [ctHigh: ctHigh, ctLow: ctLow]
			}
		}
		device << [type: type]
		if (comps.find {it.id == "led"}) { device << [hasLed: "true"] }
		if (type != "Parent") {
			if (comps.find {it.id == "energy_monitoring"}) { device << [isEm: "true"] }
			if (comps.find {it.id == "on_off_gradually"}) { device << [gradOnOff: "true"] }
		}
		addDeviceData(dni, device)
	}
	logDebug(logData)
}

void quickFindSecureData(response) {
	unschedule("udpTimeout")
	atomicState.findingSecure = false
	Map logData = [method: "quickFindSecureData"]
	if (response == "udpTimeout") {
		logData << [response: "udpTimeout", status: "No devices found"]
	} else {
		def foundDevs = 0
		if (response instanceof Map) {
			foundDevs += 1
			def respData = parseUdp(response, "smart")
			updateSecureChild(respData)
		} else {
			response.each {
				foundDevs +=1
				def respData = parseUdp(it, "smart")
				updateSecureChild(respData)
			}
		}
		logData << [devicesFound: foundDevs, status: "allSentToParse"]
	}
	logInfo(logData)
}

void updateSecureChild(respData) {
	if (respData.status == "ok") {
		if (respData.status != "ok") {
			logDebug("updateSecureChild: [error: not LAN_TYPE_UDPCLIENT]")
			return 
		} 
		Map payload = respData?.cmdResp?.result 
		Map encryptScheme = payload?.mgt_encrypt_schm 
		if (!payload?.mac || !encryptScheme?.encrypt_type 
			|| !encryptScheme?.http_port) { 
			logDebug("updateSecureChild: [status: invalidDiscoveryPayload]")
			return
		} 
		String protocol = encryptScheme.encrypt_type.toLowerCase() 
		if (protocol == "tpap") { protocol = "klap" }
		String httpPort = payload.mgt_encrypt_schm.http_port
		String httpStr = "http://"
		String httpPath = "/app"
		if (payload.mgt_encrypt_schm.is_support_https) { httpStr = "https://" }
		String baseUrl = httpStr + respData.ip + ":" + httpPort + httpPath
		Map deviceData = [protocol: protocol, baseUrl: baseUrl]
		String dni = payload.mac.replaceAll("-", "")
		def child = getChildDevice(dni)
		if (child) { child.updateDeviceData(deviceData) }
	} else {
		logDebug("updateSecureChild: [error: not LAN_TYPE_UDPCLIENT]")
	}
}

Map getDataCmd(api) {
	Map cmdBody = [:]
	if (api == "iot") {
		cmdBody = [system: [get_sysinfo:[]]]
	} else {
		List requests = [[method: "get_device_info"], [method: "component_nego"]]
		cmdBody = [method: "multipleRequest", params: [requests: requests]]
	}
	return cmdBody
}

//	===== get KLAP Protocol Data =====
void sendKlapDataCmd(devData) {
	Map reqParams = [timeout: 10, headers: ["Cookie": devData.cookie]]
	def seqNo = devData.seqNo + 1
	String cmdBodyJson = new groovy.json.JsonBuilder(getDataCmd(devData.api)).toString()
	Map encryptedData = klapEncrypt(cmdBodyJson.getBytes(), devData.encKey,
									devData.encIv, devData.encSig, seqNo)
	reqParams << [
		uri: "${devData.baseUrl}/request?seq=${encryptedData.seqNumber}",
		body: encryptedData.cipherData,
		timeout:10,
		contentType: "application/octet-stream",
		requestContentType: "application/octet-stream"]
	asynchttpPost("parseKlapResp", reqParams, devData)
}

void parseKlapResp(resp, devData) {
	Map logData = [method: "parseKlapResp", ip: devData.baseUrl, model: devData.model]
	if (resp.status == 200) {
		Map cmdResp = [:]
		try {
			byte[] cipherResponse = resp.data.decodeBase64()[32..-1]
			def clearResp = klapDecrypt(cipherResponse,devData.encKey,
									devData.encIv, devData.seqNo + 1)
			cmdResp =  new JsonSlurper().parseText(clearResp)
			logData << [status: "OK"]
		} catch (err) {
			atomicState.deviceWait = false
			logData << [error: err, errTxt: "error decyphering response"]
			logDebug(logData)
			return
		}
		if (cmdResp?.error_code == 0 && cmdResp?.result?.responses) {
			getSmartDeviceData(devData, cmdResp.result.responses)
		} else if (cmdResp?.system?.get_sysinfo?.err_code == 0) {
			getIotDeviceData(cmdResp, devData.baseUrl, devData.protocol)
		} else {
			atomicState.deviceWait = false
			logData << [status: "errorInCmdResp", cmdResp: cmdResp]
			logDebug(logData)
		}		
	} else {
		atomicState.deviceWait = false
		logData << [status: "httpFailure", data: resp.properties]
		logDebug(logData)
	}
}

//	===== get Smart AES Protocol Data =====
void sendAesDataCmd(Map devData) {
	String cmd = new JsonBuilder(getDataCmd(devData.api)).toString()
	String uri = "${devData.baseUrl}?token=${devData.token}"
	Map reqParams = getAesParams(cmd, devData.encKey, devData.encIv,
								 uri, devData.cookie)
	devData.retry = false
	asynchttpPost("parseAesResp", reqParams, devData)
}

void parseAesResp(resp, devData) {
	Map logData = [method: "parseAesResp", api: devData.api, model: devData.model]
	if (resp.status != 200 || !resp?.json?.result?.response) {
		atomicState.deviceWait = false
		logData << [status: "httpFailure", data: resp.properties]
		logDebug(logData)
		return
	}
	try {
		Map cmdResp = new JsonSlurper().parseText(aesDecrypt(
			resp.json.result.response, devData.encKey, devData.encIv))
		logData << [status: "OK"]
		if (devData.api == "smart" && cmdResp?.error_code == 0 &&
			cmdResp?.result?.responses) {
			getSmartDeviceData(devData, cmdResp.result.responses)
		} else if (devData.api == "iot" &&
				   cmdResp?.system?.get_sysinfo?.err_code == 0) {
			getIotDeviceData(cmdResp, devData.baseUrl, devData.protocol)
		} else {
			atomicState.deviceWait = false
			logData << [ status: "errorInCmdResp", cmdResp: cmdResp]
            logDebug(logData)
		}
	} catch (err) {
		atomicState.deviceWait = false
		logData << [status: "deviceDataParseError", error: err]
		logDebug(logData)
	}
}
