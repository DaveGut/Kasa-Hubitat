/*	Kasa/Tapo Integration Driver: TpLink Parent
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md
*/ 

String nameSpace() { return "davegut" }
String version() { return "2.5.3" }


import groovy.transform.Field
@Field static final String DEV_TYPE = "Parent"
@Field static final Boolean IS_CHILD = false
@Field static final String SYSTEM = "system"

metadata {
	definition (name: "Kasa Parent",
				namespace: nameSpace(), 
				author: "Dave Gutheinz", 
				singleThreaded: true
			   )
	{
	}
	preferences {
		commonPrefs()
		input ("installChild", "bool", title: "Install Child Devices", defaultValue: true)
	}
}

def installed() {
	Map instStatus = [method: "installed"]
	instStatus << commonInstalled()
	logInfo(instStatus)
	deviceHandshake()
	runIn(5, updated)
}

def updated() {
	Map updStatus = [method: "updated"]
	unschedule()
	updStatus << [commonUpdated: commonUpdated()]
	if (installChild) {
		runIn(10, getChildData)
	}
	logInfo(updStatus)
}

void getChildData() {
	if (getDataValue("api") == "smart") {
		getSmartChildData()
	} else {
		getIotChildData()
	}
	logInfo("getChildData: Starting child installation process")
} 

def addChild(devData) {
	Map logData = [:]
	Map deviceData = [label: devData.label, model: devData.model,
					  api: devData.api, firmwareVersion: devData.firmwareVersion, 
					  manufacturer: devData.manufacturer, deviceId: devData.deviceId]
	if (devData.hasLed) { deviceData << [hasLed: devData.hasLed] }
	if (devData.isEm) { deviceData << [isEm: devData.isEm] }
	if (devData.gradOnOff) { deviceData << [gradOnOff: devData.gradOnOff] }
	try {
		addChildDevice(
			nameSpace(), 
			"Kasa ${devData.type}",
			devData.childDni,
			deviceData)
		logData << [status: "deviceAdded"]
	} catch (err) {
		logData << [status: "add child device failed", ERROR: err]
	}
	return logData
}

//	===== Child-Parent Command Queue =====
void processChildCmd(commandData) {
	//	Test version to see how much reduction in proc utilization if no queue.
	if (commandData.api == "smart") {
		sendSmartChildCmd(commandData)
	} else {
		sendIotChildCmd(commandData)
	}
}

//	===== Smart Methods =====
def smartParentRefresh() {
	state.eventType = "digital"
	List requests = [[method:"get_child_device_list"]]
	Map cmdBody = [method: "multipleRequest", params: [requests: requests]]
	sendSmartCmd(cmdBody, true)
}

def smartParentPoll() {
	state.eventType = "manual"
	List requests = [[method:"get_child_device_list"]]
	Map cmdBody = [method: "multipleRequest", params: [requests: requests]]
	sendSmartCmd(cmdBody, false)
}

def parse_get_device_info(result) {
	//	May have some preferences to set here in future
}

def parse_get_child_device_list(result) {
	Map logData = [method: "get_child_device_list"]
	def children = getChildDevices()
	children.each { child ->
		def devId = child.getDataValue("deviceId")
		def childData = result.child_device_list.find{ it.device_id == devId }
		child.parse_get_device_info(childData)
	}
	logData << [status: "OK"]
	logDebug(logData)
}

def getSmartChildData() {
	List requests = [[method: "get_child_device_list"]]
	requests << [method: "get_child_device_component_list"]
	Map cmdBody = [method: "multipleRequest", params: [requests: requests]]
	sendSmartCmd(cmdBody, true, "parseSmartInstData")
}

def parseSmartInstData(resp, data = null) {
	Map logData = [method: "parseSmartResp"]
	Map cmdResp 
	if (data == "httpSync") {
		cmdResp = resp
	} else {
		def respData = parseKlapAesResp(resp)
		cmdResp = respData.cmdResp
	}
	List responses = []
	if (cmdResp.result?.responses) {
		responses = cmdResp.result.responses
	} else if (cmdResp.result?.responseData) {
		responses = respData.cmdResp.result.responseData
	} else {
		log.warn "parseSmartInstData: Response data is malformed. Try rebooting device or Hub."
		return
	}
	List childDeviceList = responses.find {
		it.method == "get_child_device_list"}?.result?.child_device_list ?: []
	List childComponentList = responses.find {
		it.method == "get_child_device_component_list"}?.result?.child_component_list ?: []
	childDeviceList.each { devData ->
		Map compData = childComponentList.find { it.device_id == devData.device_id }
		installSmartChild(devData, compData.component_list)
	}
	device.updateSetting("installChild", [type: "bool", value: "false"])
	logDebug(logData)
}

def installSmartChild(devData, compData) {
	byte[] plainBytes = devData.nickname.decodeBase64()
	String alias = new String(plainBytes)
	String childNo = devData.device_id[-2..-1]
	String childDni = "${devData.mac}${childNo}"
	Map logData = [method: "installSmartChild", alias: alias]
	String type = getDeviceType(devData.category)
	if (getChildDevice(childDni)) {
		logData << [status: "alreadyInstalled"]
	} else if (type == "undefined") {
		logData << [status: "unsupportedDeviceType"]
	} else {
		def model = "${devData.model}-child-${childNo}"
		Map childData = [label: alias, childDni: childDni, api: "smart", type: type, 
						 firmwareVersion: devData.fw_ver, model: model,
						 manufacturer: "Tapo", deviceId: devData.device_id]
		if (compData.find {it.id == "energy_monitoring"}) { childData << [isEm: true] }
		if (compData.find {it.id == "on_off_gradually"}) { childData << [gradOnOff: true] }
		logData << [addDevice: addChild(childData)]
	}
	logInfo(logData)
}

def getDeviceType(category) {
	String deviceType
	switch(category) {
		case "plug.powerstrip.sub-plug":
			deviceType = "Child Plug Switch"
			break
 		case "kasa.switch.outlet.sub-fan":
			deviceType = "Child Fan"
			break
 		case "kasa.switch.outlet.sub-dimmer":
		case "plug.powerstrip.sub-bulb":
			deviceType = "Child Dimming Switch"
			break
		default:
			deviceType = "undefined"
	}
	return deviceType
}

def sendSmartChildCmd(commandData) {
	Map cmd = [method: "control_child",
				   params: [device_id: commandData.devId,
							requestData: commandData.cmdBody]]
//	Insturmentation point for testing	
//log.info "[method: sendSmartChildCmd, cmdBody: $cmdBody, RETRY: $retry]"
	sendSmartCmd(cmd, commandData.retry, "parseSmartChildResp", commandData.dni)
}

def parseSmartChildResp(resp, data) {
	Map logData = [method: "parseSmartChildResp"]
	def respData = parseKlapAesResp(resp)
	if (respData.cmdResp) {
		Map result = respData.cmdResp?.result?.responseData?.result
		if (result != null) {
			def child = getChildDevice(data.dni)
			result.responses.each {
				if (it.error_code == 0) {
					distSmartChildData(it, child)
			} else {
				logData << [devRespError: it]
				log.warn logData
				}
			}
		}
	} else {
		logData << respData
		log.warn logData
		if (data.retry == true && systemPoll.contains("min")) {
			handleCommsError([status: respData.status, cryptoStatus: respData.cryptoStatus])
		}
	}
}

def distSmartChildData(devResp, child) {
	def key = devResp.method
	Map methResp = devResp.result
//	Insturmentation point for testing	
//log.info "[method: distSnartChildData: $key: $devData]"
	logDebug("distSmartChildData: $key, ${methResp}")
	if (key.contains("set_")) { return }
	switch(key) {
		case "get_device_info":
			child.parse_get_device_info(methResp)
			break
		case "get_current_power":
			child.parse_get_current_power(methResp)
			break
		case "get_device_usage":
			child.parse_get_device_usage(methResp)
			break
		case "get_on_off_gradually_info":
			child.parse_get_on_off_gradually_info(methResp)
			break
		default:
			if (!devResp.method.contains("set_")) {
				Map logData = [method: "distGetData", devMethod: devResp.method, 
							   status: "unprocessed"]
				logDebug(logData)
		}
	}
}

//	===== IOT Methods =====
def parse_system(resp) {
	def children = getChildDevices()
	children.each { child ->
		child.parse_system(resp)
	}
}

def parseIotXorInstData(message) {
	if (message == "udpTimeout") {
		if (systemPoll.contains("min")) {
			handleCommsError(message)
			Map logData = [method: "parseIotXorInstData", error: message]
			log.warn logData
		}
	} else {
		Map respData = parseUdp(message, "xor")
		if (respData.status == "ok") {
			setCommsError("OK")
			installIotChildren(respData.cmdResp.system.get_sysinfo)			
		} else {
			Map logData = [method: "parseIotXorInstData", respData: respData]
			logWarn(logData)
		}
	}
}

def getIotChildData() {
	Map cmdBody = [system: [get_sysinfo: []]]
	def parseMeth = "parseIotXorInstData"
	if (getDataValue("protocol") == "klap") { parseMeth = "parseIotKlapInstData" }
	sendIotCmd(cmdBody, true, parseMeth)
}

def parseIotKlapInstData(resp, data) {
	def respData = parseKlapAesResp(resp)
	if (respData.cmdResp) {
		installIotChildren(respData.cmdResp.system.get_sysinfo)
	} else {
		Map logData = [method: "parseIotKlapInstData", respData: respData]
		log.warn logData
		if (data.retry == true && systemPoll.contains("min")) {
			handleCommsError([status: respData.status, cryptoStatus: respData.cryptoStatus])
		}
	}
}

def installIotChildren(devData) {
	devData.children.each{ childData ->
		Map logData = [method: "installSmartChild", alias: childData.alias]
		String childId = childData.id
		if (childId.length() > 2) { childId = childId[-2..-1] }
		def childDni = "${device.deviceNetworkId}${childId}"
		if (getChildDevice(childDni)) {
			logData << [status: "already installed!"]
		} else {
			def model = "${devData.model}-child-${childId}"
			def deviceId = "${getDataValue("deviceId")}${childId}"
			Map addData = [childDni: childDni, deviceId: deviceId, api: "iot", 
						   type: "Child Plug Switch", firmwareVersion: devData.sw_ver, 
						   model: model, manufacturer: "Kasa", label: childData.alias]
			if(devData.led_off) { addData << [hasLed: true] }
			if (devData.feature == "TIM:ENE") { addData << [isEm: true] }
			logData << [addDevice: addChild(addData)]
		}
		logInfo(logData)
	}
	device.updateSetting("installChild", [type: "bool", value: "false"])
}
 
def sendIotChildCmd(commandData) {
	if (commandData.retry == true) {
		Map cmdData = [cmdBody: commandData.cmdBody, action: "parseIotXorChildResp"]
		state.cmdData = cmdData
	}
	String cmd = new groovy.json.JsonBuilder(commandData.cmdBody).toString()
	if (getDataValue("protocol") == "xor") {
		state.iotChildDni = commandData.dni
		if (commandData.retry == true) { runIn(10, udpTimeout) }
//	Insturmentation point for testing	
//log.info "[method: sendIotChildCmd(XOR), cmdBody: $cmdBody, RETRY: $retry]"
		logDebug("sendIotChildCmd(XOR) : $cmd")
		sendUdp(outputXOR(cmd), "parseIotXorChildResp", getDataValue("baseUrl"))
	} else {
		byte[] keyBytes = new JsonSlurper().parseText(encKey)
		byte[] ivBytes = new JsonSlurper().parseText(encIv)
		byte[] sigBytes = new JsonSlurper().parseText(encSig)		
		String uri = "${getDataValue("baseUrl")}/request?seq=${state.seqNo + 1}"
		reqParams = getKlapParams(cmd, keyBytes, ivBytes, sigBytes, state.seqNo, uri, cookie)
		logDebug("sendIotChildCmd(SMART) : $cmd")
//	Insturmentation point for testing	
//log.info "[method: sendIotChildCmd(KLAP), cmdBody: $cmdBody, RETRY: $retry]"
		asynchttpPost("parseIotKlapChildResp", reqParams, [retry: commandData.retry, childDni: commandData.dni])
	}
}

def parseIotXorChildResp(message) {
	if (message == "udpTimeout") {
		handleCommsError(message)
		Map logData = [method: "parseXorResp", error: message]
		log.warn logData
	} else {
		Map respData = parseUdp(message, "xor")
		if (respData.status == "ok") {
			def child = getChildDevice(state.iotChildDni)
			respData.cmdResp.each { 
				distIotChildData(it, child)
			}
			state.iotChildDni = null
		} else {
			Map logData = [method: "parseXorResp", respData: respData]
			logWarn(logData)
		}
	}
}

def parseIotKlapChildResp(resp, data) {
	def respData = parseKlapAesResp(resp)
	if (resp.status == 200 && respData.cryptoStatus == "OK") {
		def child = getChildDevice(data.childDni)
			respData.cmdResp.each {
				distIotChildData(it, child)
			}
	} else {
		Map logData = [method: "parseIotKlapResp", retry: data.retry, httpStatus: resp.status, cryptoStatus: cryptoStatus]
		if (data.retry == true && systemPoll.contains("min")) {
			handleCommsError([httpStatus: resp.status, cryptoStatus: cryptoStatus])
		}
		log.warn logData
	}
}

def distIotChildData(respData, child) {
	def key = respData.key
	devData = respData.value
	logDebug("distIotChildData: $key, $devData")
//	Insturmentation point for testing	
//log.info "distIotChildData: $key, $devData"
	
	if (key.contains("set")) { return }
	switch(key) {
		case "system":
			child.parse_system(devData.get_sysinfo)
			break
		case "emeter":
			child.parse_emeter(devData)
			break
		default:
			Map logData = [method: "distIotData", key: key, devData: devData, status: "unprocessed"]
			logDebug(logData)
	}
}

//	===== Include Libraries =====
#include tpLink.tpl_dev_common
#include tpLink.tpl_api_smart
#include tpLink.tpl_api_iot
#include tpLink.tpl_prot_xor_udp
#include tpLink.tpl_prot_klap
#include tpLink.tpl_prot_aes
#include tpLink.tpl_id_logs
#include tpLink.tpl_encode
#include tpLink.tpl_error
