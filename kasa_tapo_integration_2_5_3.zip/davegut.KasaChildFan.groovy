/*	Kasa/Tapo Integration Driver: TpLink Child Fan
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md
=====  Driver Notes  =====
1.	Only fan in Kasa - Tapo inventory is the KS240 Child device (using Smart API);
	therefore, this driver only supports that device.
*/ 

String nameSpace() { return "davegut" }
String version() { return "2.5.3" }


import groovy.json.JsonBuilder
import groovy.transform.Field
@Field static final String DEV_TYPE = "Child Fan"
@Field static final Boolean IS_CHILD = true
@Field static final String SYSTEM = "system"
metadata {
	definition (name: "Kasa Child Fan", namespace: nameSpace(), author: "Dave Gutheinz", 
				importUrl: "")
	{
		capability "FanControl"
		attribute "level", "NUMBER"
	}
	preferences {
		emPrefs()
		commonPreferences()
	}
}

def installed() {
	Map logData = [method: "installed"]
	List supportedFanSpeeds = ["low","medium-low","medium", "high"]
	def fanSpeedsAttr = new groovy.json.JsonBuilder(supportedFanSpeeds)
	sendEvent(name: "supportedFanSpeeds", value: fanSpeedsAttr.toString())
	logData << [supportedFanSpeeds: supportedFanSpeeds]
	logData << commonInstalled()
	logInfo(logData)
}

def updated() {
	Map logData = [method: "updated", commonUpdated: commonUpdated()]
	if (getDataValue("isEm")) { logData << [emUpdated: emUpdated()] }
	logInfo(logData)
	runIn(2, refresh)
}

def setSpeed(fanspeed) {
	Map logData = [method: "setSpeed", fanspeed: fanspeed]
	int level
	switch(fanspeed) {
		case "low": level = 1; break
		case "medium-low": level = 2; break
		case "medium": level = 3; break
		case "high": level = 4; break
		case "on": level = 9; break
		case "off": level = 0; break
		case "auto": break
		default: 
			logData << [ALERT: "UNKNOWN SetSpeed ERROR"]
	}
	logData << [level: level]
	if (level == 0) { 
		setOnOff(false)
	} else if (level == 9) { 
		setOnOff(true) 
	} else {
		List requests = [[method: "set_device_info", params: [device_on: true, fan_speed_level: level]],
						 [method: "get_device_info"]]
		Map cmdBody = [method: "multipleRequest", params: [requests: requests]]
		if (IS_CHILD) {
			Map commandData = [cmdBody: cmdBody, retry: true, devId: getDataValue("deviceId"), 
							   dni: device.deviceNetworkId, api: "smart"]
			parent.processChildCmd(commandData)
		} else {
			sendSmartCmd(cmdBody, true)
		}
	}
	logDebug(logData)
}

def cycleSpeed() {
	List cycles = ["low","medium-low","medium","high"]
	def nextIndex = cycles.indexOf(device.currentValue("speed")) + 1
	if (nextIndex > 3) { nextIndex = 0 }
	setSpeed(cycles[nextIndex])
}

def parse_get_device_info(devData) {
	def onOff = "off"
	if (devData.device_on == true) { onOff = "on" }
	def fanSpeed = devData.fan_speed_level
	def speed
	switch(fanSpeed) {
		case 0: speed = "off"; break
		case 1: speed = "low"; break
		case 2: speed = "medium-low"; break
		case 3: speed = "medium"; break
		case 4: speed = "high"; break
		default: speed = "parseError"
	}
	sendEvent(name: "speed", value: speed)
	sendEvent(name: "switch", value: onOff, type: state.eventType)
	logDebug("setDevStatus: [switch: ${onOff}, speed: ${speed}]")
	if (emEnable) {
		def delay = getDataValue("deviceId")[-1].toInteger()
		runIn(2*delay, smartPowerRefresh)
	}
}

#include tpLink.tpl_cap_switch
#include tpLink.tpl_cap_em
#include tpLink.tpl_child_common
#include tpLink.tpl_id_logs
