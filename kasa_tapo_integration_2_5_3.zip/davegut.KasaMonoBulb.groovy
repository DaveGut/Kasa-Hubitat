/*	tpLink Integration Driver: tpLinkCT Bulb
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md
*/ 

String nameSpace() { return "davegut" }
String version() { return "2.5.3" }


import groovy.transform.Field
@Field static final String DEV_TYPE = "Mono Bulb"
@Field static final String EM_SYS = "smartlife.iot.common.emeter"
@Field static final Boolean IS_CHILD = false
@Field static final String LIGHT_TRANS_TYPE = "transition_period"
@Field static final String SYSTEM = "smartlife.iot.smartbulb.lightingservice"
@Field static final String LIGHT_CMD = "transition_light_state"

metadata {
	definition (name: "Kasa Mono Bulb",
				namespace: nameSpace(), 
				author: "Dave Gutheinz", 
				singleThreaded: true
			   )
	{
		capability "Light"
	}
	preferences {
		emPrefs()
		levelPrefs()
		commonPrefs()
	}
} 

def installed() {
	Map instStatus = [method: "installed"]
	instStatus << commonInstalled()
	logInfo(instStatus)
	deviceHandshake()
	runIn(5, updated)
}
 
def updated() {
	Map updStatus = [method: "updated"]
	unschedule()
	updStatus << [commonUpdated: commonUpdated()]
	updStatus << [levelUpdated: levelUpdated()]
	if (getDataValue("isEm")) { updStatus << [emUpdated: emUpdated()] }
	logInfo(updStatus)
}

def setMonoBulb(onOff, level) {
	sendEvent(name: "switch", value: onOff, type: state.eventType)
	Map logData = [method: "setMonoBulb", switch: onOff]
	if (onOff == "on") {
		sendEvent(name: "level", value: level)
		logData << [level: level]
	}
	logDebug(logData)
}

//	===== Smart Methods =====
def parse_get_device_info(resp) {
	def onOff = "off"
	if (resp.device_on == true) { onOff = "on" }
	int level = resp.brightness.toInteger()
	setMonoBulb(onOff, level)
}

//	===== Iot Methods =====
def parse_system(devData) {
	def onOff = "off"
	if (devData.relay_state == 1 || devData.on_off == 1) {
		onOff = "on"
	}
	int level
	if (devData.brightness) { level = devData.brightness.toInteger() }
	else { level = devData.dft_on_state.brightness.toInteger() }
	setMonoBulb(onOff, level)
}

//	===== Include Libraries =====
#include tpLink.tpl_cap_switch
#include tpLink.tpl_cap_level
#include tpLink.tpl_cap_em
#include tpLink.tpl_dev_common
#include tpLink.tpl_api_smart
#include tpLink.tpl_api_iot
#include tpLink.tpl_prot_klap
#include tpLink.tpl_prot_aes
#include tpLink.tpl_prot_xor_udp
#include tpLink.tpl_id_logs
#include tpLink.tpl_encode
#include tpLink.tpl_error
