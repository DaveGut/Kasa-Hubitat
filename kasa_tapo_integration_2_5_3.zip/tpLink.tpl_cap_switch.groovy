library (
	name: "tpl_cap_switch",
	namespace: "tpLink",
	author: "Dave Gutheinz",
	description: "Kasa-Tapo switch on/off. Hub V 2.5.3",
	category: "utilities",
	documentationLink: ""
)

capability "Switch"

def on() { setOnOff("on") }

def off() { setOnOff("off") }

def setOnOff(onOff) {
	def api = getDataValue("api")
	Map logData = [method: "setOnOff", api:api, switch: onOff]
	if (api == "smart") {
		setSmartOnOff(onOff)
	} else {
		setIotOnOff(onOff)
	}
	logDebug(logData)
}

//	===== Smart API Calls =====
def setSmartOnOff(onOff) {
	def smartOnOff = true
	if (onOff == "off") { smartOnOff = false }
	Map params = [device_on: smartOnOff]
	if (transTime) {
		int tTime = 1000 * transTime.toInteger()
		if (tTime == 0) { tTime = 10 }
		params << [transition_period: tTime]
	}
	List requests = [[method: "set_device_info", params: params],
					 [method: "get_device_info"]]
	Map cmdBody = [method: "multipleRequest", params: [requests: requests]]
	if (IS_CHILD) {
		state.eventType = "digital"
		Map commandData = [cmdBody: cmdBody, retry: true, devId: getDataValue("deviceId"), 
						   dni: device.deviceNetworkId, api: "smart"]
		parent.processChildCmd(commandData)
	} else {
		sendSmartCmd(cmdBody, true)
	}
	if (emEnable) { runIn(5, getSmartPower) }
}

//	===== IOT API Calls	=====
//	All IOT Hubitat child devices are childPlugSwitch.
def setIotOnOff(onOff) {
	state.eventType = "digital"
	def onOffState = 1
	if (onOff == "off") { onOffState = 0 }
	Map cmdBody = [:]
	if (getDataValue("plugNo") || DEV_TYPE == "Child Plug Switch") {
		//	Handle legacy multiplug (plugNo) and new installs (Child Plug Switch)
		cmdBody << [context: [child_ids:[getDataValue("deviceId")]]]
	}
	if (DEV_TYPE == "Plug Switch" || DEV_TYPE == "Dimming Switch" || IS_CHILD) {
			cmdBody << [system: [set_relay_state: [state: onOffState], get_sysinfo: []]]
	} else {
		int tTime = 1000 * transTime.toInteger()
		if (tTime == 0) { tTime = 10 }
		Map transData = [on_off: onOffState, "${LIGHT_TRANS_TYPE}": tTime]
		cmdBody = ["${SYSTEM}": ["${LIGHT_CMD}": transData]]
	}
	if (IS_CHILD) {
		Map commandData = [cmdBody: cmdBody, retry: true, devId: getDataValue("deviceId"), 
						   dni: device.deviceNetworkId, api: "iot"]
		parent.processChildCmd(commandData)
	} else {
		sendIotCmd(cmdBody, true)
	}
	if (emEnable) { runIn(5, iotGetRealtime) }
}
