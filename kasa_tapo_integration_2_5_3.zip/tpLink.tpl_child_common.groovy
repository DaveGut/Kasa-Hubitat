library (
	name: "tpl_child_common",
	namespace: "tpLink",
	author: "Compiled by Dave Gutheinz",
	description: "Common child methods library for Kasa/Tapo and Tapo SMART protocol drivers. Hub V 2.5.3",
	category: "utilities",
	documentationLink: ""
)

capability "Refresh"

def commonPreferences() {
	input ("logEnable", "bool",  title: "Enable debug logging for 30 minutes", defaultValue: false)
	input ("infoLog", "bool", title: "Enable information logging",defaultValue: true)
}

def commonInstalled() {
	return [eventType: "digital"]
}

def commonUpdated() {
	Map logData = [infoLog: infoLog, debugLog: logEnable]
	if (logEnable == true) { runIn(1800, debugLogOff) }
	return logData
}

def refresh() {
	state.eventType = "digital"
	Map commandData = [retry: true, devId: getDataValue("deviceId"), dni: device.deviceNetworkId]
	if (getDataValue("api") == "smart") {
		List requests = [[method: "get_device_info"]]
		Map cmdBody = [method: "multipleRequest", params: [requests: requests]]
		commandData << [cmdBody: cmdBody, api: "smart"]
	} else {
		Map cmdBody = [system: [get_sysinfo: []]]
		commandData << [cmdBody: cmdBody, api: "iot"]
	}
	parent.processChildCmd(commandData)
}
