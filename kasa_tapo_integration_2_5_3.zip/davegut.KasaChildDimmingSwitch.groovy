/*	Kasa/Tapo Integration Driver: TpLink Child Dimmer
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md
Notes: 
1.	There are zero IOT api child dimmers. So this driver does not support IOT api child dimmers.
*/ 

String nameSpace() { return "davegut" }
String version() { return "2.5.3" }

import groovy.transform.Field
@Field static final String DEV_TYPE = "Child Dimming Switch"
@Field static final Boolean IS_CHILD = true
@Field static final String LIGHT_TRANS_TYPE = "transition_period"
@Field static final String SYSTEM = "system"
metadata {
	definition (name: "Kasa Child Dimming Switch", namespace: nameSpace(), author: "Dave Gutheinz", 
				importUrl: "")
	{
		capability "Light"
	}
	preferences {
		emPrefs()
		commonPreferences()
		levelPrefs()
	}
}

def installed() {
	Map logData = [method: "installed"]
	logData << commonInstalled()
	logInfo(logData)
	runIn(1, updated)
}

def updated() {
	Map logData = [method: "updated"]
	unschedule()
	logData << commonUpdated()
	logData << levelUpdated()
	if (getDataValue("isEm")) { logData << [emUpdated: emUpdated()] }
	logInfo(logData)
	runIn(2, refresh)
}

def setDevStatus(onOff, level) {
	sendEvent(name: "switch", value: onOff, type: state.eventType)
	sendEvent(name: "level", value: level, type: state.eventType)
	logDebug("setDevStatus: [switch: ${onOff}, level: ${level}]")
}

//	===== Smart Methods =====
def parse_get_device_info(devData) {
	def onOff = "off"
	if (devData.device_on == true) { onOff = "on" }
	int level = devData.brightness
	setDevStatus(onOff, level)
	if (emEnable) {
		def delay = getDataValue("deviceId")[-1].toInteger()
		runIn(2*delay, smartPowerRefresh)
	}
}

#include tpLink.tpl_cap_switch
#include tpLink.tpl_cap_level
#include tpLink.tpl_cap_em
#include tpLink.tpl_child_common
#include tpLink.tpl_id_logs
