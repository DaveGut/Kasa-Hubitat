/*	Kasa/Tapo Integration Driver: TpLink Child Plug
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md
=====  Driver Notes  =====
1.	Supports Smart multi-plug children plugs/switches and NEW IOT multiplug child plugs/switches.
*/ 

String nameSpace() { return "davegut" }
String version() { return "2.5.3" }


import groovy.transform.Field
@Field static final String DEV_TYPE = "Child Plug Switch"
@Field static final String EM_SYS = "emeter"
@Field static final Boolean IS_CHILD = true
@Field static final String SYSTEM = "system"
metadata {
	definition (name: "Kasa Child Plug Switch", namespace: nameSpace(), author: "Dave Gutheinz", 
				importUrl: "")
	{ }
	preferences {
		emPrefs()
		commonPreferences()
	}
}

def installed() {
	Map logData = [method: "installed"]
	state.eventType = "physical"
	logData << commonInstalled()
	logInfo(logData)
	runIn(1, updated)
}

def updated() {
	Map logData = [method: "updated"]
	unschedule()
	logData << commonUpdated()
	if (getDataValue("isEm")) { logData << [emUpdated: emUpdated()] }
	logInfo(logData)
	runIn(5, refresh)
}

def setChildSwitch(onOff) {
	sendEvent(name: "switch", value: onOff, type: state.eventType)
	Map logData = [method: "setChildSwitch", switch: onOff, eventType: state.eventType]
	logDebug(logData)
	state.eventType = "physical"
}

//	===== Smart Methods =====
def parse_get_device_info(devData) {
	def onOff = "on"
	if (devData.device_on == false) { onOff = "off" }
	setChildSwitch(onOff)
	if (emEnable) {
		def delay = getDataValue("deviceId")[-1].toInteger()
		runIn(2*delay, smartPowerRefresh)
	}
}

//	===== IOT Methods =====
def parse_system(devData) {
	def devId = getDataValue("deviceId")
	def childData = devData.children.find { it.id == devId }
	def onOff = "off"
	if (childData == null) {
		childData = devData.children.find { it.id == devId[-2..-1]}
	}
	if (!childData) {
    	logWarn("parse_system: Child ${devId} not found")
	} else {
		if (childData.state == 1) { onOff = "on" }
		setChildSwitch(onOff)
		if (emEnable) {
			def delay = getDataValue("deviceId")[-1].toInteger()
			runIn(2*delay, iotGetRealtime)
		}
	}
}

#include tpLink.tpl_cap_switch
#include tpLink.tpl_cap_em
#include tpLink.tpl_child_common
#include tpLink.tpl_id_logs
