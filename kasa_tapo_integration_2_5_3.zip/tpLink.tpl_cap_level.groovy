library (
	name: "tpl_cap_level",
	namespace: "tpLink",
	author: "Dave Gutheinz",
	description: "Kasa-taop switch level and change level. Hub V 2.5.3",
	category: "utilities",
	documentationLink: ""
)

capability "Switch Level"
capability "Change Level"

def levelPrefs() {
	input ("transTime", "number", defaultValue: 1, range: [0..10],
		   title: "lighting transition time (seconds, 1->10)")
}

def levelUpdated() {
	Map logData = [:]
	if (transTime < 0 || transTime > 10 || transTime == null) {
		device.updateSetting("transTime", [type: "number", value: 1])
		logData << [transTimeError: "out of range", updatedTo: 1]
	} else {
		logData << [transTime: transTime]
	}
	if (getDataValue("gradOnOff")) { logData << setDimmerTransition() }
	return [levelUpdated: logData]
}

def setDimmerTransition() {
	//	Sets the onOff Transition Time in the actual device.
	//	All kasa/tapo dimming devices support this.
	Map cmdBody = [:]
	Map logData = [:]
	int onOffTime = transTime.toInteger()
	def api = getDataValue("api")
	if (api == "iot") {
		setIotDimmerTrans(onOffTime)
	} else if (api == "smart") {
		setSmartDimmerTrans(onOffTime)
	}
	return [setDimmerTransition: [fadeOn: transTime, fadeOff: transTime]]
}

def setLevel(level, transSecs = transTime) {
	if (level.toInteger() == 0) {
		off()
		return
	}
	def api = getDataValue("api")
	Map logData = [method: "setLevel", api: api, level: level, transTime:transTime]
	Integer fadeTime = (transSecs ?: 1).toInteger()
	int tTime = 1000 * fadeTime
	if (tTime == 0) { tTime = 10 }
	Map params = [brightness: level, "${LIGHT_TRANS_TYPE}": tTime]
	if (api == "smart") {
		params << [device_on: true]
		setSmartLevel(params)
	} else {
		params << [ignore_default: 1, on_off: 1]
		setIotLevel(params)
	}
	logDebug(logData)
}

def startLevelChange(direction) {
	int curLevel = (device.currentValue("level") ?: 0).toInteger()
	unschedule(levelUp)
	unschedule(levelDown)
	if (direction == "up") { 
		levelUp(curLevel)
	} else { 
		levelDown(curLevel)
	}
}

def stopLevelChange() {
	unschedule(levelUp)
	unschedule(levelDown)
	refresh()
}

def levelUp(curLevel) {
	if (curLevel == 100) { 
		refresh()
	} else {
		def newLevel = curLevel + 4
		if (newLevel > 100) { newLevel = 100 }
		if (getDataValue("api") == "smart") { 
			smartTransCmd(newLevel)
		} else {
			iotQuickLevel(newLevel)
		}
		sendEvent(name: "level", value: newLevel, type: "levelUpDown")
		runIn(1, levelUp, [data: newLevel])
	}
}

def levelDown(curLevel) {
	if (curLevel == 0 || device.currentValue("switch") == "off") {
		refresh()
	} else {
		def newLevel = curLevel - 4
		if (getDataValue("api") == "smart") { 
			smartTransCmd(newLevel) 
		} else {
			iotQuickLevel(newLevel)
		}
		sendEvent(name: "level", value: newLevel, type: "levelUpDown")
		if (newLevel < 4) { 
			off()
		}
		else { runIn(1, levelDown, [data: newLevel]) }
	}
}

//	===== Smart API Calls =====
def setSmartDimmerTrans(onOffTime) {
	Map params = [:]
	if (onOffTime == 0) {
		params << [off_state: [enable: false], on_state: [enable: false]]
	} else {
		params << [off_state: [duration: onOffTime, enable: true],
				   on_state: [duration: onOffTime, enable: true]]
	}
	List requests = [[method: "set_on_off_gradually_info", params: params],
					 [method: "get_on_off_gradually_info"]]
	Map cmdBody = [method: "multipleRequest", params: [requests: requests]]
	if (IS_CHILD) {
		Map commandData = [cmdBody: cmdBody, retry: true, devId: getDataValue("deviceId"), 
						   dni: device.deviceNetworkId, api: "smart"]
		parent.processChildCmd(commandData)
	} else {
		sendSmartCmd(cmdBody, true)
	}
}

def parse_get_on_off_gradually_info(resp) {
	def onOffDef = resp.on_state.duration
	device.updateSetting("onOffDef", [type:"number", value: onOffDef])
	Map logData = [method: "setSmartDimConfig", onOffDef: onOffDef, enable: resp.on_state.enable]
	logDebug(logData)
}
	
def setSmartLevel(params) {
	List requests = [[method: "set_device_info", params: params],
					 [method: "get_device_info"]]
	Map cmdBody = [method: "multipleRequest", params: [requests: requests]]
	if (IS_CHILD) {
		Map commandData = [cmdBody: cmdBody, retry: true, devId: getDataValue("deviceId"), 
						   dni: device.deviceNetworkId, api: "smart"]
		parent.processChildCmd(commandData)
	} else {
		sendSmartCmd(cmdBody, true)
		if (emEnable) { runIn(5, getSmartPower) }
	}
}

def smartTransCmd(currLevel) {
	//	always uses tTime of 10
	Map params = [device_on: true, brightness: currLevel, "${LIGHT_TRANS_TYPE}": 10]
	List requests = [[method: "set_device_info", params: params]]
	Map cmdBody = [method: "multipleRequest", params: [requests: requests]]
	if (IS_CHILD) {
		Map commandData = [cmdBody: cmdBody, retry: false, devId: getDataValue("deviceId"), 
						   dni: device.deviceNetworkId, api: "smart"]
		parent.processChildCmd(commandData)
	} else {
		sendSmartCmd(cmdBody, false, "smartNullParse")
	}
}

//	===== IOT API Calls	=====
def setIotDimmerTrans(onOffTime) {
	Map cmdBody = ["smartlife.iot.dimmer": [
		set_fade_on_time: [fadeTime: onOffTime * 1000],
		set_fade_off_time: [fadeTime: onOffTime * 1000],
		get_dimmer_parameters :[]]]
	sendIotCmd(cmdBody, true)
}

def parse_get_dimmer_parameters(resp) {
	logDebug([method: "setIotDimConfig", resp: resp])
	if (resp.err_code != 0) {
		log.warn "setIotDimConfig: Error in return"
	} else {
		def onOffDef = (0.5 + resp.fadeOffTime / 1000).toInteger()
		device.updateSetting("onOffDef", [type:"number", value: onOffDef])
	}
}

def setIotLevel(params) {
	Map cmdBody = ["${SYSTEM}": ["${LIGHT_CMD}": params]]
	sendIotCmd(cmdBody, true)
	//	Dimming switch return actual level, so wait for transition to complete.
	if (DEV_TYPE == "Dimming Switch") { runIn(transTime + 1, refresh) }
	if (emEnable) { runIn(5, iotGetRealtime) }
}

def iotQuickLevel(level) {
	Map transData = [ignore_default: 1, on_off: 1, brightness: level,
					 "${LIGHT_TRANS_TYPE}": 10]
	Map cmdBody = ["${SYSTEM}": ["${LIGHT_CMD}": transData]]
	if (getDataValue("protocol") == "xor") {
		sendIotCmd(cmdBody, false, "iotNullParse")
	} else {
		sendSmartCmd(cmdBody, false, "smartNullParse")
	}
}
