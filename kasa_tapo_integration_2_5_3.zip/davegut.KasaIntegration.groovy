/*	Install Kasa / Tapo Plugs, Switches, and Bulbs.
	Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md
*/

String nameSpace() { return "davegut" }
String version() { return "2.5.3" }


definition(
	name: "Kasa Integration",
	namespace: nameSpace(),
	author: "Dave Gutheinz",
	description: "Application to install TP-Link Kasa and Tapo  bulbs, plugs, and switches.",
	category: "Convenience",
	iconUrl: "",
	iconX2Url: "",
	installOnOpen: true,
	singleInstance: true,
	documentationLink: "https://github.com/DaveGut/Kasa-Hubitat/blob/main/KasaIntegrationHelp.pdf",
	importUrl: ""
)

preferences {
	page(name: "startPage")
	page(name: "setupApp")
	page(name: "addDevicesPage")
	page(name: "removeDevicesPage")
}

void installed() {
	//	Initialize settings on installation
	def hub = location.hubs[0]
	def hubIpArray = hub.localIP.split('\\.')
	def segment = [hubIpArray[0],hubIpArray[1],hubIpArray[2]].join(".")
	app?.updateSetting("version", [type:"string", value: version()])
	app?.updateSetting("lanSegment", [type:"string", value: segment])
	app?.updateSetting("ports", [type:"string", value: "9999"])
	app?.updateSetting("asInst", [type:"bool", value: true])	//Display setup page quick help
	app?.updateSetting("spInst", [type:"bool", value: true])	//Display start page quick help
	atomicState.iotDevices = [:]	//database for IOT devices
	atomicState.smartDevices = [:]	//database for SMART devices
	atomicState.findingSecure = false	//Wait state to preclude smartDevices concurrence issues.
	atomicState.findingXor = false	//Wait state to preclude xorDevices concurrence issues.
	atomicState.deviceWait = false
	initialize()
	logInfo("installed: [status: Initialized settings and states.]")
}

void initialize() {
	subscribe(location, "systemStart", "hubStartupHandler")
}

void hubStartupHandler() {
	//	Runs on startup. Calls child.updateVersion.
	//	Is specific for each INTEGRATION Version Change.
	//	Note: The verUpdate_2_5_3 should be kept since it is the
	//	transition from Kasa to KasaTapo app (supports users delaying
	//	the hub update for significant periods.
	//	Method child.verUpdate_2_5_3 is in library tpl_dev_common.
	//	Those child method will determine what to do for each version.
	//	Note: method version() is in library tpl_id_logs
	Map logData = [method: "hubStartupHandler", children: "updating"]
	def children = getChildDevices()
	children.each { child ->
		child.verUpdate_2_5_3()
	}
	if (settings.version != version()) {
		logData << [currVersion: settings.version, newVersion: version()]
		if (version() == "2.5.3") {
			//	remove old settings
			app.removeSetting("routerIp")
			app.removeSetting("configureEnabled")
			app.removeSetting("appSetup")
			app.removeSetting("hostLimits")
			app?.updateSetting("asInst", [type:"bool", value: true])
			app?.updateSetting("instMatter", [type:"bool", value: true])
			app?.updateSetting("infoLog", [type:"bool", value: true])
			//	update states
			state.remove("devices")
			state.remove("tapoDevices")
			state.remove("hostArray")
			state.remove("devices")
			//	Update app for next run.
			app.updateSetting("version", [type:"string", value: version()])
			runIn(2, updated)
		} else {
			logData << [status: "no app updates required"]
		}
	}
	logInfo(logData)
}

def updated() {
	unschedule()
	unsubscribe()
	initialize()
	app?.updateSetting("logEnable", [type:"bool", value: false])
	atomicState.iotDevices = [:]
	atomicState.smartDevices = [:]
	atomicState.findingSecure = false
	atomicState.findingXor = false
	atomicState.deviceWait = false
	log.info "updated: [status: setting updated for next session]"
}

def uninstalled() {
	List uninstalled = []
    getAllChildDevices().each {
		uninstalled << [it.alias]
        deleteChildDevice(it.deviceNetworkId)
    }
	log.info "uninstalled: [status: Device ${uninstalled} and App uninstalled]"
}

//	===== Start Page =====
def startPage() {
	log.info "startPage"
	if (selectedRemoveDevices) {removeDevices()}
	else if (selectedAddDevices) { addDevices() }
	//	Update port and segment array
	state.segArray = lanSegment.split('\\,')
	state.portArray = ports.split('\\,')

	return dynamicPage(name:"startPage",
					   uninstall: true,
					   install: true) {
		section() {
			String setupParams = "user: ${userName}, installMatter: <b>${instMatter}</b>, "
			setupParams += "LanSegments: ${state.segArray}, KasaPorts: ${state.portArray}."
			if (spInst) { paragraph startPgInst() }
			if (!userName || !userPassword) {
				setupParams += "\n<b>App will only insall Kasa IOT Devices.</b>"
			} else {
				setupParams += "\nApp will install Kasa IOT and Kasa/Tapo SMART Devices."
			}
			href "setupApp",
				title: "<b>Setup Application and Credentials</b>",
				description: setupParams
			href "addDevicesPage",
				title: "<b>Scan for devices and add</b>",
				description: "Be patient. It can take up to 1.6 minutes."
			href "removeDevicesPage",
				title: "<b>Remove Devices</b>",
				description: "Select devices to remove from Hubitat."
			input "logEnable", "bool",
				   title: "<b>Debug logging</b>",
				   submitOnChange: true, defaultValue: true
			input "infoLog", "bool",
				   title: "<b>Info logging</b>",
				   submitOnChange: true, defaultValue: true
			input "spInst", "bool", title: "<b>Display Start Page Help</b>",
				submitOnChange: true, defaultValue: true
		}
	}
}

String startPgInst() {
	String quickSP = "Install Kasa/Tapo Device and prepare for Hubitat control."
	quickSP += "\n\ta.\tKasa/Tapo Phone App: Install device."
	quickSP += "\n\tb.\tKasa/Tapo Phone App: Turn on Third Party Compatibility."
	quickSP += "\n\tc.\tKasa/Tapo Phone App: Exercise device to be installed."
	quickSP += "\n\td.\tKasa/Tapo Phone App: Turn OFF Multi-Factor Authentication."
	quickSP += "\n\te.\tYour WiFiRouter: Set DHCP Reservation for Device."
	quickSP += "\nIn this Integration."
	quickSP += "\n\ta.\tSelect Setup Application and Credentials."
	quickSP += "\n\tb.\tOn return select desired action."
	quickSP += "\n<b>Detailed help: use the ? icon above</b>."
	return quickSP
}
 
//	===== Setup App Page =====
def setupApp() { 
	return dynamicPage (name: "setupApp", 
    					title: "Setup Application and Update Credentials",
						nextPage: "startPage",
                        install: false) {
		section() {
			if (asInst) { paragraph setUpInst() }
			input ("userName", "string",
            		title: "Email Address", 
                    required: false,
                    submitOnChange: true)
			input ("userPassword", "string",
            		title: "Account Password",
                    required: false,
                    submitOnChange: true)
			if (userName && userPassword) {
				def credCheck = checkCreds(userName, userPassword)
				if (credCheck != "OK") {
					paragraph credCheck
				}
				createSecureCreds()
			}
			//	Install Matter
			input "instMatter", "bool", title: "<b>Install matter capable devices</b>",
				submitOnChange: true, defaultValue: false
			if (instMatter) {
				paragraph "\tCaution.  If the devices is already installed in Hubitat, this can created a second version."
			}
			//	Lan segments and ports
			input "lanSegment", "string",
				title: "<b>Lan Segments</b> (only works for legacy Kasa devices).", 
				submitOnChange: true
			input "ports", "string",
				title: "<b>Kasa (IOT) ONLY ports</b> (only works for legacy Kasa devices)", 
				submitOnChange: true
			input "asInst", "bool", title: "<b>Display Setup Help</b>",
				submitOnChange: true, defaultValue: true
		}
	}
}
 
String setUpInst() {
	String setUpInst = "Username and Password"
			setUpInst += "\n\ta.\tPassword and Username are both case sensitive."
			setUpInst += "\n\tb.\tRecommend Tapo/Kasa password be alpha/numeric only."
			setUpInst += "Install Matter. Caution, can cause duplicate instantiation of devices."
			setUpInst += "\n\tLan Segments and ports. Advanced users only."
	return setUpInst
}

String checkCreds(userName, userPassword) {
	def resp = "OK"
	String altResp = "Credentials have special characters:"
	Map credSpecChars = [:]
	def pattern = /[^a-zA-Z0-9@.]/
	def matcher = userName =~ pattern
	List specChars = []
	matcher.each { match -> specChars << match[0] }
	if (specChars != []) { credSpecChars << [userName: specChars] }
	specChars = userPassword.findAll(/\W+/)
	if (specChars != []) { credSpecChars << [userPassword: specChars] }
	if (credSpecChars != [:]) {
		resp = "\tYour credentials may have issues with the following special characters:"
		resp += "\n\t\t${credSpecChars}"
	}
	return resp
}

void createSecureCreds() {
	String encUsername = mdEncode("SHA-1", userName.bytes).encodeHex().encodeAsBase64().toString()
	app?.updateSetting("encUsername", [type: "string", value: encUsername])
	String encPassword = userPassword.trim().bytes.encodeBase64().toString()
	app?.updateSetting("encPassword", [type: "string", value: encPassword])
	//	Get normal localHush
	String authHash = genKlapLocalHash(userName, userPassword)
	app?.updateSetting("localHash", [type: "string", value: authHash])
	//	Get alternate local hash using default passwords
	authHash = genKlapLocalHash("test@tp-link.net", "test")
	app?.updateSetting("altLocalHash", [type: "string", value: authHash])
	logDebug("createSecureCreds: Created credential settings and checked credentials for special characters")
} 

String genKlapLocalHash(name, password) {
	byte[] userHashByte = mdEncode("SHA-1", encodeUtf8(name).getBytes())
	byte[] passwordHashByte = mdEncode("SHA-1", encodeUtf8(password.trim()).getBytes())
	byte[] authHashByte = [userHashByte, passwordHashByte].flatten()
	String authHash = mdEncode("SHA-256", authHashByte).encodeBase64().toString()
	return authHash
}

//	===== Add Devices Page =====
def addDevicesPage() {
	Map logData = [method: "addDevicesPage"]
	logData << [pollForDevices: pollForDevices("find", 10)]
//	Map devicesData = atomicState.iotDevices + atomicState.smartDevices
	Map devicesData = atomicState.iotDevices
	if (atomicState.smartDevices) {
		devicesData += atomicState.smartDevices
	}
	logData << [devicesDataSize: devicesData.size()]
	app?.removeSetting("selectedAddDevices")
	Map uninstalledDevices = [:]
	devicesData.each {
		def isChild = getChildDevice(it.key)
		if (!isChild) {
			def driver = "kasaTapo ${it.value.type}"
			uninstalledDevices["${it.key}"] = "${it.value.alias}, ${it.value.type}, ${it.value.api}, ${it.value.protocol}, ${it.key}"
		}
	}
	uninstalledDevices = uninstalledDevices.sort{ it.value }
	logData << [totalUninstalledDevs: uninstalledDevices.size()]
	logInfo(logData)
	return dynamicPage(name:"addDevicesPage",
					   title: "Add Devices to Hubitat",
					   nextPage: "startPage",
					   install: false) {
		section() {
			input ("selectedAddDevices", "enum",
				   required: false,
				   multiple: true,
				   title: "<b>Devices to add</b> (${uninstalledDevices.size() ?: 0} available).\n\t" +
				   "Total Devices: ${devicesData.size()}",
				   description: "Use the dropdown to select devices.  Then select 'Done'.",
				   options: uninstalledDevices)
			href "addDevicesPage",
				title: "<b>Rescan for Additional Devices</b>",
				description: "<b>Exercise missing devices through the Kasa or Tapo Phone App.</b>"
		}
	}
} 

def addDevices() {
	logInfo([method: "addDevices", selectedAddDevices: selectedAddDevices])
	Map devicesData = atomicState.iotDevices + atomicState.smartDevices
	selectedAddDevices.each { dni ->
		def isChild = getChildDevice(dni)
		if (!isChild) {
			def device = devicesData.find { it.key == dni }.value
			addDevice(device, dni)
		}
		pauseExecution(2000)
	}
	app?.removeSetting("selectedAddDevices")
}

def addDevice(device, dni) {
	Map logData = [method: "addDevice", dni: dni, alias: device.alias]
	try {
		String label = device.alias.replaceAll("[\u201C\u201D]", "\"").replaceAll("[\u2018\u2019]", "'").replaceAll("[^\\p{ASCII}]", "")
		String name = device.model
		String driver = "Kasa ${device.type}"
		["alias", "type", "driver"].each { device.remove(it) }
		addChildDevice(nameSpace(), driver, dni,
			["label": label,
			 "name" : name,
			 "data" : device]
		)
		logData << [status: "added"]
	} catch (err) {
		logData << [status: "failedToAdd", device: device, errorMsg: err]
	}
	logInfo(logData)
	return
}

//	===== Remove Devices =====
def removeDevicesPage() {
	Map installedDevices = [:]
	getChildDevices().each {
		installedDevices << ["${it.device.deviceNetworkId}": it.device.label]
	}
	logDebug("removeDevicesPage: ${installedDevices}")
	return dynamicPage(name:"removeDevicesPage",
					   title:"<b>Remove Devices from Hubitat</b>",
					   nextPage: "startPage",
					   install: false) {
		section() {
			input ("selectedRemoveDevices", "enum",
				   required: false,
				   multiple: true,
				   title: "Devices to remove (${installedDevices.size() ?: 0} available)",
				   description: "Use the dropdown to select devices.  Then select 'Done'.",
				   options: installedDevices)
		}
	} 
}

void removeDevices() {
	logInfo([method: "removeDevices", selectedRemoveDevices: selectedRemoveDevices])
	List removed = []
	selectedRemoveDevices.each { dni ->
		removed << [getChildDevice(dni)]
		deleteChildDevice(dni)
	}
	app?.removeSetting("selectedRemoveDevices")
}

//	===== Device Discovery and devices database creation =====
Map pollForDevices(type, timeout = 5) {
	//	type = find (add devices), poll (quick poll for limited data).
	Map logData = [method: "pollForDevices", type: type, timeout: "${timeout}", xorPortArray: state.portArray]
	def xorAction = "getXorLanData"
	def secureAction = "getSecureLanData"
	if (type == "poll") {
		xorAction = "quickFindXorData"
		secureAction = "quickFindSecureData"
	}
	//	XOR/UDP devices 
	state.portArray.each { port ->
		atomicState.findingSecure = false
		atomicState.findingXor = true
		findDevices(xorAction, xorDiscCmd(), port, timeout)
		if (type == "poll") {
			def await = waitForXorFind(20)
		} else {
			def await = waitForXorFind(45)
		}			
	}
	//	KLAP/AES devices
	if (userName && userPassword) {
		atomicState.findingSecure = true
		atomicState.findingXor = false
		findDevices(secureAction, secureDiscCmd(), 20002, timeout)
		if (type == "poll") {
			def await = waitForSecureFind(20)
		} else {
			def await = waitForSecureFind(60)
		}			
		pauseExecution(2000)
	}
	logDebug(logData)
	return logData
}

def waitForXorFind(secs) {
	//	Optimizes timing between the IOT/Smart find as well as reduces state concurrence issues.
	Map logData = [method: "waitForIotFind"]
	int i = 0
	for(i = 0; i < secs; i += 1) {
		if (atomicState.findingXor == false) {
			logData << [seconds: i]
			if(i == secs - 1) {
				logData << [ERROR: "Find took excessive time."]
				log.warn logData
			}
			i = secs
		} else {
			pauseExecution(1000)
		}
	}
	logDebug(logData)
	return
}

def waitForSecureFind(secs) {
	//	Optimizes timing between the IOT/Smart find as well as reduces state concurrence issues.
	Map logData = [method: "waitForSecureFind"]
	int i = 0
	for(i = 0; i < secs; i += 1) {
		if (atomicState.findingSecure == false) {
			logData << [seconds: i]
			if(i == secs - 1) {
				logData << [ERROR: "Find took excessive time."]
				log.warn logData
			}
			i = secs
		} else {
			pauseExecution(1000)
		}
	}
	logDebug(logData)
	return
}

void findDevices(action, cmdData, port, timeout) {
	Map logData = [method: "findDevices", action: action, port: port, timeout: timeout]
	state.segArray.each {
		def pollSegment = it.trim()
		List deviceIPs = []
		for(int i = 2; i < 255; i++) {
			deviceIPs.add("${pollSegment}.${i.toString()}")
		}
		logInfo("findDevices: executing findDevice poll to port ${port} (takes up to 40 seconds).")
		//	Pre-poll to exercise interface, waking deep-sleeping devices.
		sendUdp(cmdData, "nullParse", "${deviceIPs.join(',')}:${port}", 3)
		pauseExecution(4000)
		//	Required since Hubitat does not currently return parseWarning message.
		runIn(timeout + 6, udpTimeout, [data: action])
		sendUdp(cmdData, action, "${deviceIPs.join(',')}:${port}", timeout)
	}
	logDebug(logData)
}
 
void addDeviceData(dni, devData) {
	Map logData = [method: "addDeviceData", alias: devData.alias]
	
//	Instrumentation option
//	logData << [devData: devData]
	
	devData << [version: version()]
	def childDev = getChildDevice(dni)
	if (childDev) {
		logData << [isChild: true, action: "send data to child device"]
		childDev.updateDeviceData(devData)
	} else {
		Map devicesData = [:]
		//	klap protocol are put in smartDevices to assure klap supremacy
		if (devData.protocol == "xor") {
			devicesData.putAll(atomicState.iotDevices ?: [:])
			devicesData << ["${dni}": devData]
			atomicState.iotDevices = devicesData
			logData << [action: "added to iotDevices."]
		} else {
			devicesData.putAll(atomicState.smartDevices ?: [:])
			devicesData << ["${dni}": devData]
			atomicState.smartDevices = devicesData
			logData << [action: "added to smartDevices."]
		}
	}
	atomicState.deviceWait = false
	logInfo(logData)
}

def nullParse(resp) { }

def waitForDevData(secs) {
	//	Assures one device processed at a time during async methods.
	int i = 0
	def intervals = 2 * secs
	for(i = 0; i < intervals; i += 1) {
		if (atomicState.deviceWait == false) {
				i = intervals
		} else {
			pauseExecution(500)
		}
	}
	return
}

#include tpLink.tpl_app_xor
#include tpLink.tpl_app_secure
#include tpLink.tpl_prot_klap
#include tpLink.tpl_prot_aes
#include tpLink.tpl_prot_xor_udp
#include tpLink.tpl_id_logs
#include tpLink.tpl_encode
