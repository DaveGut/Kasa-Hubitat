library (
	name: "tpl_encode",
	namespace: "tpLink",
	author: "Dave Gutheinz",
	description: "Common data encoding / decoding methods. Hub V 2.5.3",
	category: "utilities",
	documentationLink: ""
)

byte[] getSeed(Integer size) {
    byte[] seed = new byte[size]
    new Random().nextBytes(seed)
    return seed
}

byte[] mdEncode(String hashMethod, byte[] data) {
    MessageDigest digest = MessageDigest.getInstance(hashMethod)
    digest.update(data)
    return digest.digest()
}

String encodeUtf8(String message) {
    return new String(message.getBytes("UTF-8"), "UTF-8")
}

Integer byteArrayToInteger(byte[] bytes) {
    try {
        return ((bytes[0] & 0xFF) << 24) |
               ((bytes[1] & 0xFF) << 16) |
               ((bytes[2] & 0xFF) << 8)  |
               (bytes[3] & 0xFF)
    }
    catch (Exception e) {
        log.warn "byteArrayToInteger: [byteArr: ${bytes}, ERROR: ${e}]"
        return null
    }
}

byte[] integerToByteArray(Integer value) {
    String hexValue = hubitat.helper.HexUtils.integerToHexString(value, 4)
    return hubitat.helper.HexUtils.hexStringToByteArray(hexValue)
}

private String convertHexToIP(String hex) {
    return [
        convertHexToInt(hex[0..1]),
        convertHexToInt(hex[2..3]),
        convertHexToInt(hex[4..5]),
        convertHexToInt(hex[6..7])
    ].join(".")
}

private Integer convertHexToInt(String hex) {
    return Integer.parseInt(hex, 16)
}
