library ( 
	name: "tpl_app_xor",
	namespace: "tpLink",
	author: "Dave Gutheinz",
	description: "Kasa (IOT) Protocol metnods for Kasa/Tapo application. Hub V 2.5.3",
	category: "utilities",
	documentationLink: ""
)

void getXorLanData(response) {
	unschedule("udpTimeout")
	Map logData = [method: "getXorLanData"]
	if (response == "udpTimeout") {
		logData << [response: "udpTimeout", warning: "No devices found"]
	} else {
		logData << [responses: response.size()]
		if (response instanceof Map) {
			atomicState.deviceWait = true
			getXorDiscData(response)
			waitForDevData(5)
		} else {
			response.each {
				atomicState.deviceWait = true
				getXorDiscData(it)
				waitForDevData(5)
			}
		}
	}
	atomicState.findingXor = false
	logInfo(logData)
}

void getXorDiscData(response) {
	Map discData = parseUdp(response, "xor")
	if (discData.status == "ok") {
		String baseUrl = "${discData.ip}:${discData.port}"
		getIotDeviceData(discData.cmdResp, baseUrl, "xor")
	} else {
		atomicState.deviceWait = false
		Map logData = [ method  : "getXorDiscData", status  : "errorInParseUDP",
					   discData: discData]
        logDebug(logData)
    }
}

void getIotDeviceData(cmdResp, baseUrl, protocol) {
	Map sysInfo = cmdResp?.system?.get_sysinfo
	if (!sysInfo) {
		atomicState.deviceWait = false
		logDebug("getIotDeviceData: [status: missingSysInfo]")
		return
	}
	cmdResp = sysInfo	
	def dni
	Map logData = [method: "getIotDeviceData", protocol: protocol]
	if (cmdResp.mic_mac) {
		dni = cmdResp.mic_mac
	} else if (cmdResp.mac) {
		dni = cmdResp.mac.replace(/:/, "")
	} else {
		logData << [alias: cmdResp.alias, cmdResp: cmdResp,
					status: "Failed to add. DNI Not found in response"]
		logDebug(logData)
		atomicState.deviceWait = false
		return
	}
	//	Design to preclude unnecessary processing and also device protocol
	//	ping-pong. For IOT devices, if it has already been found on this 
	//	application session, do not add.
	if (atomicState.iotDevices?.containsKey(dni) && getChildDevice(dni)) {
		logData << [alias: cmdResp.alias, status: "aready in state.iotDevices. Ignored."]
		logInfo(logData)
		atomicState.deviceWait = false
		return
	}
	def kasaType = cmdResp.type
	if (cmdResp.mic_type) { kasaType = cmdResp.mic_type }
	Map device = [api: "iot", baseUrl: baseUrl, model: cmdResp.model, protocol: protocol,
				 manufacturer: "kasa"]
	switch(kasaType) {
		case "IOT.SMARTPLUGSWITCH":
			def type = "Plug Switch"
			if (cmdResp.children) {
				//	if any of the children are installed as legacy, children are added
				//	to devices as devices (vice not installed except the parent)
				def isInstalled = false
				cmdResp.children.each {
					def id = it.id[-2..-1]
					def child = getChildDevice(dni + id)
					if (getChildDevice(dni + id)) { isInstalled = true }
				}
				if (!isInstalled) {
					device << [type: "Parent", alias: cmdResp.alias, deviceId: cmdResp.deviceId]
					device << [hasLed: true]
					addDeviceData(dni, device)
				} else {
					//	In case not all children for the installed device are installed.
					//	plus updated child data for those installed.
					if(cmdResp.led_off) { device << [hasLed: true] }
					if (cmdResp.feature == "TIM:ENE") { device << [isEm : true] }
					cmdResp.children.each {
						Map childDevice = [:]
						childDevice.putAll(device ?: [:])
						def id = it.id[-2..-1]
						def deviceId = cmdResp.deviceId + id
						def alias = it.alias
						def childDni = dni + id
						childDevice << [plugNo: id, deviceId: deviceId, alias: alias, type: type]
						addDeviceData(childDni, childDevice)
					}
				}
			} else {
				if(cmdResp.led_off) { device << [hasLed: true] }
				if (cmdResp.feature == "TIM:ENE") { device << [isEm : true] }
				if (cmdResp.brightness) {
					type = "Dimming Switch"
				}
				device << [type: type, alias: cmdResp.alias, deviceId: cmdResp.deviceId]
				addDeviceData(dni, device)
			}
			break
		case "IOT.SMARTBULB":
			def descr = cmdResp.description
			def isCt = cmdResp.is_variable_color_temp
			def isColor = cmdResp.is_color
			if (descr.contains("Light Strip")) {
				type = "Light Strip"
			} else {
				if (isCt == 0 && isColor == 0) {
					type = "Mono Bulb"
				} else if (isCt == 1 && isColor == 0) {
						device << [ctLow: 2700, ctHigh: 6500]
					type = "CT Bulb"
				} else if (isCt ==1 && isColor == 1) {
					device << [ctLow: 2700, ctHigh: 6500]
					type = "Color Bulb"
				}
			}
			device << [isEm: true, type: type, alias: cmdResp.alias, 
					   deviceId: cmdResp.deviceId]
				addDeviceData(dni, device)
			break
		default: 
			atomicState.deviceWait = false 
			logData << [ "${cmdResp.alias}": "kasaType ${kasaType} is not supported" ] 
			logDebug(logData)
			break
	}
	logDebug(logData)
}

void quickFindXorData(response) {
	unschedule("udpTimeout")
	atomicState.findingXor = false
	Map logData = [method: "quickFindXorData"]
	if (response == "udpTimeout") {
		logData << [response: "udpTimeout", status: "No devices found"]
	} else {
		def foundDevs = 0
		if (response instanceof Map) {
			foundDevs += 1
			def respData = parseUdp(response, "xor")
			updateXorChild(respData)
		} else {
   			 response.each {
        		foundDevs += 1
        		Map respData = parseUdp(it, "xor")
        		updateXorChild(respData)
    		}
		}
		logData << [devicesFound: foundDevs, status: "allSentToParse"]
	}
	logInfo(logData)	
}

void updateXorChild(respData) {
	if (respData.status == "ok") {
		Map sysInfo = respData?.cmdResp?.system?.get_sysinfo
		if (!sysInfo) {
			logDebug("updateXorChild: [status: missingSysInfo]")
			return
		}
		String dni = sysInfo.mic_mac
		if (sysInfo.mac) { dni = sysInfo.mac.replace(/:/, "") }
		String baseUrl = "${respData.ip}:${respData.port}"
		Map devData = [protocol: "xor", baseUrl: baseUrl, version: version()]
		def child = getChildDevice(dni)
		if (child) { child.updateDeviceData(devData) }
	} else {
		logDebug("updateXorChild: [error: not LAN_TYPE_UDPCLIENT]")
	}
}
