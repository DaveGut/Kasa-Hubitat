library (
	name: "tpl_cap_ct",
	namespace: "tpLink",
	author: "Dave Gutheinz",
	description: "kasa-tapo color temperature control. Hub V 2.5.3",
	category: "utilities",
	documentationLink: ""
)

capability "Color Temperature"

def setColorTemperature(colorTemp, level=device.currentValue("level"), transSecs = transTime) {
	level = level ?: device.currentValue("level") ?: 100
	if (level.toInteger() == 0) {
		off()
		return
	}
	if (colorTemp < getDataValue("ctLow").toInteger()) {
		colorTemp = getDataValue("ctLow").toInteger()
	} else if (colorTemp > getDataValue("ctHigh").toInteger()) {
		colorTemp = getDataValue("ctHigh").toInteger()
	}
	int fadeTime = (transSecs ?: settings.transTime ?: 1).toInteger()
	int tTime = fadeTime * 1000	
	if (tTime == 0) { tTime = 10 }
	String api = getDataValue("api")
	Map logData = [method: "setColorTemperature", api: api, 
				   params: [level: level, colorTemp: colorTemp, transTime: transTime]]
	Map params = [brightness: level, color_temp: colorTemp,
				  hue: 0, saturation: 0, "${LIGHT_TRANS_TYPE}": tTime]
	if (api == "smart") {
		params << [device_on: true]
		setSmartColor(params)
	} else {
		params << [ignore_default: 1, on_off: 1]
		setIotColor(params)
	}
	logDebug(logData)
}
