library (
	name: "tpl_prot_xor_udp",
	namespace: "tpLink",
	author: "Dave Gutheinz",
	description: "Xor protocol plus UDP support. Hub V 2.5.3",
	category: "utilities",
	documentationLink: ""
)

//	===== UDP =====
def sendUdp(command, action, baseUrl, timeout = 5) {
	def myHubAction = new hubitat.device.HubAction(
		command,
		hubitat.device.Protocol.LAN, [
			type: hubitat.device.HubAction.Type.LAN_TYPE_UDPCLIENT,
			destinationAddress: baseUrl,
			encoding: hubitat.device.HubAction.Encoding.HEX_STRING,
			ignoreResponse: false,
			parseWarning: true,
			timeout: timeout,
			callback: action])
	try {
		sendHubCommand(myHubAction)
	} catch (error) {
		log.warn "sendLanCmd: command to ${baseUrl} failed. Error = ${error}"
		unschedule("udpTimeout")
	}
}

/*	UDP Timeout is required since the parameter parseWarning does not
	currently work for single polls. */
def udpTimeout(String action = "parseXorResp") {
    switch (action) {
        case "getXorLanData":
            getXorLanData("udpTimeout")
            break

        case "quickFindXorData":
            quickFindXorData("udpTimeout")
            break

        case "getSecureLanData":
            getSecureLanData("udpTimeout")
            break

        case "quickFindSecureData":
            quickFindSecureData("udpTimeout")
            break

        case "parseXorResp":
            parseIotXorResp("udpTimeout")
            break

        case "parseIotXorChildResp":
            parseIotXorChildResp("udpTimeout")
            break

        default:
            logDebug("udpTimeout: [unsupportedAction: ${action}]")
            atomicState.findingXor = false
            atomicState.findingSecure = false
            atomicState.deviceWait = false
    }
}

def parseUdp(message, type) {
	if (message.toString().contains("description")) { message = message.description }
	def resp = parseLanMessage(message)
	if (resp.type == "LAN_TYPE_UDPCLIENT") {
		unschedule("udpTimeout")
		if (device) {
			setCommsError("OK")
		}
		String ip = convertHexToIP(resp.ip)
		String port = convertHexToInt(resp.port)
		String payload = ""
		if (type == "xor") {
			payload = inputXOR(resp.payload)
			if (payload.length() >= 1023) { 
				payload = udpStringCorrect(payload) 
			}
		} else {
			byte[] payloadByte = hubitat.helper.HexUtils.hexStringToByteArray(resp.payload.drop(32))
			payload = new String(payloadByte)
			if (payload.length() >= 1007) {
				payload = udpStringCorrect(payload)
			}
		}
		try {
			Map cmdResp = new JsonSlurper().parseText(payload)
			return [cmdResp: cmdResp, ip: ip, port:port, status: "ok"]
		} catch (err) {
			logWarn("parseUdp: ${err}")
			return [status: "JsonSlurper parse error"]
		}
	} else {
		logDebug("parseUdp: [error: not LAN_TYPE_UDPCLIENT, respType: ${resp.type}]")
		return [status: "Not LAN_TYPE_UDPCLIENT"]
	}
}

/*	Hubitat truncates the UDP return messages at the first response, ignoring
	any additional responses. This attempts to recover the packet so that it
	can be read/parsed by the system. Critical for some IOT devices. */
def udpStringCorrect(payloadString) {
	if (payloadString.count("[") == payloadString.count("]")) {
		payloadString = payloadString.substring(0, payloadString.lastIndexOf("]") + 1)
	} else {
		payloadString = payloadString.substring(0, payloadString.lastIndexOf("["))
		payloadString = payloadString.substring(0, payloadString.lastIndexOf(","))
	}
	def addString = "}" * (1 + payloadString.count("{") - payloadString.count("}"))
	payloadString += addString
	return payloadString
}

private String outputXOR(String command) {
    int key = 0xAB
    StringBuilder encrypted = new StringBuilder()
    command.bytes.each { byte b ->
        int value = (b & 0xFF) ^ key
        key = value
        encrypted.append(String.format('%02x', value))
    }
	return encrypted.toString()
}

private String inputXOR(String encryptedResponse) {
    int key = 0xAB
    StringBuilder decrypted = new StringBuilder()

    encryptedResponse.findAll(/../).each { hexByte ->
        int nextKey = Integer.parseInt(hexByte, 16)
        int value = nextKey ^ key
        key = nextKey
        decrypted.append((char) value)
    }

    return decrypted.toString()
}
