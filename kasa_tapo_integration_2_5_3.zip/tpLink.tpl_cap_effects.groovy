library (
	name: "tpl_cap_effects",
	namespace: "tpLink",
	author: "Dave Gutheinz",
	description: "kasa-tapo lighting effects control. Hub V 2.5.3",
	category: "utilities",
	documentationLink: ""
)

import groovy.transform.Field
@Field static final Map EFFECTS = [
	1: "Aurora", 2: "Bubbling Cauldron", 3: "Candy Cane", 4: "Christmas", 
	5: "Flicker", 6: """Grandma's Christmas Lights""", 7: "Hanukkah",
	8: "Haunted Mansion", 9: "Icicle", 10: "Lightning", 11: "Ocean",
	12: "Rainbow", 13: "Raindrop", 14: "Spring", 15: "Valentines"]
//	Kasa unavailable effects: Sunrise, Sunset

@Field static final List EFFECTS_DATA = [
	[custom:0, id:"TapoStrip_1MClvV18i15Jq3bvJVf0eP", brightness:100, name:"Aurora", enable:1, segments:[0], expansion_strategy:1, display_colors:[[120, 100, 100], [240, 100, 100], [260, 100, 100], [280, 100, 100]], type:"sequence", duration:0, transition:1500, direction:4, spread:7, repeat_times:0, sequence:[[120, 100, 100], [240, 100, 100], [260, 100, 100], [280, 100, 100]]],
	[custom:0, id:"TapoStrip_6DlumDwO2NdfHppy50vJtu", brightness:100, name:"Bubbling Cauldron", enable:1, segments:[0], expansion_strategy:1, display_colors:[[100, 100, 100], [270, 100, 100]], type:"random", hue_range:[100, 270], saturation_range:[80, 100], brightness_range:[50, 100], duration:0, transition:200, init_states:[[270, 100, 100]], fadeoff:1000, random_seed:24, backgrounds:[[270, 40, 50]]],
	[custom:0, id:"TapoStrip_6Dy0Nc45vlhFPEzG021Pe9", brightness:100, name:"Candy Cane", enable:1, segments:[0], expansion_strategy:1, display_colors:[[0, 0, 100], [360, 81, 100]], type:"sequence", duration:700, transition:500, direction:1, spread:1, repeat_times:0, sequence:[[0, 0, 100], [0, 0, 100], [360, 81, 100], [0, 0, 100], [0, 0, 100], [360, 81, 100], [360, 81, 100], [0, 0, 100], [0, 0, 100], [360, 81, 100], [360, 81, 100], [360, 81, 100], [360, 81, 100], [0, 0, 100], [0, 0, 100], [360, 81, 100]]],
	[custom:0, id:"TapoStrip_5zkiG6avJ1IbhjiZbRlWvh", brightness:100, name:"Christmas", enable:1, segments:[0], expansion_strategy:1, display_colors:[[136, 98, 100], [350, 97, 100]], type:"random", hue_range:[136, 146], saturation_range:[90, 100], brightness_range:[50, 100], duration:5000, transition:0, init_states:[[136, 0, 100]], fadeoff:2000, random_seed:100, backgrounds:[[136, 98, 75], [136, 0, 0], [350, 0, 100], [350, 97, 94]]],
	[custom:0, id:"TapoStrip_4HVKmMc6vEzjm36jXaGwMs", brightness:100, name:"Flicker", enable:1, segments:[1], expansion_strategy:1, display_colors:[[30, 81, 100], [40, 100, 100]], type:"random", hue_range:[30, 40], saturation_range:[100, 100], brightness_range:[50, 100], duration:0, transition:0, transition_range:[375, 500], init_states:[[30, 81, 80]]],
	[custom:0, id:"TapoStrip_3Gk6CmXOXbjCiwz9iD543C", brightness:100, name:"""Grandma's Christmas Lights""", enable:1, segments:[0], expansion_strategy:1, display_colors:[[30, 100, 100], [240, 100, 100], [130, 100, 100], [0, 100, 100]], type:"sequence", duration:5000, transition:100, direction:1, spread:1, repeat_times:0, sequence:[[30, 100, 100], [30, 0, 0], [30, 0, 0], [240, 100, 100], [240, 0, 0], [240, 0, 0], [240, 0, 100], [240, 0, 0], [240, 0, 0], [130, 100, 100], [130, 0, 0], [130, 0, 0], [0, 100, 100], [0, 0, 0], [0, 0, 0]]],
	[custom:0, id:"TapoStrip_2YTk4wramLKv5XZ9KFDVYm", brightness:100, name:"Hanukkah", enable:1, segments:[1], expansion_strategy:1, display_colors:[[200, 100, 100]], type:"random", hue_range:[200, 210], saturation_range:[0, 100], brightness_range:[50, 100], duration:1500, transition:0, transition_range:[400, 500], init_states:[[35, 81, 80]]],
	[custom:0, id:"TapoStrip_4rJ6JwC7I9st3tQ8j4lwlI", brightness:100, name:"Haunted Mansion", enable:1, segments:[80], expansion_strategy:2, display_colors:[[45, 10, 100]], type:"random", hue_range:[45, 45], saturation_range:[10, 10], brightness_range:[0, 80], duration:0, transition:0, transition_range:[50, 1500], init_states:[[45, 10, 100]], fadeoff:200, random_seed:1, backgrounds:[[45, 10, 100]]],
	[custom:0, id:"TapoStrip_7UcYLeJbiaxVIXCxr21tpx", brightness:100, name:"Icicle", enable:1, segments:[0], expansion_strategy:1, display_colors:[[190, 100, 100]], type:"sequence", duration:0, transition:400, direction:4, spread:3, repeat_times:0, sequence:[[190, 100, 70], [190, 100, 70], [190, 30, 50], [190, 100, 70], [190, 100, 70]]],
	[custom:0, id:"TapoStrip_7OGzfSfnOdhoO2ri4gOHWn", brightness:100, name:"Lightning", enable:1, segments:[7], expansion_strategy:1, display_colors:[[210, 10, 100], [200, 50, 100], [200, 100, 100]], type:"random", hue_range:[240, 240], saturation_range:[10, 11], brightness_range:[90, 100], duration:0, transition:50, init_states:[[240, 30, 100]], fadeoff:150, random_seed:50, backgrounds:[[200, 100, 100], [200, 50, 10], [210, 10, 50], [240, 10, 0]]],
	[custom:0, id:"TapoStrip_0fOleCdwSgR0nfjkReeYfw", brightness:100, name:"Ocean", enable:1, segments:[0], expansion_strategy:1, display_colors:[[198, 84, 100]], type:"sequence", duration:0, transition:2000, direction:3, spread:16, repeat_times:0, sequence:[[198, 84, 30], [198, 70, 30], [198, 10, 30]]],
	[custom:0, id:"TapoStrip_7CC5y4lsL8pETYvmz7UOpQ", brightness:100, name:"Rainbow", enable:1, segments:[0], expansion_strategy:1, display_colors:[[0, 100, 100], [100, 100, 100], [200, 100, 100], [300, 100, 100]], type:"sequence", duration:0, transition:1500, direction:1, spread:12, repeat_times:0, sequence:[[0, 100, 100], [100, 100, 100], [200, 100, 100], [300, 100, 100]]],
	[custom:0, id:"TapoStrip_1t2nWlTBkV8KXBZ0TWvBjs", brightness:100, name:"Raindrop", enable:1, segments:[0], expansion_strategy:1, display_colors:[[200, 10, 100], [200, 20, 100]], type:"random", hue_range:[200, 200], saturation_range:[10, 20], brightness_range:[10, 30], duration:0, transition:1000, init_states:[[200, 40, 100]], fadeoff:1000, random_seed:24, backgrounds:[[200, 40, 0]]],
	[custom:0, id:"TapoStrip_1nL6GqZ5soOxj71YDJOlZL", brightness:100, name:"Spring", enable:1, segments:[0], expansion_strategy:1, display_colors:[[0, 30, 100], [130, 100, 100]], type:"random", hue_range:[0, 90], saturation_range:[30, 100], brightness_range:[90, 100], duration:600, transition:0, transition_range:[2000, 6000], init_states:[[80, 30, 100]], fadeoff:1000, random_seed:20, backgrounds:[[130, 100, 40]]],
	[custom:0, id:"TapoStrip_2q1Vio9sSjHmaC7JS9d30l", brightness:100, name:"Valentines", enable:1, segments:[0], expansion_strategy:1, display_colors:[[340, 20, 100], [20, 50, 100], [0, 100, 100], [340, 40, 100]], type:"random", hue_range:[340, 340], saturation_range:[30, 40], brightness_range:[90, 100], duration:600, transition:2000, init_states:[[340, 30, 100]], fadeoff:3000, random_seed:100, backgrounds:[[340, 20, 50], [20, 50, 50], [0, 100, 50]]]
]

//	Kasa unavailable effects: 
	
capability "LightEffects"
//attribute "lightEffects", "JSON_OBJECT"
//	For backward compatibility with old rules.
command "setLightingEffect", [[name: "Lighting Effect",
							   constraints: EFFECTS,
							   type: "ENUM"]]
	
def setEffect(effectNumber) {
	Map logData = [method: "setEffect", effectNumber: effectNumber]
	String effectName = EFFECTS[effectNumber.toInteger()]
	if (effectName == null) {
		logData << [status: "effect Number Not In Effects"]
		log.warn logData
	} else {
		setLightingEffect(effectName)
		logDebug(logData)
	}
}

def setNextEffect() {
	String currEffect = device.currentValue("effectName")
	Map logData = [method: "setNextEffect", currEffect: currEffect]
	if (currEffect == null) {
		logData << [ERROR: "Can not setNextEffect with no current effect."]
		log.warn logData
	} else {
		def index = EFFECTS.find { it.value == currEffect }?.key
		int nextEffNo = index + 1
		String effectName = EFFECTS[nextEffNo]
		if (effectName == null) { effectName = EFFECTS[1] }
		logData << [nextEffect: effectName]
		logDebug(logData)
		setLightingEffect(effectName)
	}
}

def setPreviousEffect() {
	String currEffect = device.currentValue("effectName")
	Map logData = [method: "setPreviousEffect", currEffect: currEffect]
	if (currEffect == null) {
		logData << [ERROR: "Can not setPreviousEffect with no current effect."]
		log.warn logData
	} else {
		def index = EFFECTS.find { it.value == currEffect }?.key
		int nextEffNo = index - 1
		String effectName = EFFECTS[nextEffNo]
		if (effectName == null) {
			int lastEffectNo = EFFECTS.size()
			effectName = EFFECTS[lastEffectNo]
		}
		logData << [previousEffect: effectName]
		logDebug(logData)
		setLightingEffect(effectName)
	}
}

def setLightingEffect(effectName) {
	Map logData = [method: "setLigntingEffect", effectName: effectName]
	def api = getDataValue("api")
	Map params = EFFECTS_DATA.find { it.name == effectName }
	if (params != [:]) {
		if (api == "smart") {
			setSmartEffect(params)
		} else {
			setIotEffect(params)
		}
		logDebug(logData)
	} else {
		logData << [error: "parameters not in EFFECTS_DATA"]
		log.warn logData
	}						 
}

def setSmartEffect(params) {
	List requests = [[method: "set_lighting_effect", params: params],
					 [method: "get_device_info"]]
	Map cmdBody = [method: "multipleRequest", params: [requests: requests]]
	sendSmartCmd(cmdBody, false)
}

def parse_lighting_effect(devData) {
	Map logData = [method: "parse_lighting_effect"]
	String effectName = devData.lighting_effect.name
	if (devData.lighting_effect.enable == 1) { 
		sendEvent(name: "effectName", value: devData.lighting_effect.name)
		logData << [effectName: devData.lighting_effect.name]
		logDebug(logData)
	}
}

def setIotEffect(params) {
	Map cmdBody = ["smartlife.iot.lighting_effect": 
//				   [get_lighting_effect: []]]
				   [set_lighting_effect: params, get_lighting_effect: []]]
	sendIotCmd(cmdBody, true)
}

def parse_get_lighting_effect(devData) {
	Map logData = [method: "get_lighting_effect"]
	String effName = devData.get_lighting_effect.name
	if (devData.get_lighting_effect.enable == 0 ) { effName = null }
	sendEvent(name: "effectName", value: effName)
	logData << [effectName: effName]
	logDebug(logData)
}
