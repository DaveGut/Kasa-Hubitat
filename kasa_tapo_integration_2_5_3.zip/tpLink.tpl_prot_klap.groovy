library (
	name: "tpl_prot_klap",
	namespace: "tpLink",
	author: "Dave Gutheinz",
	description: "KLAP protocol. Hub V 2.5.3",
	category: "utilities",
	documentationLink: ""
)

//	Imports for both Klap and AES
import org.json.JSONObject
import groovy.json.JsonOutput
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper
import java.security.spec.PKCS8EncodedKeySpec
import javax.crypto.Cipher
import java.security.KeyFactory
import java.util.Random
import javax.crypto.spec.SecretKeySpec
import javax.crypto.spec.IvParameterSpec
import java.security.MessageDigest

//	===== KLAP synchttp command =====
void sendKlapSyncCmd(cmdBody, retry = false, parseMeth = "parseSmartResp", dni = null) {
	if (retry == true) {
		Map cmdData = [cmdBody: cmdBody, action: parseMeth, retryMeth: "sendKlapSyncCmd"]
		state.cmdData = cmdData
	}
	String cmd = new groovy.json.JsonBuilder(cmdBody).toString()
	byte[] keyByte = new JsonSlurper().parseText(encKey)
	byte[] ivByte = new JsonSlurper().parseText(encIv)
	byte[] sigByte = new JsonSlurper().parseText(encSig)
	String uri = "${getDataValue("baseUrl")}/request?seq=${state.seqNo + 1}"
	Map reqParams = getKlapParams(cmd, keyByte, ivByte, sigByte, state.seqNo, uri, cookie)
	httpPost(reqParams) { resp ->
		if (resp.status == 200 && resp.data != null) {
			byte[] keyBytes = new JsonSlurper().parseText(encKey)
			byte[] ivBytes = new JsonSlurper().parseText(encIv)
			int seqNo = state.seqNo
			byte[] encoded = resp.data.readAllBytes()[32..-1]
			String decoded
			try {
				decoded = klapDecrypt(encoded, keyBytes, ivBytes, seqNo)
			} catch (err) {
				logDebug("sendKlapSyncCmd: [cryptoError: ${err}]")
				runInMillis(200, handleCommsError, [data:"cryptoDecodeError"])
			}
			Map cmdResp = new JsonSlurper().parseText(decoded)
			if (parseMeth == "parseSmartInstData") {
				parseSmartInstData(cmdResp, "httpSync")
			}
		} else {
			logDebug("sendKlapSyncCmd: [httpReturnData: resp.properties]")
			runInMillis(200, handleCommsError, [data: "httpRespError"])
		}
	}
}

//	===== KLAP Smart Support =====
def klapHandshake(baseUrl, localHash, devData = [:]) {
	byte[] localSeed = getSeed(16)
	devData << [localSeed: localSeed, localHash: localHash]
	Map reqParams = [uri: "${baseUrl}/handshake1",
					 headers: ["Connection": "close"],
					 body: localSeed,
					 contentType: "application/octet-stream",
					 requestContentType: "application/octet-stream",
					 timeout: 5
					]
	asynchttpPost("parseKlapHandshake", reqParams, devData)
}

def parseKlapHandshake(resp, devData) {
	String hs1Status = devData.hs1Status
	def tryStatus
	if (resp.status == 200 && resp.data != null) {
		byte[] localSeed = devData.localSeed
		byte[] seedData = resp.data.decodeBase64()
		
		if (!seedData || seedData.size() < 48) {
			devData << [respStatus: "ERROR",
						failNote: "KLAP handshake response too short",
						hs1Status: "failed handshake response"]
		} else {
			byte[] remoteSeed = seedData[0 .. 15]
			byte[] serverHash = seedData[16 .. 47]
			byte[] localHash = devData.localHash.decodeBase64()
			byte[] authHash = [localSeed, remoteSeed, localHash].flatten()
			byte[] localAuthHash = mdEncode("SHA-256", authHash)
			if (localAuthHash == serverHash) {
				//	cookie
				def cookieHeader = resp.headers["Set-Cookie"].toString()
				def cookie = cookieHeader.substring(cookieHeader.indexOf(":") +1, cookieHeader.indexOf(";"))
				//	seqNo and encIv
				byte[] payload = ["iv".getBytes(), localSeed, remoteSeed, localHash].flatten()	
				byte[] fullIv = mdEncode("SHA-256", payload)
				byte[] byteSeqNo = fullIv[-4..-1]
				int seqNo = byteArrayToInteger(byteSeqNo)
				if (device) {
					state.seqNo = seqNo
				}
				//	encKey
				payload = ["lsk".getBytes(), localSeed, remoteSeed, localHash].flatten()
				byte[] encKey = mdEncode("SHA-256", payload)[0..15]
				//	encSig
				payload = ["ldk".getBytes(), localSeed, remoteSeed, localHash].flatten()
				byte[] encSig = mdEncode("SHA-256", payload)[0..27]
				if (device) {
					device.updateSetting("cookie",[type:"password", value: cookie]) 
					device.updateSetting("encKey",[type:"password", value: JsonOutput.toJson(encKey)]) 
					device.updateSetting("encIv",[type:"password", value: JsonOutput.toJson(fullIv[0..11])]) 
					device.updateSetting("encSig",[type:"password", value: JsonOutput.toJson(encSig)]) 
				} else {
					devData << [cookie: cookie, seqNo: seqNo, encIv: fullIv[0..11], 
								encSig: encSig, encKey: encKey]
					}
				byte[] loginHash = [remoteSeed, localSeed, localHash].flatten()
				def hs2CmdStatus = klapHandshake2(loginHash, cookie, devData)
				if (hs2CmdStatus == "OK") {
					tryStatus = "OK"
				} else {
					devData << [failNote: "failed in klapHandshake2"]
					tryStatus = "failure"
				}
			}
		}
	} else {
		devData << [respStatus: resp.status, message: resp.errorMessage,
					failNote: "failed in parseKlapHandshake"]
			tryStatus = "failure"
	}
	if (tryStatus == "failure") {
		if (hs1Status == "tryAltHash") {
			hs1Status = "failed altHash attempt"
		} else {
			hs1Status = "tryAltHash"
		}
	} else {
		hs1Status = "complete"
	}
	devData << [hs1Status: hs1Status]
	if (hs1Status == "tryAltHash") {
		String altHash = altLocalHash
		String baseUrl = devData.baseUrl
		if (device) {
			altHash = parent.altLocalHash
			baseUrl = getDataValue("baseUrl")
		}
		klapHandshake(baseUrl, altHash, devData)
	} else if (hs1Status.contains("fail")) {
		log.warn "parseKlapHandshake: [hs1Status: ${hs1Status}]"
//		if (app) { atomicState.deviceWait = false }
	}
}

def klapHandshake2(loginHash, cookie, devData) {
	def uri = "${devData.baseUrl}/handshake2"
	String status = "OK"
	if (device) { uri = "${getDataValue("baseUrl")}/handshake2" }
	byte[] body = mdEncode("SHA-256", loginHash)
	try {
		Map reqParams = [uri: uri,
						 body: body,
						 timeout: 10,
						 headers: ["Cookie": cookie, "Connection": "close"],
						 contentType: "application/octet-stream",
						 requestContentType: "application/octet-stream"]
		asynchttpPost("parseKlapHandshake2", reqParams, devData)
	} catch (err) {
		status = "klapHandshake2Error"
		Map logData = [method: "klapHandshake2", status: status, error: err]
		log.warn logData
	}
	return status
}

def parseKlapHandshake2(resp, devData) {
	Map logData = [method: "parseKlapHandshake2", devData: devData]
	if (resp.status == 200) {
		logData << [respStatus: "Login OK"]
		if (device) {
			setCommsError("OK")
			runIn(1, refresh)
		} else {
			sendKlapDataCmd(devData)
		}
		logDebug(logData)
	} else {
		logData << [respStatus: "LOGIN FAILED", reason: "ERROR in HTTP response",
					resp: resp.properties]
		log.warn logData 
	}
}

def getKlapParams(cmd, encKey, encIv, encSig, seqNo, uri, cookie) {
	seqNo = seqNo + 1
	if (device) { state.seqNo = seqNo }
	Map encryptedData = klapEncrypt(cmd.getBytes(), encKey, 
									encIv, encSig, seqNo)
	Map reqParams = [
		uri: uri,
		body: encryptedData.cipherData,
		headers: ["Cookie": cookie, "Connection": "close"],
		contentType: "application/octet-stream",
		requestContentType: "application/octet-stream",
		timeout: 5,
		ignoreSSLIssues: true]
	return reqParams
}

def parseKlapData(resp) {
	Map parseData = [parseMethod: "parseKlapData"]
	try {
		byte[] keyBytes = new JsonSlurper().parseText(encKey)
		byte[] ivBytes = new JsonSlurper().parseText(encIv)
		int seqNo = state.seqNo
		byte[] cipherResponse = resp.data.decodeBase64()[32..-1]
		Map cmdResp =  new JsonSlurper().parseText(
			klapDecrypt(cipherResponse, keyBytes, ivBytes, seqNo))
		parseData << [cryptoStatus: "OK", cmdResp: cmdResp]
	} catch (err) {
		parseData << [cryptoStatus: "decryptDataError", error: err]
	}
	return parseData
}

//	===== Encryption =====
def klapEncrypt(byte[] request, encKey, encIv, encSig, seqNo) {
	byte[] encSeqNo = integerToByteArray(seqNo)
	byte[] ivEnc = [encIv, encSeqNo].flatten()
	def cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
	SecretKeySpec key = new SecretKeySpec(encKey, "AES")
	IvParameterSpec iv = new IvParameterSpec(ivEnc)
	cipher.init(Cipher.ENCRYPT_MODE, key, iv)
	byte[] cipherRequest = cipher.doFinal(request)

	byte[] payload = [encSig, encSeqNo, cipherRequest].flatten()
	byte[] signature = mdEncode("SHA-256", payload)
	cipherRequest = [signature, cipherRequest].flatten()
	return [cipherData: cipherRequest, seqNumber: seqNo]
}

def klapDecrypt(cipherResponse, encKey, encIv, seqNo) {
	byte[] encSeqNo = integerToByteArray(seqNo)
	byte[] ivEnc = [encIv, encSeqNo].flatten()
	def cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
    SecretKeySpec key = new SecretKeySpec(encKey, "AES")
	IvParameterSpec iv = new IvParameterSpec(ivEnc)
    cipher.init(Cipher.DECRYPT_MODE, key, iv)
	byte[] byteResponse = cipher.doFinal(cipherResponse)
	return new String(byteResponse, "UTF-8")
}
