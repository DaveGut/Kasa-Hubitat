library (
	name: "tpl_prot_aes",
	namespace: "tpLink",
	author: "Dave Gutheinz",
	description: "AES protocol. Hub V 2.5.3",
	category: "utilities",
	documentationLink: ""
)
//	AES protocol was deprecated by TP-Link aroung 2021 and for (all?) devices. 
//	the firmware updated transitioned to KLAP. There may still be some devices
//	out there; so this code is necessary. Unfortunately, no testing since all
//	of the developers devices were transitioned long ago.
//	===== AES Smart Support =====
def aesHandshake(baseUrl, devData = [:]) {
	Map rsaKey = getRsaKey()
	devData << [baseUrl: baseUrl, rsaKey : rsaKey]
	String pubPem = "-----BEGIN PUBLIC KEY-----\n" + 
		"${rsaKey.public}" + "-----END PUBLIC KEY-----\n"
	Map cmdBody = [method: "handshake", params: [key: pubPem]]
	Map reqParams = [uri: baseUrl,
					 headers: ["Connection": "close"],
					 body: new JsonBuilder(cmdBody).toString(),
					 requestContentType: "application/json",
					 timeout: 5 ]
   asynchttpPost("parseAesHandshake", reqParams, devData)
}


def parseAesHandshake(resp, devData){
	Map logData = [method: "parseAesHandshake"]
	if (resp.status == 200 && resp.data != null) {
		try {
			Map cmdResp =  new JsonSlurper().parseText(resp.data)
			def cookieHeader = resp.headers["Set-Cookie"].toString()
			def cookie = cookieHeader.substring(cookieHeader.indexOf(":") +1, cookieHeader.indexOf(";"))
			byte[] privateKeyBytes = devData.rsaKey.private.decodeBase64()
			byte[] deviceKeyBytes = cmdResp.result.key.getBytes("UTF-8").decodeBase64()
    		Cipher instance = Cipher.getInstance("RSA/ECB/PKCS1Padding")
			instance.init(2, KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(privateKeyBytes)))
			byte[] cryptoArray = instance.doFinal(deviceKeyBytes)
			byte[] encKey = cryptoArray[0..15]
			byte[] encIv = cryptoArray[16..31]
			logData << [respStatus: "Cookies/Keys Updated", cookie: cookie,
						encKey: encKey, encIv: encIv]
			String password = encPassword
			String username = encUsername
			if (device) {
				password = parent.encPassword
				username = parent.encUsername
				device.updateSetting("cookie",[type:"password", value: cookie])
				device.updateSetting("encKey", [type:"password", value: JsonOutput.toJson(encKey)])
				device.updateSetting("encIv", [type:"password",value: JsonOutput.toJson(encIv)])
			} else {
				devData << [cookie: cookie, encIv: encIv, encKey: encKey]
			}
			//	Login to the device
			Map cmdBody = [method: "login_device",
						   headers: ["Connection": "close"],
						   params: [password: password,
									username: username],
						   requestTimeMils: 0]
			def cmd = JsonOutput.toJson(cmdBody).toString()
			Map reqParams = getAesParams(cmd, encKey, encIv, devData.baseUrl, cookie)
			asynchttpPost("parseAesLogin", reqParams, devData)
			logDebug(logData)
		} catch (err) {
			atomicState.deviceWait = false
			logData << [respStatus: "ERROR parsing HTTP resp.data",
						respData: resp.data, error: err]
			log.warn logData 
		}
	} else {
		atomicState.deviceWait = false
		logData << [respStatus: "ERROR in HTTP response", resp: resp.properties]
		log.warn logData 
	}
}

def parseAesLogin(resp, devData) {
	Map logData = [method: "parseAesLogin"]
	if (resp.status == 200 && resp?.json) {
		if (resp.json.error_code == 0) {
			try {
				byte[] keyBytes
				byte[] ivBytes
				if (device) {
					keyBytes = new JsonSlurper().parseText(encKey) as byte[]
					ivBytes = new JsonSlurper().parseText(encIv) as byte[]
				} else {
					keyBytes = devData.encKey as byte[]
					ivBytes = devData.encIv as byte[]
				}
				String clearResp = aesDecrypt(resp.json.result.response,
											  keyBytes, ivBytes)				
				Map cmdResp = new JsonSlurper().parseText(clearResp)
				if (cmdResp.error_code == 0) {
					def token = cmdResp.result.token
					logData << [respStatus: "OK", token: token]
					if (device) {
						device.updateSetting("token",[type:"password", value: token])
						setCommsError("OK")
						runIn(1, refresh)
					} else {
						devData << [token: token]
						sendAesDataCmd(devData)
					}
					logDebug(logData)
				} else {
					atomicState.deviceWait = false
					logData << [respStatus: "ERROR code in cmdResp", 
								error_code: cmdResp.error_code,
								check: "cryptoArray, credentials", data: cmdResp]
					log.debug logData
				}
			} catch (err) {
				atomicState.deviceWait = false
				logData << [respStatus: "ERROR parsing respJson", respJson: resp.json,
							error: err]
				log.debug logData
			}
		} else {
			atomicState.deviceWait = false
			logData << [respStatus: "ERROR code in resp.json", errorCode: resp.json.error_code,
						respJson: resp.json]
			log.debug logData
		}
	} else {
		atomicState.deviceWait = false
		logData << [respStatus: "ERROR in HTTP response", respStatus: resp.status, data: resp.properties]
		log.warn logData
	}
}

def getAesParams(cmd, encKey, encIv, uri, cookie) {
	Map reqBody = [method: "securePassthrough",
				   params: [request: aesEncrypt(cmd, encKey, encIv)]]
	Map reqParams = [uri: uri,
					 body: new groovy.json.JsonBuilder(reqBody).toString(),
					 contentType: "application/json",
					 requestContentType: "application/json",
					 timeout: 5,
					 headers: ["Cookie": cookie]]
	return reqParams
}

def parseAesData(resp) {
	Map parseData = [parseMethod: "parseAesData"]
	try {
		byte[] keyBytes = new JsonSlurper().parseText(encKey)
		byte[] ivBytes = new JsonSlurper().parseText(encIv)
		Map cmdResp = new JsonSlurper().parseText(aesDecrypt(resp.json.result.response,
														 keyBytes, ivBytes))
		parseData << [cryptoStatus: "OK", cmdResp: cmdResp]
	} catch (err) {
		parseData << [cryptoStatus: "decryptDataError", error: err]
	}
	return parseData
}

def getRsaKey() {
	return [public: "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDGr/mHBK8aqx7UAS+g+TuAvE3J2DdwsqRn9MmAkjPGNon1ZlwM6nLQHfJHebdohyVqkNWaCECGXnftnlC8CM2c/RujvCrStRA0lVD+jixO9QJ9PcYTa07Z1FuEze7Q5OIa6pEoPxomrjxzVlUWLDXt901qCdn3/zRZpBdpXzVZtQIDAQAB",
			private: "MIICeAIBADANBgkqhkiG9w0BAQEFAASCAmIwggJeAgEAAoGBAMav+YcErxqrHtQBL6D5O4C8TcnYN3CypGf0yYCSM8Y2ifVmXAzqctAd8kd5t2iHJWqQ1ZoIQIZed+2eULwIzZz9G6O8KtK1EDSVUP6OLE71An09xhNrTtnUW4TN7tDk4hrqkSg/GiauPHNWVRYsNe33TWoJ2ff/NFmkF2lfNVm1AgMBAAECgYEAocxCHmKBGe2KAEkq+SKdAxvVGO77TsobOhDMWug0Q1C8jduaUGZHsxT/7JbA9d1AagSh/XqE2Sdq8FUBF+7vSFzozBHyGkrX1iKURpQFEQM2j9JgUCucEavnxvCqDYpscyNRAgqz9jdh+BjEMcKAG7o68bOw41ZC+JyYR41xSe0CQQD1os71NcZiMVqYcBud6fTYFHZz3HBNcbzOk+RpIHyi8aF3zIqPKIAh2pO4s7vJgrMZTc2wkIe0ZnUrm0oaC//jAkEAzxIPW1mWd3+KE3gpgyX0cFkZsDmlIbWojUIbyz8NgeUglr+BczARG4ITrTV4fxkGwNI4EZxBT8vXDSIXJ8NDhwJBAIiKndx0rfg7Uw7VkqRvPqk2hrnU2aBTDw8N6rP9WQsCoi0DyCnX65Hl/KN5VXOocYIpW6NAVA8VvSAmTES6Ut0CQQCX20jD13mPfUsHaDIZafZPhiheoofFpvFLVtYHQeBoCF7T7vHCRdfl8oj3l6UcoH/hXMmdsJf9KyI1EXElyf91AkAvLfmAS2UvUnhX4qyFioitjxwWawSnf+CewN8LDbH7m5JVXJEh3hqp+aLHg1EaW4wJtkoKLCF+DeVIgbSvOLJw"]
}

//	=====	Encryption ======
def aesEncrypt(request, encKey, encIv) {
	def cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
	SecretKeySpec key = new SecretKeySpec(encKey, "AES")
	IvParameterSpec iv = new IvParameterSpec(encIv)
	cipher.init(Cipher.ENCRYPT_MODE, key, iv)
	String result = cipher.doFinal(request.getBytes("UTF-8")).encodeBase64().toString()
	return result.replace("\r\n","")
}

def aesDecrypt(cipherResponse, encKey, encIv) {
    byte[] decodedBytes = cipherResponse.decodeBase64()
	def cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
    SecretKeySpec key = new SecretKeySpec(encKey, "AES")
	IvParameterSpec iv = new IvParameterSpec(encIv)
    cipher.init(Cipher.DECRYPT_MODE, key, iv)
	return new String(cipher.doFinal(decodedBytes), "UTF-8")
}
