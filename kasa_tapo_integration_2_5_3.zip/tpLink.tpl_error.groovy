library (
	name: "tpl_error",
	namespace: "tpLink",
	author: "Dave Gutheinz",
	description: "Error processing. Hub V 2.5.3",
	category: "utilities",
	documentationLink: ""
)

def handleCommsError(status) {
	if (status == "OK" || status == 200) {
		setCommsError("OK")
	} else {
		errorCount = state.errorCount + 1
		state.errorCount = errorCount
		Map logData = [method: "handleCommsError", status: status, errorCount: errorCount]
		switch (errorCount) {
			case 1:
			case 2:
				sendRetry()
				break
			case 3:
				configure()
				runIn(10, sendRetry)
				break
			case 4:
				sendRetry()
				break
			default:
				logData << [action: "SetCommsErrorTrue"]
				setCommsError(status, state.errorCount)
				break
		}
		logDebug(logData)
	}
}

void sendRetry(Map cmdData = state.cmdData) {
	Map cmdBody = cmdData.cmdBody
	String action = cmdData.action
	String retryMeth = cmdData.retryMeth
	"${retryMeth}"(cmdBody, true, action)
}

def setCommsError(status, count = 0) {
	if (status == "OK") {
		state.errorCount = 0
		if (device.currentValue("commsError") == "true") {
			Map logData = [method: "setCommsError", status: status, count: count]
			sendEvent(name: "commsError", value: "false")
			logData << setPollInterval(systemPoll)
			state.cmdData = null
			unschedule("errorConfigure")
			logDebug(logData)
		}
	} else {
		Map logData = [method: "setCommsError", status: status, count: count]
		if (device.currentValue("commsError") == "false") {
			sendEvent(name: "commsError", value: "true")
			logData << setPollInterval("15 min")
			runEvery1Hour(errorConfigure)
			logData << [quickPolling: "off", errorConfigure: "ever hour"]
			if (status == 403) {
				logData << [loginError: loginErrorAction()]
			} else {
				logData << [lanError: lanErrorAction()]
			}
			log.warn logData
		} else {
			logData << [error: "Unspecified Error"]
			logDebug(logData)
		}
	}
}

def errorConfigure() {
	logDebug([method: "errorConfigure"])
	if (device.currentValue("commsError") == "true") {
		configure()
	} else {
		unschedule("errorConfigure")
	}
}

def lanErrorAction() {
	def action = "Likely cause of this error is YOUR LAN device configuration: "
	action += "a. VERIFY your device is on the DHCP list in your router, "
	action += "b. VERIFY your device is in the active device list in your router, and "
	action += "c. TRY controlling your device from the TAPO phone app."
	return action
}

def loginErrorAction() {
	def action = "Likely cause is your login credentials are incorrect or the login has expired. "
	action += "a. RUN command Configure. b. If error persists, check your credentials in the App"
	return action
}
