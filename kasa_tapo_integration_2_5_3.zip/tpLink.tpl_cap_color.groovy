library (
	name: "tpl_cap_color",
	namespace: "tpLink",
	author: "Dave Gutheinz",
	description: "kasa-tapo color control. Hub V 2.5.3",
	category: "utilities",
	documentationLink: ""
)

capability "Color Mode"
capability "Color Control"

def setHue(hue) {
	Map color = [level: device.currentValue("level").toInteger(),
				 hue: hue, 
				 saturation: device.currentValue("saturation").toInteger()]
	setColor(color)
}

def setSaturation(saturation) { 
	Map color = [level: device.currentValue("level").toInteger(),
				 hue: device.currentValue("hue").toInteger(), 
				 saturation: saturation]
	setColor(color)
}

def setRGB(rgb) {
	def rgbArray = rgb.split('\\,')
	def hsvData = hubitat.helper.ColorUtils.rgbToHSV([rgbArray[0].toInteger(), rgbArray[1].toInteger(), rgbArray[2].toInteger()])
	def hue = (0.5 + hsvData[0]).toInteger()
	def saturation = (0.5 + hsvData[1]).toInteger()
	def level = (0.5 + hsvData[2]).toInteger()
	def Map color = [
		hue: hue,
		saturation: saturation,
		level: level
		]
	setColor(color)
}

def setColor(Map color, transTime = transTime) {
	def api = getDataValue("api")
	Map logData = [method: "setColor", api: api, 
				   params: [brightness: color.level, hue: color.hue, saturation: color.saturation]]
	int hubHue = Math.round(0.49 + color.hue.toInteger() * 3.6).toInteger()
	int level = color.level.toInteger()
	int saturation = color.saturation.toInteger()
	int tTime = 1000 * transTime.toInteger()
	if (color.rate) { tTime = 1000 * color.rate.toInteger() }
	if (tTime == 0) { tTime = 10 }
	Map params = [brightness: level, color_temp: 0, hue: hubHue, 
				  saturation: saturation, "${LIGHT_TRANS_TYPE}": tTime]
	if (getDataValue("api") == "smart") {
		params << [device_on: true]
		setSmartColor(params)
	} else {
		params << [ignore_default: 1, on_off: 1]
		setIotColor(params)
	}
	logDebug(logData)
}

@Field static Map ANIM_LIMITS = [
	level: [min: 5,    max: 100],
	hue:  [min: 0,    max: 100],
	saturation:  [min: 0,    max: 100],
	colorTemp:  [min: 2700,    max: 6500],
	rate:  [min: 0,    max: 10000],
	onOff: [min: 0, max: 1]
]

command "setLightWithTransition", [[
	name: "Custom transition for lighting",
	type: "STRING",
	title: "enter key:value pairs followed by commas",
	description: "enter key:value pairs followed by commas"]]

def setLightWithTransition(inputs) {
	Map logData = [method: "setLightWithTransition", input: inputs]
	Boolean paramsOK = true
	Map inputParams = [:]
	inputs.split(',').each { item ->
		def (k, v) = item.split(':', 2)*.trim()
		inputParams[k] = v.isInteger() ? v.toInteger() : v
	}
	//	range-check entered params.
	inputParams.each { key, v ->
		def r = ANIM_LIMITS[key]
		if (r && (v < r.min || v > r.max)) {
			logData << ["${key}": "${v} out of limits"]
				paramsOK = false
		}
	}
	if (paramsOK == true) {
		Map params = [:]
		//	If rate/level not sent, use currentValue
		int rate = inputParams.rate
		int onOff = 1
		if (inputParams.onOff == 0) { onOff = 0 }
		if (onOff != 0) {
			int level = device.currentValue("level").toInteger()
			if (inputParams.level) { level = inputParams.level }
				params = [brightness: level]
			if (inputParams.color_temp && inputParams.color_temp >= 2700)  {
				//	if color_temp is >= 2700, do a colorTemperature transition.
				params << [hue: 0, saturation: 0, color_temp: inputParams.color_temp]
			} else {
				//	if hue or saturation is null, use currentValue
				int hue = device.currentValue("hue")
				if(inputParams.hue) { hue = inputParams.hue }
				int hubHue = Math.round(0.49 + hue.toInteger() * 3.6).toInteger()
				int saturation = device.currentValue("saturation")
				if(inputParams.saturation) { saturation = inputParams.saturation }
				params << [hue: hubHue, saturation: saturation, color_temp: 0]
			}
		}
		if (getDataValue("api") == "smart") {
			deviceOn = true
			if (onOff == 0) { deviceOn = false }
			params << [device_on: deviceOn, "${LIGHT_TRANS_TYPE}": rate]
			logData << [params: params]
			setSmartColor(params)
		} else {
			params << [ignore_default: 1, on_off: onOff, "${LIGHT_TRANS_TYPE}": rate]
			logData << [params: params]
			setIotColor(params)
		}
	}
	logDebug(logData)
}
