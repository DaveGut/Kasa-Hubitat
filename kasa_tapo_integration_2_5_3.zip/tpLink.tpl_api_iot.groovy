library (
	name: "tpl_api_iot",
	namespace: "tpLink",
	author: "Dave Gutheinz",
	description: "IOT Protocol-specific methods. Hub V 2.5.3",
	category: "utilities",
	documentationLink: ""
) 

//	===== Device Capability Commands =====
void iotRefresh() {
	state.eventType = "digital"
	Map cmdBody = [system: [get_sysinfo: []]]
	sendIotCmd(cmdBody, true)
	if (emEnable) {runIn(1, iotGetRealtime) }
}

void iotPoll() {
	state.eventType = "manual"
	Map cmdBody = [system: [get_sysinfo: []]]
	sendIotCmd(cmdBody, true)
	if (emEnable) {runIn(1, iotGetRealtime) }
}

//	Used in multiple drivers / capabilities
def setIotColor(params) {
	Map cmdBody = ["${SYSTEM}": ["${LIGHT_CMD}": params]]
	sendIotCmd(cmdBody, true)
	if (emEnable) { runIn(5, iotGetRealtime) }
}

//	===== Iot Implementation Interface =====
def sendIotCmd(cmdBody, retry = false, action = null, dni = null) {
	String cmd = new groovy.json.JsonBuilder(cmdBody).toString()
	if (retry == true) {
		Map cmdData = [cmdBody: cmdBody, action: action, retryMeth: "sendIotCmd"]
		state.cmdData = cmdData
	}
	if (getDataValue("protocol") == "xor") {
		logDebug("[method: sendIotCmd(XOR), cmdBody: $cmdBody, RETRY: $retry]")
//	Insturmentation point for testing	
//log.info "[method: sendIotCmd(XOR), cmdBody: $cmdBody, RETRY: $retry]"
		if (action == null) { action = "parseIotXorResp" }
		if (retry == true) {
			runIn(10, udpTimeout)
		}
		sendUdp(outputXOR(cmd), action, getDataValue("baseUrl"))
	} else {
		logDebug("[method: sendIotCmd(SMART), cmdBody: $cmdBody, RETRY: $retry]")
//	Insturmentation point for testing	
//log.info "[method: sendIotCmd(SMART), cmdBody: $cmdBody, RETRY: $retry]"
		if (action == null) { action = "parseIotKlapResp" }
		if (encKey == null) {
			//	Only encountered on transition from XOR to UPD first time
			//	and does not impact transition.
			return
		}
		byte[] keyByte = new JsonSlurper().parseText(encKey)
		byte[] ivByte = new JsonSlurper().parseText(encIv)
		byte[] sigByte = new JsonSlurper().parseText(encSig)
		String uri = "${getDataValue("baseUrl")}/request?seq=${state.seqNo + 1}"
		Map reqParams = getKlapParams(cmd, keyByte, ivByte, sigByte, state.seqNo, uri, cookie)
		asynchttpPost(action, reqParams, [data: [dni:dni, retry: retry]])
	}
}

def iotNullParse(message) {}

def parseIotXorResp(message) {
	if (message == "udpTimeout") {
		if (systemPoll.contains("min")) {
			handleCommsError(message)
			Map logData = [method: "parseXorResp", error: message]
			logDebug(logData)
		}
	} else {
		Map respData = parseUdp(message, "xor")
		if (respData.status == "ok") {
			setCommsError("OK")
			respData.cmdResp.each { key, devData ->
				distIotData(key, devData)
			}
		} else {
			Map logData = [method: "parseXorResp", respData: respData]
			logWarn(logData)
		}
	}
}

def parseIotKlapResp(resp, data) {
	def respData = parseKlapAesResp(resp)
	def cryptoStatus = respData.cryptoStatus
	if (resp.status == 200 && cryptoStatus == "OK") {
		setCommsError("OK")
		respData.cmdResp.each { key, devData ->
			distIotData(key, devData)
		}
	} else {
		Map logData = [method: "parseIotKlapResp", retry: data.retry, 
					   httpStatus: resp.status, cryptoStatus: cryptoStatus]
		if (data.retry == true && systemPoll.contains("min")) {
			handleCommsError([httpStatus: resp.status, cryptoStatus: cryptoStatus])
		}
		logDebug(logData)
	}
}

void distIotData(key, devData) {
	logDebug("[method: distIotData: $key: $devData]")
//	Insturmentation point for testing	
//log.info "[method: distIotData: $key: $devData]"
	switch(key) {
		case "system":
			if (devData.get_sysinfo) {
				devData = devData.get_sysinfo
				if (nameSync != "no") {
					parseNameUpdate(devData)
				}
				if (devData.light_state) {
					devData = devData.light_state
				}
				parse_system(devData)
			}
			break
		case "get_light_state":
			parse_system(devData)
			break
		case "smartlife.iot.smartbulb.lightingservice":
			parse_system(devData.transition_light_state)
			break
		case "smartlife.iot.lightStrip":
			iotRefresh()
			break
		case "smartlife.iot.dimmer":
			if(devData.get_dimmer_parameters) {
				parse_get_dimmer_parameters(devData.get_dimmer_parameters)
			}
			break
		case "smartlife.iot.common.emeter":
		case "emeter":
			parse_emeter(devData)
			break
		case "smartlife.iot.common.system":
			if (devData.reboot) {
				runIn(10, updated) 
			}
			break
		default:
			Map logData = [method: "distIotData", key: key, devData: devData, status: "unprocessed"]
			logDebug(logData)
	}
}
