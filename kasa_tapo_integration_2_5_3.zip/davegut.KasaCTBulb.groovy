/*	tpLink Integration Driver: tpLinkCT Bulb
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md
Notes:
*/ 

String nameSpace() { return "davegut" }
String version() { return "2.5.3" }


import groovy.transform.Field
@Field static final String DEV_TYPE = "CT Bulb"
@Field static final String EM_SYS = "smartlife.iot.common.emeter"
@Field static final Boolean IS_CHILD = false
@Field static final String LIGHT_TRANS_TYPE = "transition_period"
@Field static final String SYSTEM = "smartlife.iot.smartbulb.lightingservice"
@Field static final String LIGHT_CMD = "transition_light_state"

metadata {
	definition (name: "Kasa CT Bulb",
				namespace: nameSpace(), 
				author: "Dave Gutheinz", 
				singleThreaded: true
			   ) 
	{
		capability "Bulb"
		capability "Light"
	}
	preferences {
		emPrefs()
		levelPrefs()
		commonPrefs()
	}
}

def installed() {
	Map instStatus = [method: "installed"]
	instStatus << commonInstalled()
	logInfo(instStatus)
	deviceHandshake()
	runIn(5, updated)
}

def updated() {
	Map updStatus = [method: "updated"]
	unschedule()
	updStatus << [commonUpdated: commonUpdated()]
	updStatus << [levelUpdated: levelUpdated()]
	if (getDataValue("isEm")) { updStatus << [emUpdated: emUpdated()] }
	logInfo(updStatus)
	runIn(2, deviceHandshake)
}

def setCtLight(onOff, level, colorTemp) {
	sendEvent(name: "switch", value: onOff, type: state.eventType)
	if (onOff == "on") {
		colorName = convertTemperatureToGenericColorName(colorTemp)
		sendEvent(name: "level", value: level)
		sendEvent(name: "colorTemperature", value: colorTemp)
		sendEvent(name: "colorName", value: colorName)
		sendEvent(name: "colorMode", value: "CT")
	}
	Map logData = [method: "setCtLight", onOff: onOff, level: level, colorTemp: colorTemp]
	logDebug(logData)
}

//	===== Smart Methods =====
def parse_get_device_info(devData) {
	def onOff = "off"
	if (devData.device_on == true) { onOff = "on" }
	int level = devData.brightness.toInteger()
	int colorTemp = devData.color_temp.toInteger()
	setCtLight(onOff, level, colorTemp)
	if (emEnable) { smartPowerRefresh() }
}

//	===== IOT Methods =====
def parse_system(devData) {
	def onOff = "on"
	if (devData.on_off == 0) {
		onOff = "off"
		devData = devData.dft_on_state
	}
	int level = devData.brightness.toInteger()
	int colorTemp = devData.color_temp.toInteger()
	setCtLight(onOff, level, colorTemp)
}

//	===== Include Libraries =====
#include tpLink.tpl_cap_switch
#include tpLink.tpl_cap_level
#include tpLink.tpl_cap_ct
#include tpLink.tpl_cap_em
#include tpLink.tpl_dev_common
#include tpLink.tpl_api_smart
#include tpLink.tpl_api_iot
#include tpLink.tpl_prot_klap
#include tpLink.tpl_prot_aes
#include tpLink.tpl_prot_xor_udp
#include tpLink.tpl_id_logs
#include tpLink.tpl_encode
#include tpLink.tpl_error
