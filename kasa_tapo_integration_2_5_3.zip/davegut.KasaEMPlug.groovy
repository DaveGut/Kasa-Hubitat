/*	tpLink Integration Driver: tpLinkCT Bulb
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md
*/

String nameSpace() { return "davegut" }
String version() { return "2.5.3" }


import groovy.transform.Field
@Field static final String DEV_TYPE = "Plug Switch"
@Field static final String EM_SYS = "emeter"
@Field static final Boolean IS_CHILD = false
@Field static final String SYSTEM = "system"

//	This dirver is replicated as four drivers for backward compatibility with 2018 code.
metadata {
	definition (name: "Kasa EM Plug",
				namespace: nameSpace(), 
				author: "Dave Gutheinz", 
				singleThreaded: true
			   ) 
	{
	}
	preferences {
		emPrefs()
		commonPrefs()
	} 
}

def installed() {
	Map instStatus = [method: "installed"]
	instStatus << commonInstalled()
	logInfo(instStatus)
	deviceHandshake()
	runIn(5, updated)
} 

def updated() {
	Map updStatus = [method: "updated"]
	unschedule()
	updStatus << [commonUpdated: commonUpdated()]
	if (getDataValue("isEm")) { updStatus << [emUpdated: emUpdated()] }
	logInfo(updStatus)
}

def setSwitch(onOff) {
	Map logData = [method: "setSwitch", switch: onOff, eventType: state.eventType]
	sendEvent(name: "switch", value: onOff, type: state.eventType)
	logDebug(logData)
}

//	===== Smart Methods =====
def parse_get_device_info(devData) {
	def onOff = "off"
	if (getDataValue("api") == "smart") {
		if (devData.device_on == true) { onOff = "on" }
	}
	setSwitch(onOff)
}

//	===== IOT Methods =====
def parse_system(devData) {
	def onOff = "off"
	if (devData.relay_state == 1) { 
		onOff = "on"
	} else if (devData.children) {
		def childStatus = devData.children.find { it.id == getDataValue("plugNo").toString() }
		if (childStatus == null) {
			childStatus = devData.children.find { it.id == getDataValue("deviceId").toString() }
		}
		if (childStatus?.state == 1) { onOff = "on" }
	}
	setSwitch(onOff)
}

//	===== Include Libraries =====
#include tpLink.tpl_cap_switch
#include tpLink.tpl_cap_em
#include tpLink.tpl_dev_common
#include tpLink.tpl_api_smart
#include tpLink.tpl_api_iot
#include tpLink.tpl_prot_klap
#include tpLink.tpl_prot_aes
#include tpLink.tpl_prot_xor_udp
#include tpLink.tpl_id_logs
#include tpLink.tpl_encode
#include tpLink.tpl_error
