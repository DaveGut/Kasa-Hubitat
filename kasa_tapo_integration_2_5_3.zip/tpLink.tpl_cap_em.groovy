library (
	name: "tpl_cap_em",
	namespace: "tpLink",
	author: "Dave Gutheinz",
	description: "IOT/Smart Energy Monitor Methods. Hub V 2.5.3",
	category: "energyMonitor",
	documentationLink: ""
)

capability "Power Meter"
capability "Energy Meter"

def emPrefs() {
	if (getDataValue("isEm")) {
		input ("emEnable", "bool", title: "Enable Energy Monitoring", defaultValue: false)
	}
}

def emUpdated() {
	def updStatus = [:]
	if (getDataValue("api") == "iot") {
		if (!state.energyYesterday) {
			state.energyYesterday = 0
			updStatus << [initialized: "energyYesterday", 
				NOTE: "FOR TODAY, energy WILL BE FROM DEVICE INSTALLATION"]
			setTotWhPrev()
		}
		schedule("0 1 0 * * ?", "setTotWhPrev")
	}
	if (emEnable) {
		runEvery30Minutes("energyRefresh")
		runIn(10, energyRefresh)
	}
	return updStatus
}

def setTotWhPrev() {
	state.settingWhPrev = true
	int delay = 1
	if (IS_CHILD) {
		//	Vary delay to avoid collisions at actual device.
		delay = getDataValue("deviceId")[-1].toInteger()
	}
	runIn(2*delay, iotEnergyRefresh)
	logDebug([method: "setTotWhPrev", status: "Updating yesterday's total watt hours"])
}

def energyRefresh() {
	if (getDataValue("api") == "smart") { 
		smartEnergyRefresh()
	} else {
		iotEnergyRefresh()
	}
}

//	===== Smart API Calls =====
def smartPowerRefresh() {
	state.eventType = "digital"
	getSmartPower()
}

def smartPowerPoll() {
	state.eventType = "manual"
	getSmartPower()
}

def getSmartPower() {
	List requests = [[method: "get_current_power"]]
	Map cmdBody = [method: "multipleRequest", params: [requests: requests]]
	if (IS_CHILD) {
		Map commandData = [cmdBody: cmdBody, retry: false, devId: getDataValue("deviceId"), 
						   dni: device.deviceNetworkId, api: "smart"]
		parent.processChildCmd(commandData)
	} else {
		sendSmartCmd(cmdBody, false)
	}
}

def parse_get_current_power(methResp) {
	Map logData = [method: "smartPowerParse", result: methResp]
	logDebug(logData)
	sendEvent(name: "power", value: methResp.current_power)
}

def smartEnergyRefresh() {
	List requests = [[method: "get_device_usage"]]
	Map cmdBody = [method: "multipleRequest", params: [requests: requests]]
	if (IS_CHILD) {
		Map commandData = [cmdBody: cmdBody, retry: false, devId: getDataValue("deviceId"), 
						   dni: device.deviceNetworkId, api: "smart"]
		parent.processChildCmd(commandData)
	} else {
		sendSmartCmd(cmdBody, false)
	}
}

def parse_get_device_usage(methResp) {
	Map logData = [method: "smartEnergyParse", methResp: methResp]
	def pwrKwh = methResp.power_usage.today / 1000
	sendEvent(name: "energy", value: pwrKwh, descriptionText: "KiloWatt Hours", unit: "KWH")
	logDebug(logData)
}

//	===== IOT API Calls	=====
def iotGetRealtime() {
	state.eventType = "digital"
	getIotPoll()
}

def iotRealtimePoll() {
	state.eventType = "manual"
	getIotPoll()
}

def getIotPoll() {
	Map cmdBody = [:]
	if (getDataValue("plugNo") || IS_CHILD) { 
		cmdBody << [context: [child_ids:[getDataValue("deviceId")]]]
	}
	cmdBody << ["${EM_SYS}": [get_realtime:[]]]
	if (IS_CHILD) {
		Map commandData = [cmdBody: cmdBody, retry: false, devId: getDataValue("deviceId"), 
						   dni: device.deviceNetworkId, api: "iot"]
		parent.processChildCmd(commandData)
	} else {
		sendIotCmd(cmdBody, false)
	}
}

def iotEnergyRefresh() {
	def currDate = new Date()
	int year = currDate.format("yyyy").toInteger()
	Map cmdBody = [:]
	def plugId = getDataValue("plugId")
	if (plugId) { cmdBody << [context: [child_ids:[plugId]]] }
	cmdBody << ["${EM_SYS}": [get_monthstat: [year: year]]]
	if (IS_CHILD) {
		Map commandData = [cmdBody: cmdBody, retry: false, devId: getDataValue("deviceId"), 
						   dni: device.deviceNetworkId, api: "iot"]
		parent.processChildCmd(commandData)
	} else {
		sendIotCmd(cmdBody, false)
	}
}

def parse_emeter(devData) {
	Map logData = [method: "iotEmeterParse"]
	if (devData.get_realtime) {
		def realtime = devData.get_realtime
		def power = realtime.power
		if (power == null) { power = realtime.power_mw / 1000 }
		power = (power + 0.5).toInteger()
		sendEvent(name: "power", value: power)
		logData << [power: power]
		if (state.totWhPrev > 0) {
			def whToday = (realtime.total_wh - state.totWhPrev) / 1000
			sendEvent(name: "energy", value: whToday, descriptionText: "KiloWatt Hours", unit: "KWH")
			logData << [energy: whToday]
		}
	}
	if (devData.get_monthstat) {
		def currDate = new Date()
		int month = currDate.format("M").toInteger()
		def monthData = devData.get_monthstat.month_list.find { it.month == month }
		if (!monthData) {
			logWarn("parse_emeter: No monthstat data for month ${month}")
			return
		}		
		def energyMonth = monthData.energy
		if (energyMonth == null) { energyMonth = monthData.energy_wh / 1000 }
		energyMonth = Math.round(1000 * energyMonth) / 1000
		if (state.settingWhPrev) {
			state.energyYesterday = energyMonth
			logData << [energyYesterday: energyMonth]
			state.remove("settingWhPrev")
		} else {
			def energyToday = energyMonth - state.energyYesterday
			sendEvent(name: "energy", value: energyToday, descriptionText: "KiloWatt Hours", unit: "KWH")
			logData << [energy: energyToday]
		}
	}
	logDebug(logData)
}
