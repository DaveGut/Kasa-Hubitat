/*	Kasa/Tapo Integration Driver: TpLink Lightstrip
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md
*/ 

String nameSpace() { return "davegut" }
String version() { return "2.5.3" }


import groovy.transform.Field
@Field static final String DEV_TYPE = "Light Strip"
@Field static final String EM_SYS = "smartlife.iot.common.emeter"
@Field static final Boolean IS_CHILD = false
@Field static final String LIGHT_TRANS_TYPE = "transition_period"
@Field static final String SYSTEM = "smartlife.iot.lightStrip"
@Field static final String LIGHT_CMD = "set_light_state"

metadata {
	definition (name: "Kasa Light Strip", 
				namespace: nameSpace(), 
				author: "Dave Gutheinz", 
				singleThreaded: true
			   )
	{
		capability "Light"
	}
	preferences {
		emPrefs()
		levelPrefs()
		commonPrefs()
	}
}

def installed() {
	Map instStatus = [method: "installed"]
	instStatus << commonInstalled()
	logInfo(instStatus)
	runIn(5, updated)
	deviceHandshake()
}

def updated() {
	Map updStatus = [method: "updated"]
	unschedule()
	updStatus << [commonUpdated: commonUpdated()]
	updStatus << [levelUpdated: levelUpdated()]
	if (getDataValue("isEm")) { updStatus << [emUpdated: emUpdated()] }
	logInfo(updStatus)
}

def setColorLight(onOff, level, colorTemp, hue, saturation) {
	Map logData = [method: "setColorLight", onOff: onOff, level: level,
				   colorTemp: colorTemp, hue: hue, satuartion: saturation]
	sendEvent(name: "switch", value: onOff, type: state.eventType)
	if (onOff == "on") {
		sendEvent(name: "level", value: level)
		sendEvent(name: "colorTemperature", value: colorTemp)
		int hubHue = (hue / 3.6).toInteger()
		sendEvent(name: "hue", value: hubHue)
		sendEvent(name: "saturation", value: saturation)
		if (colorTemp > 0) {
			sendEvent(name: "colorMode", value: "CT")
			def colorName = convertTemperatureToGenericColorName(colorTemp)
			sendEvent(name: "colorName", value: colorName)
			sendEvent(name: "color", value: [:])
			sendEvent(name: "RGB", value: [])
		} else {
			sendEvent(name: "colorMode", value: "COLOR")
			def colorName = convertHueToGenericColorName(hubHue)
			sendEvent(name: "colorName", value: colorName)
			Map color = [hue: hubHue, saturation: saturation, level: level]
			sendEvent(name: "color", value: color)
			rgb = hubitat.helper.ColorUtils.hsvToRGB([hubHue, saturation, level])
			sendEvent(name: "RGB", value: rgb)
		}
	}
	logDebug(logData)
}

//	===== Smart Methods =====
def parse_get_device_info(devData) {
	def onOff = "off"
	if (devData.device_on == true ) { onOff = "on" }
	int level = devData.brightness.toInteger()
	def colorTemp = devData.color_temp.toInteger()
	int hue = devData.hue.toInteger()
	int saturation = devData.saturation.toInteger()
	setColorLight(onOff, level, colorTemp, hue, saturation)
}

//	===== Iot Methods =====
def parse_system(devData) {
	def onOff = "on"
	if (devData.on_off == 0) {
		onOff = "off"
		devData = devData.dft_on_state
	}
	int level = devData.brightness.toInteger()
	int hue = devData.hue.toInteger()
	int saturation = devData.saturation.toInteger()
	int colorTemp = devData.color_temp.toInteger()
	setColorLight(onOff, level, colorTemp, hue, saturation)
}

//	===== Include Libraries =====
#include tpLink.tpl_cap_switch
#include tpLink.tpl_cap_level
#include tpLink.tpl_cap_color
#include tpLink.tpl_cap_ct
#include tpLink.tpl_cap_em
#include tpLink.tpl_dev_common
#include tpLink.tpl_api_smart
#include tpLink.tpl_api_iot
#include tpLink.tpl_prot_klap
#include tpLink.tpl_prot_aes
#include tpLink.tpl_prot_xor_udp
#include tpLink.tpl_id_logs
#include tpLink.tpl_encode
#include tpLink.tpl_error
