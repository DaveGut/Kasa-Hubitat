library (
	name: "tpl_api_smart",
	namespace: "tpLink",
	author: "Dave Gutheinz",
	description: "kasa-tapo color control. Hub V 2.5.3",
	category: "utilities",
	documentationLink: ""
)

//	===== Device Capability Commands =====
def smartRefresh() {
	state.eventType = "digital"
	List requests = [[method: "get_device_info"]]
	if (emEnable) { 
		requests << [method: "get_current_power"]
	}
	Map cmdBody = [method: "multipleRequest", params: [requests: requests]]
	sendSmartCmd(cmdBody, true)
}

def smartPoll() {
	state.eventType = "manual"
	List requests = [[method: "get_device_info"]]
	if (emEnable) { 
		requests << [method: "get_current_power"]
	}
	Map cmdBody = [method: "multipleRequest", params: [requests: requests]]
	sendSmartCmd(cmdBody, true)
}

//	setColor is used in CT, Color bulbs and light strip.
def setSmartColor(params) {
	List requests = [[method: "set_device_info", params: params],
					 [method: "get_device_info"]]
	Map cmdBody = [method: "multipleRequest", params: [requests: requests]]
	sendSmartCmd(cmdBody, true)
	if (emEnable) { runIn(5, getSmartPower) }
}

//	===== Smart Implementation Interface =====
def sendSmartCmd(cmdBody, retry = false, parseMeth = "parseSmartResp", dni = null) {
//	Insturmentation point for testing	
//log.info "cmdBody: $cmdBody"
	if (retry == true) {
		Map cmdData = [cmdBody: cmdBody, action: parseMeth, retryMeth: "sendSmartCmd"]
		state.cmdData = cmdData
	}
	String cmd = new groovy.json.JsonBuilder(cmdBody).toString()
	Map reqParams = [:]
	logDebug("sendSmartCmd: $cmdBody")
	if (getDataValue("protocol") == "klap") {
		byte[] keyByte = new JsonSlurper().parseText(encKey)
		byte[] ivByte = new JsonSlurper().parseText(encIv)
		byte[] sigByte = new JsonSlurper().parseText(encSig)
		String uri = "${getDataValue("baseUrl")}/request?seq=${state.seqNo + 1}"
		reqParams = getKlapParams(cmd, keyByte, ivByte, sigByte, state.seqNo, uri, cookie)
	} else {
		byte[] encKey = new JsonSlurper().parseText(encKey)
		byte[] encIv = new JsonSlurper().parseText(encIv)
		String uri = "${getDataValue("baseUrl")}?token=${token}"
		reqParams = getAesParams(cmd, encKey, encIv, uri, cookie)
	}
	asynchttpPost(parseMeth, reqParams, [dni: dni, retry: retry])
}

def smartNullParse(resp, data) { }

def parseSmartResp(resp, data) {
	Map logData = [method: "parseSmartResp"]
	def respData = parseKlapAesResp(resp)
	if (respData.cmdResp) {
		def result = respData.cmdResp.result
		result.responses.each {
			if (it.error_code == 0) {
				distSmartData(it)
			} else {
				logData << [devRespError: it]
				logDebug(logData)
			}
		}
	} else {
		logData << respData
		if (data.retry == true && systemPoll.contains("min")) {
			handleCommsError([status: respData.status, cryptoStatus: respData.cryptoStatus])
		}
	}
	logDebug(logData)
}

def parseKlapAesResp(resp) {
	Map logData = [method: "parseKlapAesResp", status: resp.status]
	if (resp.status == 200) {
		Map respData = [:]
		if (getDataValue("protocol") == "klap") {
			logData << [dataLength: resp.data.length()]
			respData << parseKlapData(resp)
		} else { 
			respData << parseAesData(resp)
		}
		logData << [cryptoStatus: respData.cryptoStatus, respData: respData]
		if (respData.cryptoStatus == "OK" && respData.cmdResp != [:]) {
			setCommsError("OK")
			return respData
		}
	} else {
		logData << [respStatus: resp.status, headers: resp.headers]
		logDebug(logData)
	}
	return logData
}

def distSmartData(devResp) {
	def key = devResp.method
	def methResp = devResp.result
	logDebug("[method: distSmartData, $key: $methResp]")
//	Insturmentation point for testing	
//log.info "[method: distSmartData, $key: $methResp]"
	switch(key) {
		case "get_device_info":
			parse_get_device_info(methResp)
			parseNameUpdate(methResp)
			break
		case "get_current_power":
			parse_get_current_power(methResp)
			break
		case "get_device_usage":
			parse_get_device_usage(methResp)
			break
		case "get_on_off_gradually_info":
			parse_get_on_off_gradually_info(methResp)
			break
		case "get_child_device_list":
			parse_get_child_device_list(methResp)
			break
		case "get_led_info":
			parse_get_led_info(methResp)
			break
		case "device_reboot":
			runIn(10, configure)
		default:
			if (!devResp.method.contains("set_")) {
				Map logData = [method: "distGetData", key: key, 
							   methResp: methResp, status: "unprocessed"]
				logDebug(logData)
			}
	}
}
